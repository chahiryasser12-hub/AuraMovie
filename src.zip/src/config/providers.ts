import type { EmbedProvider } from "@/types";

export const EMBED_PROVIDERS: EmbedProvider[] = [
  { 
    id: "videasy", 
    name: "VidEasy", 
    logo: "⚡", 
    color: "#f5c518", 
    // Uses official documentation routes with matching brand-yellow accents & UX overrides
    getMovieUrl: (id) => `https://player.videasy.net/movie/${id}?color=F5C518&overlay=true`, 
    getSeriesUrl: (id, s, e) => `https://player.videasy.net/tv/${id}/${s}/${e}?color=F5C518&nextEpisode=true&autoplayNextEpisode=true&episodeSelector=true&overlay=true` 
  },
  { 
    id: "vidlink", 
    name: "VidLink", 
    logo: "🔗", 
    color: "#00bcd4", 
    getMovieUrl: (id) => `https://vidlink.pro/movie/${id}`, 
    getSeriesUrl: (id, s, e) => `https://vidlink.pro/tv/${id}/${s}/${e}` 
  },
    { 
    id: "vidcore", 
    name: "VidCore", 
    logo: "💎", 
    color: "#00e676", 
    getMovieUrl: (id) => `https://www.vidcore.org/embed/movie/${id}`, 
    getSeriesUrl: (id, s, e) => `https://www.vidcore.org/embed/tv/${id}/${s}/${e}` 
  },
  { 
    id: "vidsrc-to", 
    name: "VidSrc.to", 
    logo: "🍿", 
    color: "#ffc107", 
    getMovieUrl: (id) => `https://vidsrc.to/embed/movie/${id}`, 
    getSeriesUrl: (id, s, e) => `https://vidsrc.to/embed/tv/${id}/${s}/${e}` 
  },
  { 
    id: "embed-su", 
    name: "Embed.su", 
    logo: "💿", 
    color: "#e91e63", 
    getMovieUrl: (id) => `https://embed.su/embed/movie/${id}`, 
    getSeriesUrl: (id, s, e) => `https://embed.su/embed/tv/${id}/${s}/${e}` 
  },
  { 
    id: "vidsrc-me", 
    name: "VidSrc.me", 
    logo: "📽️", 
    color: "#673ab7", 
    getMovieUrl: (id) => `https://vidsrc.me/embed/movie/${id}`, 
    getSeriesUrl: (id, s, e) => `https://vidsrc.me/embed/tv/${id}/${s}/${e}` 
  },
  { 
    id: "vidsrc-cc", 
    name: "VidSrc.cc", 
    logo: "📡", 
    color: "#03a9f4", 
    getMovieUrl: (id) => `https://vidsrc.cc/v2/embed/movie/${id}`, 
    getSeriesUrl: (id, s, e) => `https://vidsrc.cc/v2/embed/tv/${id}/${s}/${e}` 
  },
  { 
    id: "smashystream", 
    name: "SmashyStream", 
    logo: "💥", 
    color: "#8bc34a", 
    getMovieUrl: (id) => `https://embed.smashystream.com/playere.php?tmdb=${id}`, 
    getSeriesUrl: (id, s, e) => `https://embed.smashystream.com/playere.php?tmdb=${id}&season=${s}&episode=${e}` 
  },
  {
    id: "superembed",
    name: "SuperEmbed",
    logo: "⚡",
    color: "#f5a623",
    getMovieUrl: (id: number) => `https://multiembed.mov/?video_id=${id}&tmdb=1`,
    getSeriesUrl: (id: number, season = 1, episode = 1) =>
      `https://multiembed.mov/?video_id=${id}&tmdb=1&s=${season}&e=${episode}`,
  },
  {
    id: "autoembed",
    name: "AutoEmbed",
    logo: "🔥",
    color: "#4caf50",
    getMovieUrl: (id: number) => `https://player.autoembed.cc/embed/movie/${id}`,
    getSeriesUrl: (id: number, season = 1, episode = 1) =>
      `https://player.autoembed.cc/embed/tv/${id}/${season}/${episode}`,
  },
];

export const DEFAULT_PROVIDER_ID = "videasy";