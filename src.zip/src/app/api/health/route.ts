import { db } from "@/db";
import { sql } from "drizzle-orm";

export const dynamic = "force-dynamic";

export async function GET() {
  try {
    await db.execute(sql`select 1`);
    return Response.json({ ok: true });
  } catch (err) {
    // TEMPORAIRE bach nchoufo l error s7i7 - khasna nrej3o l version l9dima b3d ma n7allo l mochkil
    const message = err instanceof Error ? err.message : String(err);
    const stack = err instanceof Error ? err.stack : undefined;
    console.error("Health check DB error:", err);
    return Response.json({ ok: false, error: message, stack }, { status: 500 });
  }
}
