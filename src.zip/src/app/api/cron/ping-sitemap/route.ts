import { NextResponse } from "next/server";
import { getPopularMovies, getPopularSeries } from "@/lib/tmdb";

export const dynamic = "force-dynamic";

// مفتاح معيار IndexNow لأرشفة المحتوى فورياً
const INDEXNOW_KEY = "8d26be786e244b7d8d2a65824bb883b2";
const BASE_URL = process.env.NEXT_PUBLIC_SITE_URL || "https://auramovie.dpdns.org";

export async function GET() {
  try {
    // 1. جلب أحدث القوائم من TMDB
    const [movies, series] = await Promise.all([
      getPopularMovies(1),
      getPopularSeries(1),
    ]);

    // القائمة الأساسية للصفحات
    const urlsToPing: string[] = [
      `${BASE_URL}/`,
      `${BASE_URL}/movies`,
      `${BASE_URL}/series`,
    ];

    // إضافة أول 10 أفلام شعبية للقائمة
    if (movies?.results) {
      movies.results.slice(0, 10).forEach((m) => {
        urlsToPing.push(`${BASE_URL}/movies/${m.id}`);
      });
    }

    // إضافة أول 10 مسلسلات شعبية للقائمة
    if (series?.results) {
      series.results.slice(0, 10).forEach((s) => {
        urlsToPing.push(`${BASE_URL}/series/${s.id}`);
      });
    }

    // 2. إعداد حمولة البيانات (Payload) لـ IndexNow
    const indexNowPayload = {
      host: new URL(BASE_URL).hostname,
      key: INDEXNOW_KEY,
      keyLocation: `${BASE_URL}/${INDEXNOW_KEY}.txt`,
      urlList: urlsToPing,
    };

    // 3. إرسال الطلب لمحرك الأرشفة الفورية المشترك
    const response = await fetch("https://api.indexnow.org/indexnow", {
      method: "POST",
      headers: {
        "Content-Type": "application/json; charset=utf-8",
      },
      body: JSON.stringify(indexNowPayload),
    });

    if (!response.ok) {
      throw new Error(`IndexNow API responded with status ${response.status}`);
    }

    return NextResponse.json({
      success: true,
      message: `Successfully submitted ${urlsToPing.length} URLs to IndexNow search engines.`,
      urlsCount: urlsToPing.length,
      urls: urlsToPing,
    });
  } catch (err) {
    console.error("IndexNow ping cron error:", err);
    return NextResponse.json(
      {
        success: false,
        error: err instanceof Error ? err.message : String(err),
      },
      { status: 500 }
    );
  }
}