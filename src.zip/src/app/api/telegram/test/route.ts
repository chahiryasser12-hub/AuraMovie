// src/app/api/telegram/test/route.ts
import { NextResponse } from "next/server";
import { postMediaToTelegram } from "@/lib/telegram";

export async function GET(request: Request) {
  const { searchParams } = new URL(request.url);
  const id = searchParams.get("id"); // TMDB ID
  const type = (searchParams.get("type") as 'movie' | 'tv') || 'movie';

  if (!id) return NextResponse.json({ error: "Need ID" }, { status: 400 });

  const result = await postMediaToTelegram(Number(id), type, 'ar');

  return NextResponse.json({ 
    message: "Check your Telegram channel!",
    result 
  });
}