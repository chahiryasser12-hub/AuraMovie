import { NextResponse } from "next/server";
import { db } from "@/db";
import { comments } from "@/db/schema";

interface CommentBody {
  tmdbId: string | number;
  mediaType: string;
  userName: string;
  content: string;
  rating?: string | number | null;
}

export async function POST(req: Request) {
  try {
    // حددنا لـ TypeScript النوع ديال body باش يحيد الخطأ
    const body = (await req.json()) as CommentBody;
    const { tmdbId, mediaType, userName, content, rating } = body;

    if (!tmdbId || !mediaType || !userName || !content) {
      return NextResponse.json({ error: "Missing required fields" }, { status: 400 });
    }

    await db.insert(comments).values({
      tmdbId: typeof tmdbId === 'string' ? parseInt(tmdbId, 10) : tmdbId,
      mediaType,
      userName: userName.trim(),
      content: content.trim(),
      rating: rating ? parseInt(String(rating), 10) : null,
    });

    return NextResponse.json({ success: true });
  } catch (err) {
    console.error("Failed to post comment:", err);
    return NextResponse.json({ error: "Server error" }, { status: 500 });
  }
}