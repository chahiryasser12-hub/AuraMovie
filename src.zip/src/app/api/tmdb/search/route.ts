import { NextRequest, NextResponse } from "next/server";
import { searchMulti, searchMovies, searchSeries, searchPeople } from "@/lib/tmdb";

export async function GET(request: NextRequest) {
  const { searchParams } = request.nextUrl;
  const query = searchParams.get("q") || "";
  const type = searchParams.get("type") || "multi";
  const page = parseInt(searchParams.get("page") || "1", 10);

  if (!query.trim()) {
    return NextResponse.json({ results: [], total_results: 0, total_pages: 0, page: 1 });
  }

  try {
    let data;
    switch (type) {
      case "movie":
        data = await searchMovies(query, page);
        break;
      case "tv":
        data = await searchSeries(query, page);
        break;
      case "person":
        data = await searchPeople(query, page);
        break;
      default:
        data = await searchMulti(query, page);
    }
    return NextResponse.json(data);
  } catch (err) {
    const message = err instanceof Error ? err.message : "Unknown error";
    return NextResponse.json({ error: message }, { status: 500 });
  }
}