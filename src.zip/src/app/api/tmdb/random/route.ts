import { NextResponse } from "next/server";
import { getTrendingMovies, getTrendingSeries } from "@/lib/tmdb";

export const dynamic = "force-dynamic";

export async function GET() {
  try {
    // جلب أحدث العناوين الشائعة للأفلام والمسلسلات فـ نفس الوقت
    const [moviesResponse, seriesResponse] = await Promise.all([
      getTrendingMovies("week"),
      getTrendingSeries("week"),
    ]);

    const movies = moviesResponse.results || [];
    const series = seriesResponse.results || [];

    // دمج القوائم وتعريف نوع كل عنصر (فيلم أو مسلسل)
    const combined = [
      ...movies.map((m) => ({ id: m.id, type: "movie" })),
      ...series.map((s) => ({ id: s.id, type: "tv" })),
    ];

    if (combined.length === 0) {
      return NextResponse.json({ error: "No trending titles found" }, { status: 404 });
    }

    // اختيار عنصر عشوائي من القائمة المدمجة
    const randomItem = combined[Math.floor(Math.random() * combined.length)];

    return NextResponse.json({
      id: randomItem.id,
      type: randomItem.type,
    });
  } catch (err) {
    console.error("Error generating random title:", err);
    return NextResponse.json({ error: "Failed to generate random title" }, { status: 500 });
  }
}