import { NextRequest, NextResponse } from "next/server";
import {
  getTrendingMovies,
  getPopularMovies,
  getTopRatedMovies,
  getNowPlayingMovies,
  getUpcomingMovies,
  discoverMovies,
} from "@/lib/tmdb";

export async function GET(request: NextRequest) {
  const { searchParams } = request.nextUrl;
  const type = searchParams.get("type") || "popular";
  const page = parseInt(searchParams.get("page") || "1", 10);
  const genre = searchParams.get("genre") || undefined;

  try {
    let data;
    switch (type) {
      case "trending":
        data = await getTrendingMovies("week");
        break;
      case "top_rated":
        data = await getTopRatedMovies(page);
        break;
      case "now_playing":
        data = await getNowPlayingMovies(page);
        break;
      case "upcoming":
        data = await getUpcomingMovies(page);
        break;
      case "discover":
        data = await discoverMovies({
          page,
          with_genres: genre,
          sort_by: "popularity.desc",
        });
        break;
      default:
        data = await getPopularMovies(page);
    }
    return NextResponse.json(data);
  } catch (err) {
    const message = err instanceof Error ? err.message : "Unknown error";
    return NextResponse.json({ error: message }, { status: 500 });
  }
}
