import { NextRequest, NextResponse } from "next/server";
import {
  getTrendingSeries,
  getPopularSeries,
  getTopRatedSeries,
  getOnAirSeries,
  discoverSeries,
} from "@/lib/tmdb";

export async function GET(request: NextRequest) {
  const { searchParams } = request.nextUrl;
  const type = searchParams.get("type") || "popular";
  const page = parseInt(searchParams.get("page") || "1", 10);
  const genre = searchParams.get("genre") || undefined;

  try {
    let data;
    switch (type) {
      case "trending":
        data = await getTrendingSeries("week");
        break;
      case "top_rated":
        data = await getTopRatedSeries(page);
        break;
      case "on_air":
        data = await getOnAirSeries(page);
        break;
      case "discover":
        data = await discoverSeries({
          page,
          with_genres: genre,
          sort_by: "popularity.desc",
        });
        break;
      default:
        data = await getPopularSeries(page);
    }
    return NextResponse.json(data);
  } catch (err) {
    const message = err instanceof Error ? err.message : "Unknown error";
    return NextResponse.json({ error: message }, { status: 500 });
  }
}
