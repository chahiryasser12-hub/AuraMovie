import { NextResponse } from "next/server";
import { db } from "@/db";
import { requests } from "@/db/schema";

interface RequestBody {
  title?: string;
  mediaType?: string;
  notes?: string;
}

export async function POST(req: Request) {
  try {
    const body = (await req.json()) as RequestBody;
    const { title, mediaType, notes } = body;

    if (!title || !mediaType) {
      return NextResponse.json({ error: "Missing required fields" }, { status: 400 });
    }

    await db.insert(requests).values({
      title,
      mediaType,
      notes: notes || null,
    });

    return NextResponse.json({ success: true });
  } catch (err) {
    console.error("Database insert error", err);
    return NextResponse.json({ error: "Failed to store request" }, { status: 500 });
  }
}