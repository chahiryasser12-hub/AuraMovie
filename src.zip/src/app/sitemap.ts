import type { MetadataRoute } from 'next';
import { getPopularMovies, getPopularSeries, getTrendingAnimeSeries, getTrendingAnimeMovies } from '@/lib/tmdb';
import { slugify } from '@/lib/utils';
import { db } from '@/db';
import { articles } from '@/db/schema';

const BASE_URL = process.env.NEXT_PUBLIC_SITE_URL || 'https://auramovie.dpdns.org';

// Dynamic Sitemaps generator
export async function generateSitemaps() {
  return [
    { id: 0 }, // للروابط الثابتة (الرئيسية، المقالات، إلخ)
    { id: 1 }, // لأفلام TMDB (الصفحات 1 إلى 5)
    { id: 2 }, // لمسلسلات TMDB (الصفحات 1 إلى 5)
    { id: 3 }, // لأنمي TMDB (أفلام + مسلسلات)
    { id: 4 }, // لمقالات المدونة (كل اللغات)
  ];
}

export default async function sitemap({ id }: { id: number }): Promise<MetadataRoute.Sitemap> {
  const sitemapEntries: MetadataRoute.Sitemap = [];
  const locales = ['ar', 'en', 'fr'];

  // 0: Static Routes
  if (id === 0) {
    locales.forEach(locale => {
      ['', '/movies', '/series', '/anime', '/coming-soon', '/blog', '/about', '/request'].forEach(route => {
        sitemapEntries.push({
          url: `${BASE_URL}/${locale}${route}`,
          lastModified: new Date(),
          changeFrequency: 'daily',
          priority: route === '' ? 1.0 : 0.8
        });
      });
    });
    return sitemapEntries;
  }

  // 1: Movies
  if (id === 1) {
    const pages = [1, 2, 3, 4, 5]; // 5 pages = 100 movies
    const movieResults = await Promise.all(pages.map(p => getPopularMovies(p).catch(() => ({ results: [] }))));
    const allMovies = movieResults.flatMap(res => res.results);

    allMovies.forEach(movie => {
      const slug = slugify(movie.original_title || movie.title || "");
      sitemapEntries.push({
        url: `${BASE_URL}/ar/movies/${movie.id}-${slug}`,
        lastModified: new Date(),
        changeFrequency: 'weekly',
        priority: 0.7,
        alternates: {
          languages: {
            en: `${BASE_URL}/en/movies/${movie.id}-${slug}`,
            fr: `${BASE_URL}/fr/movies/${movie.id}-${slug}`,
            ar: `${BASE_URL}/ar/movies/${movie.id}-${slug}`,
          }
        }
      });
    });
    return sitemapEntries;
  }

  // 2: Series
  if (id === 2) {
    const pages = [1, 2, 3, 4, 5];
    const seriesResults = await Promise.all(pages.map(p => getPopularSeries(p).catch(() => ({ results: [] }))));
    const allSeries = seriesResults.flatMap(res => res.results);

    allSeries.forEach(s => {
      const slug = slugify(s.original_name || s.name || "");
      sitemapEntries.push({
        url: `${BASE_URL}/ar/series/${s.id}-${slug}`,
        lastModified: new Date(),
        changeFrequency: 'weekly',
        priority: 0.7,
        alternates: {
          languages: {
            en: `${BASE_URL}/en/series/${s.id}-${slug}`,
            fr: `${BASE_URL}/fr/series/${s.id}-${slug}`,
            ar: `${BASE_URL}/ar/series/${s.id}-${slug}`,
          }
        }
      });
    });
    return sitemapEntries;
  }

  // 3: Anime (movies + series, 3 pages each = ~120 titles)
  if (id === 3) {
    const pages = [1, 2, 3];

    const [animeSeriesResults, animeMoviesResults] = await Promise.all([
      Promise.all(pages.map(p => getTrendingAnimeSeries(p).catch(() => ({ results: [] })))),
      Promise.all(pages.map(p => getTrendingAnimeMovies(p).catch(() => ({ results: [] })))),
    ]);

    const allAnimeSeries = animeSeriesResults.flatMap(res => res.results);
    const allAnimeMovies = animeMoviesResults.flatMap(res => res.results);

    allAnimeSeries.forEach((s: any) => {
      const slug = slugify(s.original_name || s.name || "");
      sitemapEntries.push({
        url: `${BASE_URL}/ar/anime/${s.id}-${slug}?type=tv`,
        lastModified: new Date(),
        changeFrequency: 'weekly',
        priority: 0.6,
        alternates: {
          languages: {
            en: `${BASE_URL}/en/anime/${s.id}-${slug}?type=tv`,
            fr: `${BASE_URL}/fr/anime/${s.id}-${slug}?type=tv`,
            ar: `${BASE_URL}/ar/anime/${s.id}-${slug}?type=tv`,
          }
        }
      });
    });

    allAnimeMovies.forEach((m: any) => {
      const slug = slugify(m.original_title || m.title || "");
      sitemapEntries.push({
        url: `${BASE_URL}/ar/anime/${m.id}-${slug}?type=movie`,
        lastModified: new Date(),
        changeFrequency: 'weekly',
        priority: 0.6,
        alternates: {
          languages: {
            en: `${BASE_URL}/en/anime/${m.id}-${slug}?type=movie`,
            fr: `${BASE_URL}/fr/anime/${m.id}-${slug}?type=movie`,
            ar: `${BASE_URL}/ar/anime/${m.id}-${slug}?type=movie`,
          }
        }
      });
    });

    return sitemapEntries;
  }

  // 4: Blog posts (each article row already carries its own locale)
  if (id === 4) {
    const posts = await db.select().from(articles).catch(() => []);

    posts.forEach((post) => {
      sitemapEntries.push({
        url: `${BASE_URL}/${post.locale}/blog/${post.slug}`,
        lastModified: post.publishedAt ? new Date(post.publishedAt) : new Date(),
        changeFrequency: 'monthly',
        priority: 0.6,
      });
    });

    return sitemapEntries;
  }

  return [];
}