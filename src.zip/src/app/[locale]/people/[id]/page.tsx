import { Suspense } from "react";
import { notFound } from "next/navigation";
import Image from "next/image";
import { getPersonDetails, getImageUrl } from "@/lib/tmdb";
import { Header } from "@/components/layout/Header";
import { Footer } from "@/components/layout/Footer";
import { MovieCard } from "@/components/media/MovieCard";
import { SeriesCard } from "@/components/media/SeriesCard";
import { MediaGrid } from "@/components/media/MediaGrid";
import { DetailPageSkeleton } from "@/components/ui/Skeleton";
import { formatDate } from "@/lib/utils";
import { getDictionary } from "@/lib/i18n";

interface PersonPageProps {
  params: Promise<{ id: string; locale: string }>;
}

// دالة ذكية للترجمة التلقائية فالسيرفر فاش متكونش السيرة مترجمة فـ TMDB
async function translateText(text: string, targetLang: string): Promise<string> {
  if (!text || !text.trim() || targetLang === "en") return text;
  try {
    const url = `https://translate.googleapis.com/translate_a/single?client=gtx&sl=en&tl=${targetLang}&dt=t&q=${encodeURIComponent(text)}`;
    const res = await fetch(url, {
      next: { revalidate: 86400 } // كاش للترجمة لمدة يوم كامل لتفادي كثرة الطلبات وتسريع التصفح
    });
    if (!res.ok) return text;
    
    // هنا قمنا بتحويل النوع إلى any لتجاوز فحص TypeScript الصارم
    const data = (await res.json()) as any;
    
    if (data && Array.isArray(data[0])) {
      const translatedParts = data[0]
        .map((part: any) => (Array.isArray(part) ? part[0] : ""))
        .filter(Boolean);
      return translatedParts.join("");
    }
    return text;
  } catch (err) {
    console.error("Auto-translation failed, falling back to English biography", err);
    return text;
  }
}

export async function generateMetadata({ params }: PersonPageProps) {
  const { id } = await params;
  try {
    // جلب البيانات بالإنجليزية دائماً لضمان بقاء اسم الممثل بالإنجليزية في العنوان المتوافق مع السيو
    const person = await getPersonDetails(parseInt(id, 10), "en");
    return {
      title: `${person.name} – Filmography & Biography – AuraMovie`,
      description: person.biography 
        ? person.biography.slice(0, 150) 
        : `Read the biography and explore movies and TV shows featuring ${person.name} on AuraMovie.`,
    };
  } catch {
    return { title: "Actor Profile – AuraMovie" };
  }
}

async function PersonPageContent({ id, locale }: { id: string; locale: string }) {
  let personEn;
  let personLocalized = null;

  try {
    // جلب البيانات بالتوازي: نسخة إنجليزية للاسم والأعمال، ونسخة محلية للسيرة الذاتية
    if (locale !== "en") {
      const [enData, locData] = await Promise.all([
        getPersonDetails(parseInt(id, 10), "en"),
        getPersonDetails(parseInt(id, 10), locale).catch(() => null) // تلافي الانهيار في حال عدم توفر ترجمة لهذه اللغة
      ]);
      personEn = enData;
      personLocalized = locData;
    } else {
      personEn = await getPersonDetails(parseInt(id, 10), "en");
    }
  } catch {
    notFound();
  }

  const dict = getDictionary(locale);

  // السيرة الذاتية باللغة المحلية (مع الرجوع للإنجليزية كبديل في حال عدم توفر ترجمة)
  let biography = personLocalized?.biography || personEn.biography;

  // إذا كانت السيرة الذاتية باللغة المحلية فارغة أو مساوية للإنجليزية، نقوم بترجمتها تلقائياً عبر Google Translate
  if (locale !== "en" && (!personLocalized?.biography || personLocalized.biography === personEn.biography)) {
    if (personEn.biography) {
      biography = await translateText(personEn.biography, locale);
    }
  }

  const profileUrl = getImageUrl(personEn.profile_path, "w400");
  
  // استخدام قائمة الأعمال بالإنجليزية لضمان بقاء أسماء الأفلام والمسلسلات بالإنجليزية
  const credits = personEn.combined_credits?.cast || [];
  
  const seenCredits = new Set<string>();
  const sortedCredits = credits
    .filter((item) => {
      const creditKey = `${item.media_type}-${item.id}`;
      if (!item.poster_path || seenCredits.has(creditKey)) return false;
      seenCredits.add(creditKey);
      return true;
    })
    .sort((a, b) => b.vote_average - a.vote_average)
    .slice(0, 18);

  return (
    <div className="min-h-screen bg-zinc-950">
      <Header />

      <main className="pt-28 pb-16 max-w-[1400px] mx-auto px-4 md:px-8">
        <div className="flex flex-col md:flex-row gap-8 lg:gap-12 items-start">
          
          {/* Profile Image Column */}
          <div className="w-full md:w-64 lg:w-72 flex-shrink-0 flex flex-col gap-4">
            <div className="relative aspect-[3/4] w-full rounded-2xl overflow-hidden shadow-2xl border border-zinc-800">
              <Image
                src={profileUrl}
                alt={personEn.name}
                fill
                priority
                className="object-cover"
                unoptimized
              />
            </div>
            
            {/* Quick Metadata Block */}
            <div className="bg-zinc-900/40 border border-zinc-900/60 rounded-2xl p-5 flex flex-col gap-3 text-sm select-none">
              {personEn.birthday && (
                <div>
                  <span className="block text-[10px] text-zinc-550 font-black uppercase tracking-wider mb-0.5">{dict.birthday}</span>
                  <span className="text-zinc-300 font-semibold">{formatDate(personEn.birthday)}</span>
                </div>
              )}
              {personEn.place_of_birth && (
                <div>
                  <span className="block text-[10px] text-zinc-550 font-black uppercase tracking-wider mb-0.5">{dict.placeOfBirth}</span>
                  <span className="text-zinc-300 font-semibold">{personEn.place_of_birth}</span>
                </div>
              )}
            </div>
          </div>

          {/* Details Column */}
          <div className="flex-1 min-w-0">
            <span className="bg-amber-400/10 border border-amber-400/20 text-amber-400 text-xs font-black px-3.5 py-1.5 rounded-lg uppercase tracking-wider select-none">
              {dict.actor}
            </span>
            
            {/* إبقاء اسم الممثل بالإنجليزية دائماً */}
            <h1 className="text-3xl md:text-5xl font-black text-white mt-3 leading-tight tracking-tight">
              {personEn.name}
            </h1>
            
            <div className="mt-8">
              <h2 className="text-base font-black text-white border-l-4 border-amber-400 pl-2.5 uppercase tracking-wider select-none mb-4">
                {dict.biography}
              </h2>
              {biography ? (
                <p className="text-zinc-400 text-sm md:text-base leading-relaxed whitespace-pre-line">
                  {biography}
                </p>
              ) : (
                <p className="text-zinc-555 text-sm italic">
                  No biography available in this language for this person.
                </p>
              )}
            </div>
          </div>
        </div>

        {/* Filmography Section */}
        {sortedCredits.length > 0 && (
          <div className="mt-16 border-t border-zinc-900/60 pt-10">
            <h2 className="text-xl font-black text-white mb-2 border-l-4 border-amber-400 pl-3 uppercase tracking-wider select-none">
              {dict.famousWorks}
            </h2>
            <p className="text-zinc-550 text-xs md:text-sm mb-8 select-none">
              Explore films and television shows featuring {personEn.name}.
            </p>

            <MediaGrid>
              {sortedCredits.map((item) => {
                if (item.media_type === "movie") {
                  return (
                    <MovieCard
                      key={`movie-${item.id}`}
                      movie={{
                        id: item.id,
                        title: item.title || "Unknown",
                        original_title: item.title || "",
                        overview: "",
                        poster_path: item.poster_path,
                        backdrop_path: null,
                        release_date: item.release_date || "",
                        vote_average: item.vote_average || 0,
                        vote_count: 0,
                        popularity: 0,
                        genre_ids: [],
                        adult: false,
                        original_language: "",
                        video: false,
                      }}
                    />
                  );
                } else {
                  return (
                    <SeriesCard
                      key={`tv-${item.id}`}
                      series={{
                        id: item.id,
                        name: item.name || "Unknown",
                        original_name: item.name || "",
                        overview: "",
                        poster_path: item.poster_path,
                        backdrop_path: null,
                        first_air_date: item.first_air_date || "",
                        vote_average: item.vote_average || 0,
                        vote_count: 0,
                        popularity: 0,
                        genre_ids: [],
                        original_language: "",
                        origin_country: [],
                      }}
                    />
                  );
                }
              })}
            </MediaGrid>
          </div>
        )}
      </main>

      <Footer />
    </div>
  );
}

export default async function PersonPage({ params }: PersonPageProps) {
  const { id, locale } = await params;
  return (
    <Suspense fallback={<DetailPageSkeleton />}>
      <PersonPageContent id={id} locale={locale} />
    </Suspense>
  );
}
