import { Suspense } from "react";
import { Header } from "@/components/layout/Header";
import { Footer } from "@/components/layout/Footer";
import { HeroBanner } from "@/components/media/HeroBanner";
import { TrendingSection } from "@/components/sections/TrendingSection";
import { PopularSection } from "@/components/sections/PopularSection";
import { TopRatedSection } from "@/components/sections/TopRatedSection";
import { GenreSection } from "@/components/sections/GenreSection";
import { ContinueWatchingSection } from "@/components/sections/ContinueWatchingSection";
import { HeroBannerSkeleton } from "@/components/ui/Skeleton";
import { getDictionary } from "@/lib/i18n";
import {
  getTrendingMovies,
  getPopularMovies,
  getTrendingSeries,
  getTopRatedSeries,
  discoverMovies,
} from "@/lib/tmdb";
import type { TMDBMovie, TMDBSeries } from "@/types/tmdb";

export const revalidate = 3600;

function sortByRating<T extends { vote_average: number }>(items: T[]): T[] {
  if (!items) return [];
  return [...items].sort((a, b) => b.vote_average - a.vote_average);
}

async function fetchHomeData(locale: string) {
  try {
    // تمرير لغة المسار لـ TMDB لجلب محتوى مترجم
    const [
      trendingMovies, 
      popularMovies, 
      trendingSeries, 
      topRatedSeries,
      newReleases2026,
      horrorThriller,
      actionAdventure,
      dramaBiography,
      familyAnimation
    ] = await Promise.all([
      getTrendingMovies("week", locale),
      getPopularMovies(1, locale),
      getTrendingSeries("week", locale),
      getTopRatedSeries(1, locale),
      discoverMovies({ year: "2026", sort_by: "popularity.desc", page: 1, language: locale }),
      discoverMovies({ with_genres: "27,53", sort_by: "popularity.desc", page: 1, language: locale }),
      discoverMovies({ with_genres: "28,12", sort_by: "popularity.desc", page: 1, language: locale }),
      discoverMovies({ with_genres: "18,36", sort_by: "popularity.desc", page: 1, language: locale }),
      discoverMovies({ with_genres: "10751,16", sort_by: "popularity.desc", page: 1, language: locale }),
    ]);

    return { 
      trendingMovies, 
      popularMovies, 
      trendingSeries, 
      topRatedSeries,
      newReleases2026,
      horrorThriller,
      actionAdventure,
      dramaBiography,
      familyAnimation,
      error: null 
    };
  } catch (err) {
    const message = err instanceof Error ? err.message : "Failed to load";
    const emptyResponse = { results: [] as TMDBMovie[], page: 1, total_pages: 0, total_results: 0 };
    return {
      trendingMovies: emptyResponse,
      popularMovies: emptyResponse,
      trendingSeries: { results: [] as TMDBSeries[], page: 1, total_pages: 0, total_results: 0 },
      topRatedSeries: { results: [] as TMDBSeries[], page: 1, total_pages: 0, total_results: 0 },
      newReleases2026: emptyResponse,
      horrorThriller: emptyResponse,
      actionAdventure: emptyResponse,
      dramaBiography: emptyResponse,
      familyAnimation: emptyResponse,
      error: message,
    };
  }
}

interface HomePageProps {
  params: Promise<{ locale: string }>;
}

export default async function HomePage({ params }: HomePageProps) {
  const { locale } = await params;
  
  const { 
    trendingMovies, 
    popularMovies, 
    trendingSeries, 
    topRatedSeries,
    newReleases2026,
    horrorThriller,
    actionAdventure,
    dramaBiography,
    familyAnimation,
    error 
  } = await fetchHomeData(locale);

  const dict = getDictionary(locale);

  const sortedNewReleases = sortByRating(newReleases2026.results);
  const sortedTrendingMovies = sortByRating(trendingMovies.results);
  const sortedTrendingSeries = sortByRating(trendingSeries.results);
  const sortedActionAdventure = sortByRating(actionAdventure.results);
  const sortedHorrorThriller = sortByRating(horrorThriller.results);
  const sortedDramaBiography = sortByRating(dramaBiography.results);
  const sortedFamilyAnimation = sortByRating(familyAnimation.results);
  const sortedPopularMovies = sortByRating(popularMovies.results);
  const sortedTopRatedSeries = sortByRating(topRatedSeries.results);

  const heroItems = [
    ...sortedTrendingMovies.slice(0, 5),
    ...sortedTrendingSeries.slice(0, 3),
  ];

  if (error) {
    return (
      <div className="min-h-screen bg-zinc-950">
        <Header />
        <main className="flex flex-col items-center justify-center min-h-[80vh] gap-6 px-4 text-center">
          <div className="text-6xl">🎬</div>
          <div>
            <h1 className="text-3xl font-black text-white mb-2 border-l-4 border-amber-400 pl-3 uppercase tracking-widest">
              AuraMovie
            </h1>
            <p className="text-zinc-400 text-sm max-w-md mt-4">
              Unable to load content. Please configure your TMDB API key.
            </p>
          </div>
          <p className="text-zinc-600 text-xs">Error: {error}</p>
        </main>
        <Footer />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-zinc-950">
      <Header />

      <main>
        <Suspense fallback={<HeroBannerSkeleton />}>
          <HeroBanner items={heroItems} />
        </Suspense>

        <ContinueWatchingSection />

        {/* ترجمة العناوين ديناميكياً باستخدام القاموس */}
        <GenreSection 
          title={dict.newReleases2026} 
          movies={sortedNewReleases} 
          explorePath={`/${locale}/movies`}
        />

        <TrendingSection
          movies={sortedTrendingMovies}
          series={sortedTrendingSeries}
        />

        <GenreSection 
          title={dict.actionAdventure} 
          movies={sortedActionAdventure} 
          explorePath={`/${locale}/genres/28?type=movie`}
        />

        <GenreSection 
          title={dict.horrorThriller} 
          movies={sortedHorrorThriller} 
          explorePath={`/${locale}/genres/27?type=movie`}
        />

        <GenreSection 
          title={dict.dramaBiographies} 
          movies={sortedDramaBiography} 
          explorePath={`/${locale}/genres/18?type=movie`}
        />

        <GenreSection 
          title={dict.familyAnimation} 
          movies={sortedFamilyAnimation} 
          explorePath={`/${locale}/genres/10751?type=movie`}
        />

        <PopularSection movies={sortedPopularMovies} />
        <TopRatedSection series={sortedTopRatedSeries} />
      </main>

      <Footer />
    </div>
  );
}