import { Header } from "@/components/layout/Header";
import { Footer } from "@/components/layout/Footer";
import { getDictionary } from "@/lib/i18n";

export default async function PrivacyPage({ params }: { params: Promise<{ locale: string }> }) {
  const { locale } = await params;
  const dict = getDictionary(locale);
  const isAr = locale === 'ar';

  return (
    <div className="min-h-screen bg-zinc-950 flex flex-col">
      <Header />
      <main className="flex-1 pt-32 pb-16 max-w-4xl mx-auto px-6">
        <h1 className="text-3xl md:text-5xl font-black text-white mb-10 border-l-4 border-amber-400 pl-4">
          {dict.privacyPolicy}
        </h1>
        <div className="space-y-10 text-zinc-400 text-xs md:text-sm leading-loose">
          
          <section>
            <h2 className="text-white font-bold text-lg mb-3">{isAr ? "1. المعلومات التي نجمعها" : "1. Information Collection"}</h2>
            <p>{isAr ? "نحن في AuraMovie نحترم خصوصيتك. لا نقوم بجمع أي معلومات شخصية مثل الاسم أو العنوان بشكل مباشر إلا إذا قدمتها لنا طواعية." : "At AuraMovie, we respect your privacy. We do not collect personal info unless you voluntarily provide it."}</p>
          </section>

          <section className="bg-zinc-900/30 p-6 rounded-2xl border border-zinc-800">
            <h2 className="text-amber-400 font-bold text-lg mb-3">Google AdSense & Cookies</h2>
            <p>
              {isAr 
                ? "نحن نستخدم Google AdSense لعرض الإعلانات. تستخدم جوجل ملفات تعريف الارتباط (Cookies) لخدمة الإعلانات بناءً على زيارات المستخدم لموقعنا. يمكنك إلغاء استخدام ملف تعريف الارتباط DART بزيارة سياسة خصوصية إعلانات جوجل."
                : "We use Google AdSense to serve ads. Google uses cookies to serve ads based on a user's prior visits to our website. You may opt out of the DART cookie by visiting the Google Ad network privacy policy."}
            </p>
          </section>

          <section>
            <h2 className="text-white font-bold text-lg mb-3">{isAr ? "2. سجلات الملفات (Log Files)" : "2. Log Files"}</h2>
            <p>{isAr ? "مثل العديد من المواقع الأخرى، يستخدم AuraMovie سجلات الملفات. هذه الملفات تسجل فقط الزوار للموقع - وهي إجراء قياسي لشركات الاستضافة وتحليلات الخدمات." : "Like many other sites, AuraMovie makes use of log files. This info includes IP addresses, browser type, and timestamps."}</p>
          </section>

          <section>
            <h2 className="text-white font-bold text-lg mb-3">{isAr ? "3. الموافقة" : "3. Consent"}</h2>
            <p>{isAr ? "باستخدام موقعنا، فإنك توافق على سياسة الخصوصية الخاصة بنا وتوافق على شروطها." : "By using our website, you hereby consent to our Privacy Policy and agree to its terms."}</p>
          </section>
        </div>
      </main>
      <Footer />
    </div>
  );
}