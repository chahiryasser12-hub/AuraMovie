import { discoverMovies, discoverSeries } from "@/lib/tmdb";
import { Header } from "@/components/layout/Header";
import { Footer } from "@/components/layout/Footer";
import { MovieCard } from "@/components/media/MovieCard";
import { SeriesCard } from "@/components/media/SeriesCard";
import { MediaGrid } from "@/components/media/MediaGrid";
import { MOVIE_GENRES, TV_GENRES } from "@/lib/tmdb";
import { notFound } from "next/navigation";

interface GenrePageProps {
  params: Promise<{ id: string }>;
  searchParams: Promise<{ type?: string }>;
}

export async function generateMetadata({ params, searchParams }: GenrePageProps) {
  const { id } = await params;
  const { type = "movie" } = await searchParams;
  const genreId = parseInt(id, 10);
  const genreName = type === "tv" ? TV_GENRES[genreId] : MOVIE_GENRES[genreId];

  if (!genreName) return { title: "Browse Genres - AuraMovie" };
  return {
    title: `Best ${genreName} ${type === "tv" ? "TV Shows" : "Movies"} to Watch – AuraMovie`,
    description: `Explore top trending ${genreName.toLowerCase()} ${type === "tv" ? "tv series" : "movies"} on AuraMovie. Stream online.`,
  };
}

export default async function GenrePage({ params, searchParams }: GenrePageProps) {
  const { id } = await params;
  const { type = "movie" } = await searchParams;
  const genreId = parseInt(id, 10);
  const genreName = type === "tv" ? TV_GENRES[genreId] : MOVIE_GENRES[genreId];

  if (!genreName) {
    notFound();
  }

  const response = type === "tv"
    ? await discoverSeries({ with_genres: id, page: 1 })
    : await discoverMovies({ with_genres: id, page: 1 });

  return (
    <div className="min-h-screen bg-zinc-950">
      <Header />
      <main className="pt-24 pb-16 max-w-[1400px] mx-auto px-4 md:px-8">
        <div className="mb-8">
          <h1 className="text-3xl md:text-4xl font-black text-white flex items-center gap-2">
            <span>🎭</span> {genreName} {type === "tv" ? "Series" : "Movies"}
          </h1>
          <p className="text-zinc-500 text-sm mt-2">
            Browse our curated selection of high-quality {genreName.toLowerCase()} titles.
          </p>
        </div>

        <MediaGrid>
          {response.results.map((item) => {
            if (type === "tv") {
              return <SeriesCard key={item.id} series={item as any} />;
            } else {
              return <MovieCard key={item.id} movie={item as any} />;
            }
          })}
        </MediaGrid>
      </main>
      <Footer />
    </div>
  );
}