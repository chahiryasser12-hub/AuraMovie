import { Suspense } from "react";
import { Metadata } from "next";
import "../globals.css";
import { pickLocale } from "@/lib/i18n";

interface LayoutProps {
  children: React.ReactNode;
  params: Promise<{ locale: string }>;
}

export async function generateMetadata({ params }: { params: Promise<{ locale: string }> }): Promise<Metadata> {
  const { locale } = await params;
  const baseUrl = process.env.NEXT_PUBLIC_SITE_URL || "https://auramovie.dpdns.org";

  // SEO قوي بـ 3 لغات: عربي / فرنسي / إنجليزي
  const title = pickLocale(locale, {
    ar: "اورا موفي AuraMovie | مشاهدة أفلام ومسلسلات مترجمة أون لاين بجودة HD",
    fr: "AuraMovie | Regarder Films et Séries en Streaming VF/VOSTFR HD",
    en: "AuraMovie – Watch Movies & TV Series Online Free",
  });

  const description = pickLocale(locale, {
    ar: "شاهد أحدث الأفلام والمسلسلات الأجنبية والعالمية المترجمة بجودة عالية على موقع اورا موفي AuraMovie. تحديث يومي لأحدث العروض.",
    fr: "Regardez les derniers films et séries en streaming HD sur AuraMovie. Mise à jour quotidienne des dernières sorties, en VF et VOSTFR.",
    en: "Stream the latest movies and TV shows online on AuraMovie in high quality.",
  });

  return {
    title,
    description,
    metadataBase: new URL(baseUrl),
    other: {
      google: "notranslate",
    },
    alternates: {
      canonical: `${baseUrl}/${locale}`,
      languages: {
        // ملاحظة: خاص نديرو غير اللغات اللي عندها routes حقيقية (middleware.ts).
        // 'es' و 'de' تنحيو من هنا 7it ماكاينش صفحات ليهم، وكانو كيسببو hreflang errors
        // فـ Google Search Console (redirect ل 404).
        'ar': `${baseUrl}/ar`,
        'en': `${baseUrl}/en`,
        'fr': `${baseUrl}/fr`,
        'x-default': `${baseUrl}/ar`, // العربية هي اللغة الأم للموقع
      },
    },
    robots: {
      index: true,
      follow: true,
      googleBot: {
        index: true,
        follow: true,
        'max-video-preview': -1,
        'max-image-preview': 'large',
        'max-snippet': -1,
      },
    },
  };
}

export default async function RootLayout({
  children,
  params,
}: RootLayoutProps) {
  const { locale } = await params;
  const direction = locale === 'ar' ? 'rtl' : 'ltr';

  return (
    <html lang={locale} dir={direction} className="dark text-zinc-100" suppressHydrationWarning>
      <body className="bg-zinc-950 text-zinc-100 min-h-screen antialiased">
        {children}

        {/* كود AdSense */}
        <script
          async
          src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=ca-pub-8379415024436818"
          crossOrigin="anonymous"
        />
      </body>
    </html>
  );
}

interface RootLayoutProps {
  children: React.ReactNode;
  params: Promise<{ locale: string }>;
}