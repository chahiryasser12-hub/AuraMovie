import { discoverMovies, discoverSeries } from "@/lib/tmdb";
import { Header } from "@/components/layout/Header";
import { Footer } from "@/components/layout/Footer";
import { ComingSoonClientPage } from "./ComingSoonClientPage";

interface ComingSoonPageProps {
  params: Promise<{ locale: string }>;
}

export async function generateMetadata({ params }: ComingSoonPageProps) {
  const { locale } = await params;
  const title = locale === "ar" ? "قريباً - AuraMovie" : locale === "fr" ? "Bientôt - AuraMovie" : "Coming Soon - AuraMovie";
  return {
    title,
    description: "Watch the latest movie and anime trailers of 2026/Upcoming releases.",
  };
}

export default async function ComingSoonPage({ params }: ComingSoonPageProps) {
  const { locale } = await params;
  
  // الحصول على تاريخ اليوم بدقة
  const today = new Date();
  today.setHours(0, 0, 0, 0); // تصفير الوقت لمقارنة التواريخ فقط
  const todayStr = today.toISOString().split('T')[0];

  // 1. جلب الأعمال المستقبلية فقط مباشرة من TMDB باستخدام فلتر التاريخ الإيجابي gte
  const [moviesRes, animeRes] = await Promise.all([
    discoverMovies({
      "primary_release_date.gte": todayStr,
      sort_by: "popularity.desc",
      language: locale
    }),
    discoverSeries({
      with_genres: "16",
      with_original_language: "ja",
      "first_air_date.gte": todayStr,
      sort_by: "popularity.desc",
      language: locale
    })
  ]);

  const todayTime = today.getTime();

  // 2. فلترة صارمة إضافية (JS Post-Filter) لمنع تسرب أي عمل صدر قبل اليوم أو في نفس اليوم
  const upcomingMovies = (moviesRes.results || []).filter((m) => {
    if (!m.release_date) return false;
    const releaseTime = new Date(m.release_date).getTime();
    return releaseTime > todayTime; // يجب أن يكون تاريخ الإصدار في المستقبل حصراً
  });

  const upcomingAnime = (animeRes.results || []).filter((a) => {
    if (!a.first_air_date) return false;
    const airTime = new Date(a.first_air_date).getTime();
    return airTime > todayTime; // يجب أن يكون تاريخ العرض الأول في المستقبل حصراً
  });

  return (
    <div className="min-h-screen bg-zinc-950 flex flex-col justify-between">
      <Header />
      <ComingSoonClientPage 
        movies={upcomingMovies} 
        anime={upcomingAnime} 
        locale={locale} 
      />
      <Footer />
    </div>
  );
}