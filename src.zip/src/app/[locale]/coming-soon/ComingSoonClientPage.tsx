"use client";

import { useState } from "react";
import Image from "next/image";
import { MediaGrid } from "@/components/media/MediaGrid"; // السطر اللي كايحل المشكل
import { getImageUrl } from "@/lib/tmdb";
import { formatYear, cn } from "@/lib/utils";
import type { TMDBMovie, TMDBSeries } from "@/types/tmdb";

interface ComingSoonClientPageProps {
  movies: TMDBMovie[];
  anime: TMDBSeries[];
  locale: string;
}

export function ComingSoonClientPage({ movies, anime, locale }: ComingSoonClientPageProps) {
  const [activeTab, setActiveTab] = useState<"movies" | "anime">("movies");
  const [isOpen, setIsOpen] = useState(false);
  const [activeVideoKey, setActiveVideoKey] = useState<string | null>(null);
  const [loadingId, setLoadingId] = useState<number | null>(null);

  const isAr = locale === "ar";
  const isFr = locale === "fr";
  
  const title = isAr ? "قريباً / إصدارات 2026" : isFr ? "Bientôt / Sorties 2026" : "Coming Soon / 2026 Releases";
  const desc = isAr 
    ? "اكتشف أحدث العروض الدعائية الحصرية وتواريخ الإصدار للأفلام والأنميات القادمة." 
    : isFr 
    ? "Découvrez les dernières bandes-annonces exclusives et les dates de sortie des films et animes à venir." 
    : "Discover the latest exclusive trailers and release dates for highly anticipated upcoming movies and anime.";

  const items = activeTab === "movies" ? movies : anime;

  const handlePlayTrailer = async (id: number, mediaType: "movie" | "tv") => {
    setLoadingId(id);
    try {
      const res = await fetch(`/api/tmdb/details/${id}?type=${mediaType}`);
      if (!res.ok) throw new Error();
      
      const data = (await res.json()) as any;
      
      const videos = data.videos?.results || [];
      const trailer = videos.find((v: any) => v.type === "Trailer" && v.site === "YouTube") 
                   || videos.find((v: any) => v.site === "YouTube");
      
      if (trailer && trailer.key) {
        setActiveVideoKey(trailer.key);
        setIsOpen(true);
      } else {
        alert(isAr ? "المقطع الدعائي غير متوفر حالياً لهذا العمل." : isFr ? "Bande-annonce non disponible." : "Trailer not available for this title.");
      }
    } catch (err) {
      console.error(err);
    } finally {
      setLoadingId(null);
    }
  };

  return (
    <main className="pt-24 pb-16 max-w-[1400px] mx-auto px-4 md:px-8">
      <div className="mb-10 select-none flex flex-col md:flex-row md:items-center md:justify-between gap-6">
        <div>
          <h1 className="text-3xl md:text-4xl font-black text-white flex items-center gap-2 border-l-4 border-amber-400 pl-3 uppercase tracking-widest">
            ⏳ {title}
          </h1>
          <p className="text-zinc-550 text-sm mt-2 font-medium">
            {desc}
          </p>
        </div>

        <div className="flex bg-zinc-900 border border-zinc-800 rounded-xl p-1 self-start md:self-auto">
          <button
            onClick={() => setActiveTab("movies")}
            className={cn(
              "px-4 py-2 text-xs font-semibold rounded-lg transition-all duration-200 cursor-pointer",
              activeTab === "movies"
                ? "bg-amber-400 text-zinc-950 font-bold shadow-md"
                : "text-zinc-400 hover:text-white"
            )}
          >
            🎬 {isAr ? "أفلام قادمة" : "Upcoming Movies"}
          </button>
          <button
            onClick={() => setActiveTab("anime")}
            className={cn(
              "px-4 py-2 text-xs font-semibold rounded-lg transition-all duration-200 cursor-pointer",
              activeTab === "anime"
                ? "bg-amber-400 text-zinc-950 font-bold shadow-md"
                : "text-zinc-400 hover:text-white"
            )}
          >
            🌸 {isAr ? "أنمي قادم" : "Upcoming Anime"}
          </button>
        </div>
      </div>

      <MediaGrid>
        {items.map((item) => {
          const itemTitle = "title" in item ? item.title : item.name;
          const date = "release_date" in item ? item.release_date : item.first_air_date;
          const year = formatYear(date);
          const posterUrl = getImageUrl(item.poster_path, "w300");
          const mediaType = activeTab === "movies" ? "movie" : "tv";

          return (
            <div
              key={item.id}
              className="group relative flex flex-col bg-zinc-900/20 border border-zinc-900 hover:border-amber-400/40 rounded-2xl overflow-hidden p-2.5 transition-all duration-300"
            >
              <div className="relative aspect-[2/3] rounded-xl overflow-hidden bg-zinc-800">
                <Image
                  src={posterUrl}
                  alt={itemTitle}
                  fill
                  className="object-cover transition-transform duration-500 group-hover:scale-103"
                  unoptimized
                />

                <div className="absolute inset-0 bg-black/60 flex flex-col items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity p-2">
                  <button
                    onClick={() => handlePlayTrailer(item.id, mediaType)}
                    disabled={loadingId === item.id}
                    className="w-12 h-12 bg-amber-400 hover:bg-amber-500 text-zinc-950 rounded-full flex items-center justify-center shadow-2xl transition-all hover:scale-105 active:scale-95 cursor-pointer"
                  >
                    {loadingId === item.id ? (
                      <svg className="w-5 h-5 animate-spin" fill="none" viewBox="0 0 24 24">
                        <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" />
                        <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4z" />
                      </svg>
                    ) : (
                      <svg className="w-5 h-5 fill-current ml-0.5" viewBox="0 0 24 24">
                        <path d="M8 5v14l11-7z" />
                      </svg>
                    )}
                  </button>
                  <span className="text-[10px] text-white font-bold mt-2 select-none">
                    {isAr ? "شاهد الإعلان" : "Watch Trailer"}
                  </span>
                </div>
              </div>

              <div className="mt-2.5 px-1 flex-1 flex flex-col justify-between">
                <p className="text-white text-xs font-bold line-clamp-2 leading-snug group-hover:text-amber-400 transition-colors">
                  {itemTitle}
                </p>
                <div className="flex items-center justify-between text-[10px] text-zinc-550 font-bold mt-2 border-t border-zinc-900/60 pt-1.5">
                  <span className="uppercase tracking-wider">
                    {mediaType === "tv" ? "📺 Series" : "🎬 Movie"}
                  </span>
                  <span>{year}</span>
                </div>
              </div>
            </div>
          );
        })}
      </MediaGrid>

      {isOpen && activeVideoKey && (
        <div 
          onClick={() => { setIsOpen(false); setActiveVideoKey(null); }}
          className="fixed inset-0 bg-black/95 backdrop-blur-md z-[9999] flex items-center justify-center p-4 animate-fade-in"
        >
          <div 
            onClick={(e) => e.stopPropagation()} 
            className="relative w-full max-w-4xl aspect-video bg-black rounded-2xl overflow-hidden border border-zinc-800 shadow-2xl"
          >
            <button
              onClick={() => { setIsOpen(false); setActiveVideoKey(null); }}
              className="absolute top-3 right-3 md:top-4 md:right-4 z-50 bg-black/60 hover:bg-zinc-800 text-white rounded-full w-9 h-9 md:w-10 md:h-10 flex items-center justify-center border border-white/10 transition-transform hover:scale-105 active:scale-95 cursor-pointer"
            >
              ✕
            </button>
            <iframe
              src={`https://www.youtube.com/embed/${activeVideoKey}?autoplay=1&rel=0`}
              className="w-full h-full"
              allow="autoplay; encrypted-media"
              allowFullScreen
              title="Trailer Player"
            />
          </div>
        </div>
      )}
    </main>
  );
}