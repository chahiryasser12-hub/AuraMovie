import { Suspense } from "react";
import { notFound } from "next/navigation";
import Image from "next/image";
import Link from "next/link";
import { getMovieDetails, getSeriesDetails, getImageUrl } from "@/lib/tmdb";
import { Header } from "@/components/layout/Header";
import { Footer } from "@/components/layout/Footer";
import { VideoPlayer } from "@/components/player/VideoPlayer";
import { LocalVideoPlayer } from "@/components/player/LocalVideoPlayer";
import { MovieCard } from "@/components/media/MovieCard";
import { SeriesCard } from "@/components/media/SeriesCard";
import { WatchTracker } from "@/components/player/WatchTracker";
import { EndTimeClock } from "@/components/player/EndTimeClock";
import { getDictionary } from "@/lib/i18n";
import {
  formatDate,
  formatVoteAverage,
  getRatingColor,
  formatRuntime,
} from "@/lib/utils";

interface WatchPageProps {
  params: Promise<{ id: string; locale: string }>;
  searchParams: Promise<{ type?: string; season?: string; seasons?: string }>;
}

/**
 * دالة جلب الفيديوهات المرفوعة ذاتياً مع ترجماتها المخصصة.
 * يمكنك إضافة روابط الأفلام التي تملكها هنا لتعرض مباشرة بالترجمة العربية.
 */
async function getCustomSource(id: number, type: string, season: number, episode: number) {
  const hostedCatalog: Record<string, { videoUrl: string; subtitles: Array<{ src: string; label: string; srcLang: string; default?: boolean }> }> = {
    // مثال لفيلم يدوياً:
    // "movie-1139829": {
    //   videoUrl: "https://your-hosting-server.com/videos/sinners_2025.mp4",
    //   subtitles: [
    //     { src: "https://your-hosting-server.com/subtitles/sinners_arabic.vtt", label: "العربية", srcLang: "ar", default: true }
    //   ]
    // }
  };

  const key = type === "tv" ? `tv-${id}-s${season}-e${episode}` : `movie-${id}`;
  return hostedCatalog[key] || null;
}

export async function generateMetadata({
  params,
  searchParams,
}: WatchPageProps) {
  const { id, locale } = await params;
  const { type = "movie" } = await searchParams;
  try {
    // نجلب البيانات باللغة الإنجليزية دائماً للميتا داتا لضمان بقاء العناوين واضحة
    const media =
      type === "tv"
        ? await getSeriesDetails(parseInt(id), "en")
        : await getMovieDetails(parseInt(id), "en");
    
    const isMovie = "title" in media;
    // نفضل الاسم الإنجليزي المترجم title/name على الاسم الأصلي لمنع الحروف اليابانية
    const englishTitle = isMovie 
      ? (media as any).title || (media as any).original_title 
      : (media as any).name || (media as any).original_name;
    
    const dateField = isMovie ? (media as any).release_date : (media as any).first_air_date;
    const year = dateField ? dateField.slice(0, 4) : "";

    let pageTitle = `Watch ${englishTitle} (${year}) – AuraMovie`;
    if (locale === "ar") {
      pageTitle = isMovie 
        ? `مشاهدة فيلم "${englishTitle} ${year}" مترجم – AuraMovie`
        : `مشاهدة مسلسل "${englishTitle} ${year}" مترجم – AuraMovie`;
    } else if (locale === "fr") {
      pageTitle = isMovie
        ? `Regarder le film ${englishTitle} (${year}) en streaming VF – AuraMovie`
        : `Regarder la série ${englishTitle} (${year}) en streaming VF – AuraMovie`;
    }

    return { title: pageTitle };
  } catch {
    return { title: "Watch – AuraMovie" };
  }
}

async function WatchPageContent({
  id,
  type,
  season,
  totalSeasons,
  locale,
}: {
  id: string;
  type: string;
  season: number;
  totalSeasons: number;
  locale: string;
}) {
  const mediaType = type === "tv" ? "tv" : "movie";
  let mediaData;
  let mediaDataEn;
  
  try {
    // نجلب البيانات باللغتين: المحلية (للوصف والترجمات) والإنجليزية (لضمان الاسم الإنجليزي)
    if (locale !== "en") {
      const [locData, enData] = await Promise.all([
        mediaType === "tv" ? getSeriesDetails(parseInt(id), locale) : getMovieDetails(parseInt(id), locale),
        mediaType === "tv" ? getSeriesDetails(parseInt(id), "en") : getMovieDetails(parseInt(id), "en"),
      ]);
      mediaData = locData;
      mediaDataEn = enData;
    } else {
      mediaData =
        mediaType === "tv"
          ? await getSeriesDetails(parseInt(id), "en")
          : await getMovieDetails(parseInt(id), "en");
      mediaDataEn = mediaData;
    }
  } catch {
    notFound();
  }

  const dict = getDictionary(locale);

  const isMovie = "title" in mediaDataEn;
  // هنا نعتمد بشكل كامل على الحزمة الإنجليزية مع إعطاء الأولوية لـ title/name
  const englishTitle = isMovie 
    ? (mediaDataEn as any).title || (mediaDataEn as any).original_title 
    : (mediaDataEn as any).name || (mediaDataEn as any).original_name;

  const posterUrl = getImageUrl(mediaData.poster_path, "w300");
  const backdropUrl = getImageUrl(mediaData.backdrop_path, "w780");
  const rating = formatVoteAverage(mediaData.vote_average);

  const calculatedRuntime = isMovie 
    ? (mediaData as { runtime: number | null }).runtime || 0
    : 45;

  const similar = (mediaData.similar?.results || []).slice(0, 6);

  // التحقق من وجود مصدر فيديو محلي مخصص للفيلم أو المسلسل
  const customSource = await getCustomSource(parseInt(id), mediaType, season, 1);

  return (
    <div className="min-h-screen bg-zinc-950">
      <Header />
      
      <WatchTracker 
        id={parseInt(id)} 
        title={englishTitle} 
        posterPath={mediaData.poster_path} 
        type={mediaType} 
        season={season} 
      />

      <main className="pt-16 max-w-[1400px] mx-auto px-4 md:px-8 pb-16">
        {/* Breadcrumb */}
        <div className="flex items-center gap-2 py-4 text-sm text-zinc-500">
          <Link href={`/${locale}`} className="hover:text-white transition-colors">
            {dict.home}
          </Link>
          <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
          </svg>
          <Link
            href={mediaType === "tv" ? `/${locale}/series` : `/${locale}/movies`}
            className="hover:text-white transition-colors"
          >
            {mediaType === "tv" ? dict.series : dict.movies}
          </Link>
          <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
          </svg>
          <span className="text-zinc-350 line-clamp-1">{englishTitle}</span>
        </div>

        <div className="flex flex-col xl:flex-row gap-8">
          {/* Main - Player */}
          <div className="flex-1 min-w-0">
            <h1 className="text-2xl md:text-3xl font-black text-white mb-4">
              {englishTitle}
            </h1>
            {customSource ? (
              <LocalVideoPlayer
                videoUrl={customSource.videoUrl}
                tmdbId={parseInt(id)}
                mediaType={mediaType}
                title={englishTitle}
                subtitles={customSource.subtitles}
                season={season}
                episode={1}
              />
            ) : (
              <VideoPlayer
                tmdbId={parseInt(id)}
                mediaType={mediaType === "tv" ? "tv" : "movie"}
                title={englishTitle}
                season={season}
                episode={1}
                totalSeasons={
                  mediaType === "tv"
                    ? totalSeasons || (mediaData as { number_of_seasons: number }).number_of_seasons
                    : undefined
                }
                seasonsData={mediaType === "tv" ? (mediaData as any).seasons : undefined}
              />
            )}
          </div>

          {/* Sidebar - Media Info */}
          <div className="xl:w-80 flex flex-col gap-4">
            {/* Dynamic End-Time calculator */}
            {calculatedRuntime > 0 && <EndTimeClock runtimeMinutes={calculatedRuntime} />}

            {/* Poster card */}
            <div className="flex gap-4 bg-zinc-900/60 border border-zinc-800 rounded-2xl p-4">
              <div className="relative w-24 aspect-[2/3] rounded-xl overflow-hidden flex-shrink-0 shadow-lg">
                <Image
                  src={posterUrl}
                  alt={englishTitle}
                  fill
                  className="object-cover"
                  unoptimized
                />
              </div>
              <div className="flex flex-col gap-1.5 min-w-0">
                <h2 className="text-white font-bold text-sm leading-tight">{englishTitle}</h2>
                <div className="flex items-center gap-1">
                  <svg className="w-3.5 h-3.5 text-amber-400 fill-current" viewBox="0 0 24 24">
                    <path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z" />
                  </svg>
                  <span className={`text-sm font-bold ${getRatingColor(mediaData.vote_average)}`}>
                    {rating}
                  </span>
                </div>
                <p className="text-zinc-550 text-xs">
                  {isMovie
                    ? formatDate((mediaData as { release_date: string }).release_date)
                    : formatDate((mediaData as { first_air_date: string }).first_air_date)}
                </p>
                {isMovie && (mediaData as { runtime: number | null }).runtime && (
                  <p className="text-zinc-550 text-xs">
                    {formatRuntime((mediaData as { runtime: number | null }).runtime)}
                  </p>
                )}
                {!isMovie && (
                  <p className="text-zinc-550 text-xs">
                    {(mediaData as { number_of_seasons: number }).number_of_seasons} {dict.seasons}
                  </p>
                )}
                <Link
                  href={`/${locale}/${mediaType === "tv" ? "series" : "movies"}/${id}`}
                  className="text-amber-400 text-xs hover:text-amber-300 transition-colors mt-1 flex items-center gap-1"
                >
                  {dict.viewDetails}
                  <svg className="w-3 h-3" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
                  </svg>
                </Link>
              </div>
            </div>

            {/* Overview */}
            <div className="bg-zinc-900/60 border border-zinc-800 rounded-2xl p-4">
              <h3 className="text-sm font-semibold text-zinc-300 mb-2">Overview</h3>
              <p className="text-xs text-zinc-550 leading-relaxed line-clamp-4">
                {mediaData.overview}
              </p>
            </div>

            {/* Backdrop preview */}
            {mediaData.backdrop_path && (
              <div className="relative aspect-video rounded-xl overflow-hidden">
                <Image
                  src={backdropUrl}
                  alt={englishTitle}
                  fill
                  className="object-cover"
                  unoptimized
                />
                <div className="absolute inset-0 bg-black/40" />
              </div>
            )}
          </div>
        </div>

        {/* Similar content */}
        {similar.length > 0 && (
          <section className="mt-12 border-t border-zinc-800 pt-8">
            <h2 className="text-xl font-bold text-white mb-5 border-l-4 border-amber-400 pl-3 uppercase tracking-wider">
              {dict.moreLikeThis}
            </h2>
            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-4">
              {similar.map((item) =>
                mediaType === "tv" ? (
                  <SeriesCard key={item.id} series={item as Parameters<typeof SeriesCard>[0]['series']} />
                ) : (
                  <MovieCard key={item.id} movie={item as Parameters<typeof MovieCard>[0]['movie']} />
                )
              )}
            </div>
          </section>
        )}
      </main>

      <Footer />
    </div>
  );
}

export default async function WatchPage({ params, searchParams }: WatchPageProps) {
  const { id, locale } = await params;
  const { type = "movie", season = "1", seasons = "1" } = await searchParams;

  return (
    <Suspense
      fallback={
        <div className="min-h-screen bg-zinc-950 flex items-center justify-center">
          <div className="text-center flex flex-col items-center gap-4">
            <div className="w-20 h-20 rounded-full bg-amber-400/10 flex items-center justify-center">
              <svg className="w-10 h-10 text-amber-400 fill-current animate-pulse" viewBox="0 0 24 24">
                <path d="M8 5v14l11-7z" />
              </svg>
            </div>
            <p className="text-zinc-400 font-bold">{getDictionary(locale).loadingPlayer}</p>
          </div>
        </div>
      }
    >
      <WatchPageContent
        id={id}
        type={type}
        season={parseInt(season)}
        totalSeasons={parseInt(seasons)}
        locale={locale}
      />
    </Suspense>
  );
}