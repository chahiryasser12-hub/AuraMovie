import { Suspense } from "react";
import { notFound } from "next/navigation";
import Image from "next/image";
import Link from "next/link";
import { getSeriesDetails, getImageUrl, getFranchisePack } from "@/lib/tmdb";
import { Header } from "@/components/layout/Header";
import { Footer } from "@/components/layout/Footer";
import { FranchiseSection } from "@/components/sections/FranchiseSection";
import { Button } from "@/components/ui/Button";
import { WatchlistButton } from "@/components/ui/WatchlistButton";
import { ShareButton } from "@/components/ui/ShareButton";
import { JsonLd } from "@/components/seo/JsonLd";
import { buildLocalizedTitle, buildLocalizedDescription, buildSeriesJsonLd, buildBreadcrumbJsonLd, buildFAQJsonLd, cleanJsonLd } from "@/lib/seo";
import { getDictionary, pickLocale } from "@/lib/i18n";
import { formatDate, formatVoteAverage, slugify } from "@/lib/utils";
import { DetailPageSkeleton } from "@/components/ui/Skeleton";
import { db } from "@/db";
import { comments } from "@/db/schema";
import { eq, and, desc } from "drizzle-orm";
import { CommentsSection } from "@/components/media/CommentsSection";

interface SeriesPageProps {
  params: Promise<{ id: string; locale: string }>;
}

export async function generateMetadata({ params }: SeriesPageProps) {
  const { id, locale } = await params;
  const baseUrl = process.env.NEXT_PUBLIC_SITE_URL || "https://auramovie.dpdns.org";
  
  try {
    const seriesId = parseInt(id, 10);
    const series = await getSeriesDetails(seriesId, locale);
    const englishName = series.original_name || series.name;
    const year = series.first_air_date ? series.first_air_date.slice(0, 4) : "";
    const slug = slugify(englishName);
    
    const pageTitle = buildLocalizedTitle(englishName, year, locale, "tv");
    const pageDesc = buildLocalizedDescription(series.overview, englishName, locale);
    const imageUrl = getImageUrl(series.backdrop_path, "w780");

    return {
      title: pageTitle,
      description: pageDesc,
      openGraph: {
        title: pageTitle,
        description: pageDesc,
        url: `${baseUrl}/${locale}/series/${seriesId}-${slug}`,
        siteName: 'AuraMovie',
        images: [{ url: imageUrl, width: 780, height: 439, alt: englishName }],
        locale: locale,
        type: 'video.tv_show',
      },
      twitter: {
        card: 'summary_large_image',
        title: pageTitle,
        description: pageDesc,
        images: [imageUrl],
      },
      alternates: {
        canonical: `${baseUrl}/${locale}/series/${seriesId}-${slug}`,
        languages: {
          ar: `${baseUrl}/ar/series/${seriesId}-${slug}`,
          en: `${baseUrl}/en/series/${seriesId}-${slug}`,
          fr: `${baseUrl}/fr/series/${seriesId}-${slug}`,
        }
      }
    };
  } catch { return { title: "Series – AuraMovie" }; }
}

async function SeriesPageContent({ id, locale }: { id: string; locale: string }) {
  const seriesId = parseInt(id, 10);
  let series;
  try { series = await getSeriesDetails(seriesId, locale); } catch { notFound(); }

  const dict = getDictionary(locale);
  const englishName = series.original_name || series.name;
  const year = series.first_air_date ? series.first_air_date.slice(0, 4) : "N/A";
  const slug = slugify(englishName);

  const backdropUrl = getImageUrl(series.backdrop_path, "w780");
  const posterUrl = getImageUrl(series.poster_path, "w400");
  const franchiseItems = await getFranchisePack(englishName, "en");
  const cast = series.credits?.cast?.slice(0, 12) || [];

  const breadcrumbSchema = cleanJsonLd(
    buildBreadcrumbJsonLd([
      { name: dict.home, item: `/${locale}` },
      { name: dict.series, item: `/${locale}/series` },
      { name: englishName, item: `/${locale}/series/${seriesId}-${slug}` }
    ])
  );
  
  const faqSchema = cleanJsonLd(buildFAQJsonLd(englishName, "tv", locale));

  const seriesComments = await db.select()
    .from(comments)
    .where(and(eq(comments.tmdbId, seriesId), eq(comments.mediaType, "tv")))
    .orderBy(desc(comments.createdAt));

  return (
    <div className="min-h-screen bg-zinc-950 text-zinc-100">
      <JsonLd data={cleanJsonLd(buildSeriesJsonLd(series))} />
      <JsonLd data={breadcrumbSchema} />
      <JsonLd data={faqSchema} />
      <Header />

      <div className="pt-24 pb-6 bg-zinc-900/40 border-b border-zinc-900/60">
        <div className="max-w-[1400px] mx-auto px-4 md:px-8 flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
          <div>
            <h1 className="text-3xl md:text-5xl font-black text-white tracking-tight leading-tight">
               {pickLocale(locale, {
                 ar: `مشاهدة مسلسل ${englishName} مترجم كامل`,
                 fr: `Regarder ${englishName} en streaming`,
                 en: englishName,
               })}
            </h1>
            <div className="flex flex-wrap items-center gap-x-3 gap-y-1 text-sm text-zinc-400 mt-2 font-medium">
              <span className="text-amber-400">{year}</span>
              <span>•</span>
              {series.genres?.map((g) => (
                <Link key={g.id} href={`/${locale}/genres/${g.id}?type=tv`} className="hover:text-white transition-colors">
                  {g.name}
                </Link>
              ))}
            </div>
          </div>
          <div className="bg-amber-400 text-zinc-950 font-black px-3 py-1 rounded-lg text-lg">
            {formatVoteAverage(series.vote_average)}
          </div>
        </div>
      </div>

      <div className="max-w-[1400px] mx-auto px-4 md:px-8 py-8">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
          <div className="md:col-span-1 hidden md:block relative aspect-[2/3] rounded-xl overflow-hidden border border-zinc-800">
            <Image src={posterUrl} alt={englishName} fill priority className="object-cover" unoptimized />
          </div>
          <div className="md:col-span-3 relative aspect-video bg-zinc-900 rounded-xl overflow-hidden border border-zinc-800 shadow-lg">
            <Image src={backdropUrl} alt={englishName} fill priority className="object-cover" unoptimized />
            <div className="absolute inset-0 bg-black/40 flex items-center justify-center">
              <Link href={`/${locale}/watch/${series.id}?type=tv&seasons=${series.number_of_seasons}`}>
                <div className="w-20 h-20 bg-amber-400 hover:bg-amber-500 text-zinc-950 rounded-full flex items-center justify-center shadow-xl transition-all hover:scale-105 cursor-pointer animate-pulse"><svg className="w-10 h-10 fill-current ml-1" viewBox="0 0 24 24"><path d="M8 5v14l11-7z" /></svg></div>
              </Link>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 mt-8">
          <div className="lg:col-span-2">
            <h2 className="text-white font-bold text-lg mb-2">
              {pickLocale(locale, {
                ar: 'قصة المسلسل وتفاصيل العرض',
                fr: 'Synopsis de la série',
                en: 'Series Storyline',
              })}
            </h2>
            <p className="text-zinc-300 text-base leading-relaxed mb-6">{series.overview}</p>
            
            <div className="mt-6 p-4 bg-zinc-900/30 border border-zinc-800/50 rounded-xl mb-6">
              <p className="text-xs text-zinc-500 leading-relaxed text-justify">
                {pickLocale(locale, {
                  ar: `تابع جميع مواسم وحلقات مسلسل ${englishName} مترجم للعربية. الكلمات الدلالية: مشاهدة مسلسل ${englishName} ايجي بست، تحميل حلقات ${englishName} سيما كلوب، فاصل اعلاني، ماي سيما، مسلسلات ${year} اون لاين.`,
                  fr: `Suivez toutes les saisons et tous les épisodes de la série ${englishName} en streaming VF. Regardez ${englishName} en HD gratuitement, séries ${year} en streaming en ligne sur AuraMovie.`,
                  en: `Watch ${englishName} full series online in HD. Download ${englishName} all episodes free streaming. AuraMovie is your best choice to stream TV shows.`,
                })}
              </p>
            </div>

            {cast.length > 0 && (
              <div className="mb-6">
                <h3 className="text-white font-bold text-lg mb-4">{dict.topCast}</h3>
                <div className="flex gap-4 overflow-x-auto scrollbar-hide pb-2">
                  {cast.map((actor: any) => (
                    <Link key={actor.id} href={`/${locale}/people/${actor.id}`} className="flex flex-col items-center gap-2 group min-w-[80px]">
                      <div className="relative w-16 h-16 rounded-full overflow-hidden bg-zinc-800 border-2 border-transparent group-hover:border-amber-400 transition-all">
                        <Image src={getImageUrl(actor.profile_path, "w200")} alt={actor.name} fill className="object-cover" unoptimized />
                      </div>
                      <span className="text-[10px] text-zinc-300 text-center font-bold group-hover:text-amber-400">{actor.name}</span>
                    </Link>
                  ))}
                </div>
              </div>
            )}

            <CommentsSection 
              tmdbId={seriesId} 
              mediaType="tv" 
              initialComments={seriesComments} 
              locale={locale} 
            />
          </div>

          <div className="lg:col-span-1 flex flex-col gap-4">
            <Link href={`/${locale}/watch/${series.id}?type=tv&seasons=${series.number_of_seasons}`} className="w-full">
              <Button size="lg" className="w-full justify-center gap-2"><svg className="w-5 h-5 fill-current" viewBox="0 0 24 24"><path d="M8 5v14l11-7z" /></svg>{dict.watchStreamingNow}</Button>
            </Link>
            <WatchlistButton id={series.id} title={englishName} posterPath={series.poster_path} type="tv" />
            <ShareButton title={englishName} path={`/${locale}/series/${seriesId}-${slug}`} />
          </div>
        </div>

        <FranchiseSection items={franchiseItems} currentId={series.id} />

        {series.seasons && (
          <section className="py-10 border-t border-zinc-900 mt-12">
            <h2 className="text-xl font-black text-white mb-6 border-l-4 border-amber-400 pl-3 uppercase tracking-wider">{dict.seasons}</h2>
            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-6 gap-4">
              {series.seasons.filter(s => s.season_number > 0).map((season) => (
                <Link key={season.id} href={`/${locale}/watch/${series.id}?type=tv&season=${season.season_number}`} className="group bg-zinc-900/40 p-2 rounded-xl border border-zinc-800 hover:border-amber-400 transition-all">
                  <div className="relative aspect-[2/3] rounded-lg overflow-hidden mb-2">
                    <Image src={getImageUrl(season.poster_path, "w300")} alt={season.name} fill className="object-cover" unoptimized loading="lazy" />
                  </div>
                  <p className="text-white text-xs font-bold truncate">{season.name}</p>
                  <p className="text-zinc-550 text-[10px] uppercase font-bold">{season.episode_count} Episodes</p>
                </Link>
              ))}
            </div>
          </section>
        )}
      </div>
      <Footer />
    </div>
  );
}

export default async function SeriesPage({ params }: SeriesPageProps) {
  const { id, locale } = await params;
  return (
    <Suspense fallback={<DetailPageSkeleton />}>
      <SeriesPageContent id={id} locale={locale} />
    </Suspense>
  );
}