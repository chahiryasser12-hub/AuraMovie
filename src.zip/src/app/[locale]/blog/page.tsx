import { db } from "@/db";
import { articles } from "@/db/schema";
import { desc, eq } from "drizzle-orm";
import { Header } from "@/components/layout/Header";
import { Footer } from "@/components/layout/Footer";
import Link from "next/link";
import Image from "next/image";

export const metadata = {
  title: "Blog & News – AuraMovie",
  description: "أحدث أخبار الأفلام، المسلسلات، والأنمي ومواعيد الإصدار حصرياً على AuraMovie.",
};

export default async function BlogPage({ params }: { params: Promise<{ locale: string }> }) {
  const { locale } = await params;
  
  const posts = await db.select()
    .from(articles)
    .where(eq(articles.locale, locale))
    .orderBy(desc(articles.publishedAt));

  return (
    <div className="min-h-screen bg-zinc-950 flex flex-col justify-between">
      <Header />
      <main className="pt-28 pb-16 flex-1 max-w-[1400px] mx-auto px-4 md:px-8 w-full">
        <div className="mb-10">
          <h1 className="text-3xl md:text-5xl font-black text-white border-l-4 border-amber-400 pl-3 uppercase">
            {locale === "ar" ? "أخبار ومقالات" : "AuraMovie Blog"}
          </h1>
          <p className="text-zinc-500 mt-2">
            {locale === "ar" ? "تعرف على أحدث مواعيد الصدور والتسريبات." : "Latest news, release dates, and leaks."}
          </p>
        </div>

        {posts.length > 0 ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {posts.map((post) => (
              <Link key={post.id} href={`/${locale}/blog/${post.slug}`} className="group bg-zinc-900/40 border border-zinc-800 rounded-2xl overflow-hidden hover:border-amber-400/50 transition-all">
                <div className="relative aspect-video bg-zinc-800 overflow-hidden">
                  {post.imageUrl ? (
                    <Image src={post.imageUrl} alt={post.title} fill className="object-cover group-hover:scale-105 transition-transform duration-500" unoptimized />
                  ) : (
                    <div className="w-full h-full flex items-center justify-center text-4xl">📰</div>
                  )}
                </div>
                <div className="p-5">
                  <p className="text-[10px] text-amber-400 font-bold mb-2 uppercase tracking-widest">
                    {new Date(post.publishedAt).toLocaleDateString(locale)}
                  </p>
                  <h2 className="text-white font-bold text-lg leading-snug line-clamp-2 group-hover:text-amber-400 transition-colors">
                    {post.title}
                  </h2>
                  <p className="text-zinc-500 text-sm mt-3 line-clamp-3">
                    {post.content.replace(/<[^>]*>?/gm, '')}
                  </p>
                </div>
              </Link>
            ))}
          </div>
        ) : (
          <div className="text-center py-20 bg-zinc-900/20 border border-zinc-800 rounded-2xl">
            <div className="text-5xl mb-4">✍️</div>
            <h2 className="text-white font-bold text-xl">{locale === "ar" ? "لا توجد مقالات حالياً" : "No articles yet"}</h2>
          </div>
        )}
      </main>
      <Footer />
    </div>
  );
}