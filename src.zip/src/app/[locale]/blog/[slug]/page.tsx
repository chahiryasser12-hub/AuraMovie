import { db } from "@/db";
import { articles } from "@/db/schema";
import { eq } from "drizzle-orm";
import { Header } from "@/components/layout/Header";
import { Footer } from "@/components/layout/Footer";
import { notFound } from "next/navigation";
import Image from "next/image";
import { ShareButton } from "@/components/ui/ShareButton";

export async function generateMetadata({ params }: { params: Promise<{ slug: string, locale: string }> }) {
  const { slug } = await params;
  
  // الطريقة العادية والصحيحة لجلب البيانات بدون أخطاء Drizzle
  const posts = await db.select().from(articles).where(eq(articles.slug, slug)).limit(1);
  const post = posts[0];
  
  if (!post) return { title: "Blog - AuraMovie" };
  
  return {
    title: `${post.title} – AuraMovie`,
    description: post.content.substring(0, 150),
  };
}

export default async function BlogPostPage({ params }: { params: Promise<{ slug: string, locale: string }> }) {
  const { slug, locale } = await params;
  
  const posts = await db.select().from(articles).where(eq(articles.slug, slug)).limit(1);
  const post = posts[0];

  if (!post) notFound();

  return (
    <div className="min-h-screen bg-zinc-950 flex flex-col">
      <Header />
      <main className="flex-1 pt-28 pb-16 max-w-4xl mx-auto px-4 md:px-8 w-full">
        <div className="mb-8">
          <p className="text-amber-400 font-bold text-sm mb-3 uppercase tracking-wider">
            {new Date(post.publishedAt).toLocaleDateString(locale, { year: 'numeric', month: 'long', day: 'numeric' })}
          </p>
          <h1 className="text-3xl md:text-5xl font-black text-white leading-tight mb-6">
            {post.title}
          </h1>
          <ShareButton title={post.title} path={`/${locale}/blog/${slug}`} />
        </div>

        {post.imageUrl && (
          <div className="relative w-full aspect-video rounded-3xl overflow-hidden mb-10 shadow-2xl border border-zinc-800">
            <Image src={post.imageUrl} alt={post.title} fill className="object-cover" unoptimized priority />
          </div>
        )}

        <div className="prose prose-invert prose-amber max-w-none text-zinc-300 leading-loose text-lg whitespace-pre-wrap">
          {post.content}
        </div>
      </main>
      <Footer />
    </div>
  );
}