"use client";

import { useState, useEffect, useCallback, useRef, Suspense } from "react";
import { useSearchParams, useRouter } from "next/navigation";
import Image from "next/image";
import Link from "next/link";
import { Header } from "@/components/layout/Header";
import { Footer } from "@/components/layout/Footer";
import { MovieCard } from "@/components/media/MovieCard";
import { SeriesCard } from "@/components/media/SeriesCard";
import { MediaGrid } from "@/components/media/MediaGrid";
import { Button } from "@/components/ui/Button";
import { getImageUrl } from "@/lib/tmdb";
import type { TMDBSearchMultiResult, TMDBPaginatedResponse } from "@/types/tmdb";
import { cn, sortSmartResults } from "@/lib/utils";

type FilterType = "multi" | "movie" | "tv" | "person";

const DEBOUNCE_MS = 400;
const MIN_QUERY_LENGTH = 2;

function SearchContent() {
  const searchParams = useSearchParams();
  const router = useRouter();
  const initialQuery = searchParams.get("q") || "";

  const [query, setQuery] = useState(initialQuery);
  const [inputValue, setInputValue] = useState(initialQuery);
  const [results, setResults] = useState<TMDBSearchMultiResult[]>([]);
  const [loading, setLoading] = useState(false);
  const [totalResults, setTotalResults] = useState(0);
  const [page, setPage] = useState(1);
  const [totalPages, setTotalPages] = useState(0);
  const [filterType, setFilterType] = useState<FilterType>("multi");
  const [loadingMore, setLoadingMore] = useState(false);

  const debounceTimer = useRef<ReturnType<typeof setTimeout> | null>(null);
  const abortRef = useRef<AbortController | null>(null);

  const doSearch = useCallback(
    async (q: string, p: number, type: FilterType, reset: boolean) => {
      if (!q.trim()) {
        setResults([]);
        setTotalResults(0);
        return;
      }

      abortRef.current?.abort();
      const controller = new AbortController();
      abortRef.current = controller;

      if (reset) setLoading(true);
      else setLoadingMore(true);

      try {
        const res = await fetch(
          `/api/tmdb/search?q=${encodeURIComponent(q)}&type=${type}&page=${p}`,
          { signal: controller.signal }
        );
        const data = (await res.json()) as TMDBPaginatedResponse<TMDBSearchMultiResult>;
        
        const filtered =
          type === "multi"
            ? (data.results || []).filter(
                (r: TMDBSearchMultiResult) => r.media_type !== "person"
              )
            : data.results || [];

        const sorted = sortSmartResults(filtered, q);

        if (reset) {
          setResults(sorted);
        } else {
          setResults((prev) => [...prev, ...sorted]);
        }
        setTotalResults(data.total_results || 0);
        setTotalPages(data.total_pages || 0);
      } catch (err) {
        if ((err as Error).name !== "AbortError") {
          setResults([]);
          setTotalResults(0);
        }
      } finally {
        setLoading(false);
        setLoadingMore(false);
      }
    },
    []
  );

  useEffect(() => {
    if (initialQuery) {
      doSearch(initialQuery, 1, filterType, true);
    }
  }, []);

  useEffect(() => {
    if (debounceTimer.current) clearTimeout(debounceTimer.current);

    const trimmed = inputValue.trim();
    if (trimmed.length < MIN_QUERY_LENGTH) {
      if (trimmed.length === 0) {
        setResults([]);
        setTotalResults(0);
        setQuery("");
      }
      return;
    }

    debounceTimer.current = setTimeout(() => {
      setQuery(trimmed);
      setPage(1);
      router.replace(`/search?q=${encodeURIComponent(trimmed)}`, { scroll: false });
      doSearch(trimmed, 1, filterType, true);
    }, DEBOUNCE_MS);

    return () => {
      if (debounceTimer.current) clearTimeout(debounceTimer.current);
    };
  }, [inputValue]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (debounceTimer.current) clearTimeout(debounceTimer.current);
    if (inputValue.trim()) {
      setQuery(inputValue.trim());
      setPage(1);
      router.replace(`/search?q=${encodeURIComponent(inputValue.trim())}`, { scroll: false });
      doSearch(inputValue.trim(), 1, filterType, true);
    }
  };

  const handleFilterChange = (type: FilterType) => {
    setFilterType(type);
    setPage(1);
    if (query) {
      doSearch(query, 1, type, true);
    }
  };

  const handleLoadMore = () => {
    const nextPage = page + 1;
    setPage(nextPage);
    doSearch(query, nextPage, filterType, false);
  };

  return (
    <div className="min-h-screen bg-zinc-950">
      <Header />
      <main className="pt-20 pb-16 max-w-[1400px] mx-auto px-4 md:px-8">
        <div className="py-8">
          <h1 className="text-3xl md:text-4xl font-black text-white mb-6 border-l-4 border-amber-400 pl-3 uppercase tracking-widest">
            Search
          </h1>

          <form onSubmit={handleSubmit} className="flex gap-3 max-w-2xl">
            <div className="flex-1 flex items-center gap-2 bg-zinc-900 border border-zinc-700 rounded-xl px-4 py-3 focus-within:border-amber-400 transition-colors">
              {loading ? (
                <svg className="w-5 h-5 text-amber-400 flex-shrink-0 animate-spin" fill="none" viewBox="0 0 24 24">
                  <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" />
                  <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4z" />
                </svg>
              ) : (
                <svg
                  className="w-5 h-5 text-zinc-550 flex-shrink-0"
                  fill="none"
                  stroke="currentColor"
                  viewBox="0 0 24 24"
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth={2}
                    d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"
                  />
                </svg>
              )}
              <input
                type="text"
                value={inputValue}
                onChange={(e) => setInputValue(e.target.value)}
                placeholder="Search movies, TV series, actors..."
                className="flex-1 bg-transparent text-white placeholder-zinc-550 outline-none text-sm"
                autoFocus
              />
              {inputValue && (
                <button
                  type="button"
                  onClick={() => {
                    setInputValue("");
                    setResults([]);
                    setQuery("");
                    setTotalResults(0);
                  }}
                  className="text-zinc-550 hover:text-white transition-colors cursor-pointer"
                >
                  <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                  </svg>
                </button>
              )}
            </div>
            <Button type="submit" size="md">
              Search
            </Button>
          </form>

          {query && (
            <div className="flex items-center gap-3 mt-5">
              <span className="text-zinc-550 text-sm font-semibold">Filter:</span>
              {(["multi", "movie", "tv", "person"] as FilterType[]).map((t) => (
                <button
                  key={t}
                  onClick={() => handleFilterChange(t)}
                  className={cn(
                    "px-4 py-1.5 rounded-lg text-sm font-bold transition-all cursor-pointer",
                    filterType === t
                      ? "bg-amber-400 text-zinc-950"
                      : "bg-zinc-900 text-zinc-400 hover:text-white border border-zinc-800"
                  )}
                >
                  {t === "multi" ? "All" : t === "movie" ? "Movies" : t === "tv" ? "TV Series" : "Actors"}
                </button>
              ))}
              {totalResults > 0 && (
                <span className="text-zinc-550 text-sm ml-2 font-medium">
                  {totalResults.toLocaleString()} results
                </span>
              )}
            </div>
          )}
        </div>

        {loading ? (
          <MediaGrid loading={true} skeletonCount={12} />
        ) : results.length > 0 ? (
          <>
            <MediaGrid>
              {results.map((item) => {
                if (item.media_type === "movie" || (!item.media_type && "title" in item)) {
                  return (
                    <MovieCard
                      key={`movie-${item.id}`}
                      movie={{
                        id: item.id,
                        title: item.title || item.name || "Unknown",
                        original_title: item.title || "",
                        overview: item.overview || "",
                        poster_path: item.poster_path,
                        backdrop_path: item.backdrop_path || null,
                        release_date: item.release_date || "",
                        vote_average: item.vote_average || 0,
                        vote_count: 0,
                        popularity: item.popularity,
                        genre_ids: item.genre_ids || [],
                        adult: false,
                        original_language: "",
                        video: false,
                      }}
                    />
                  );
                } else if (item.media_type === "tv" || (!item.media_type && "name" in item)) {
                  return (
                    <SeriesCard
                      key={`tv-${item.id}`}
                      series={{
                        id: item.id,
                        name: item.name || item.title || "Unknown",
                        original_name: item.name || "",
                        overview: item.overview || "",
                        poster_path: item.poster_path,
                        backdrop_path: item.backdrop_path || null,
                        first_air_date: item.first_air_date || "",
                        vote_average: item.vote_average || 0,
                        vote_count: 0,
                        popularity: item.popularity,
                        genre_ids: item.genre_ids || [],
                        original_language: "",
                        origin_country: [],
                      }}
                    />
                  );
                } else if (item.media_type === "person") {
                  return (
                    <Link
                      key={`person-${item.id}`}
                      href={`/people/${item.id}`}
                      className="group flex flex-col gap-2.5 bg-zinc-900/40 border border-zinc-800/80 hover:border-amber-400/65 rounded-2xl overflow-hidden p-3 transition-all duration-300 hover:-translate-y-1"
                    >
                      <div className="relative aspect-[3/4] w-full rounded-xl overflow-hidden bg-zinc-800">
                        <img
                          src={getImageUrl(item.poster_path, "w300")}
                          alt={item.name}
                          className="object-cover w-full h-full transition-transform duration-300 group-hover:scale-103"
                          loading="lazy"
                        />
                      </div>
                      <div>
                        <h3 className="text-white text-xs md:text-sm font-bold truncate group-hover:text-amber-400 transition-colors">
                          {item.name}
                        </h3>
                        <p className="text-zinc-550 text-[10px] uppercase font-bold mt-1">
                          Actor
                        </p>
                      </div>
                    </Link>
                  );
                }
                return null;
              })}
            </MediaGrid>

            {page < totalPages && (
              <div className="flex justify-center mt-10">
                <Button
                  variant="secondary"
                  size="lg"
                  loading={loadingMore}
                  onClick={handleLoadMore}
                >
                  Load More
                </Button>
              </div>
            )}
          </>
        ) : query ? (
          <div className="flex flex-col items-center justify-center py-24 gap-4 text-center">
            <div className="text-6xl">🎬</div>
            <h2 className="text-xl font-bold text-white">No results found</h2>
            <p className="text-zinc-500 text-sm max-w-sm">
              We couldn&apos;t find anything for &ldquo;{query}&rdquo;. Try another term.
            </p>
          </div>
        ) : (
          <div className="flex flex-col items-center justify-center py-24 gap-4 text-center">
            <div className="text-6xl opacity-50">🔍</div>
            <h2 className="text-xl font-bold text-white">Search for anything</h2>
            <p className="text-zinc-550 text-sm">
              Find movies, TV series, actors and more
            </p>
          </div>
        )}
      </main>
      <Footer />
    </div>
  );
}

export default function SearchPage() {
  return (
    <Suspense fallback={<div className="min-h-screen bg-zinc-950" />}>
      <SearchContent />
    </Suspense>
  );
}