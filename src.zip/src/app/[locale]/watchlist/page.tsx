"use client";

import { useEffect, useState } from "react";
import { Header } from "@/components/layout/Header";
import { Footer } from "@/components/layout/Footer";
import { MovieCard } from "@/components/media/MovieCard";
import { SeriesCard } from "@/components/media/SeriesCard";
import { MediaGrid } from "@/components/media/MediaGrid";
import { Button } from "@/components/ui/Button";
import Link from "next/link";

interface WatchlistItem {
  id: number;
  title: string;
  posterPath: string | null;
  type: "movie" | "tv";
  addedAt: number;
}

export default function WatchlistPage() {
  const [watchlist, setWatchlist] = useState<WatchlistItem[]>([]);
  const [mounted, setMounted] = useState(false);

  const loadWatchlist = () => {
    try {
      const list = JSON.parse(localStorage.getItem("watchlist") || "[]");
      // Sort in order of newest added first
      const sorted = list.sort((a: any, b: any) => (b.addedAt || 0) - (a.addedAt || 0));
      setWatchlist(sorted);
    } catch (err) {
      console.error("Failed to load watchlist details", err);
    }
  };

  useEffect(() => {
    setMounted(true);
    loadWatchlist();

    // Listen to local watch updates to dynamically reload grid listings
    window.addEventListener("watchlist-updated", loadWatchlist);
    return () => window.removeEventListener("watchlist-updated", loadWatchlist);
  }, []);

  if (!mounted) {
    return (
      <div className="min-h-screen bg-zinc-950">
        <Header />
        <main className="pt-24 pb-16 max-w-[1400px] mx-auto px-4 md:px-8" />
        <Footer />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-zinc-950 flex flex-col justify-between">
      <Header />
      
      <main className="pt-24 pb-16 flex-1 max-w-[1400px] mx-auto px-4 md:px-8 w-full">
        {/* Coordinated Gold Border Header */}
        <div className="mb-8 select-none">
          <h1 className="text-3xl md:text-4xl font-black text-white border-l-4 border-amber-400 pl-3 uppercase tracking-widest">
            My Watchlist
          </h1>
          <p className="text-zinc-500 text-xs font-semibold mt-2.5">
            Your collection of curated films and television series saved to watch next.
          </p>
        </div>

        {watchlist.length > 0 ? (
          <MediaGrid>
            {watchlist.map((item) => {
              if (item.type === "tv") {
                return (
                  <SeriesCard
                    key={`tv-${item.id}`}
                    series={{
                      id: item.id,
                      name: item.title,
                      original_name: item.title,
                      overview: "",
                      poster_path: item.posterPath,
                      backdrop_path: null,
                      first_air_date: "",
                      vote_average: 0,
                      vote_count: 0,
                      popularity: 0,
                      genre_ids: [],
                      original_language: "",
                      origin_country: [],
                    }}
                  />
                );
              } else {
                return (
                  <MovieCard
                    key={`movie-${item.id}`}
                    movie={{
                      id: item.id,
                      title: item.title,
                      original_title: item.title,
                      overview: "",
                      poster_path: item.posterPath,
                      backdrop_path: null,
                      release_date: "",
                      vote_average: 0,
                      vote_count: 0,
                      popularity: 0,
                      genre_ids: [],
                      adult: false,
                      original_language: "",
                      video: false,
                    }}
                  />
                );
              }
            })}
          </MediaGrid>
        ) : (
          /* Empty watchlist UI state block */
          <div className="flex flex-col items-center justify-center py-28 gap-4 text-center select-none animate-fade-in">
            <div className="text-5xl bg-zinc-900 border border-zinc-800 w-16 h-16 rounded-2xl flex items-center justify-center shadow-lg">
              ❤️
            </div>
            <h2 className="text-xl font-bold text-white mt-2">Your Watchlist is Empty</h2>
            <p className="text-zinc-550 text-xs font-medium max-w-sm leading-relaxed">
              Explore trending titles on the homepage and click the &ldquo;My List&rdquo; button to save them to your watchlist.
            </p>
            <Link href="/" className="mt-4">
              <Button size="md">
                Browse Masterpieces
              </Button>
            </Link>
          </div>
        )}
      </main>

      <Footer />
    </div>
  );
}