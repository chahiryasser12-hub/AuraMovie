import { Suspense } from "react";
import { notFound } from "next/navigation";
import Image from "next/image";
import { getCollection, getImageUrl } from "@/lib/tmdb";
import { Header } from "@/components/layout/Header";
import { Footer } from "@/components/layout/Footer";
import { MovieCard } from "@/components/media/MovieCard";
import { MediaGrid } from "@/components/media/MediaGrid";
import { DetailPageSkeleton } from "@/components/ui/Skeleton";

interface CollectionPageProps {
  params: Promise<{ id: string }>;
}

export async function generateMetadata({ params }: CollectionPageProps) {
  const { id } = await params;
  try {
    const collection = await getCollection(parseInt(id, 10));
    return {
      title: `Watch ${collection.name} Movies in Order – AuraMovie`,
      description: collection.overview || `Explore and watch the complete series of ${collection.name} movies in chronological release order on AuraMovie.`,
    };
  } catch {
    return { title: "Movie Collection – AuraMovie" };
  }
}

async function CollectionPageContent({ id }: { id: string }) {
  let collection;
  try {
    collection = await getCollection(parseInt(id, 10));
  } catch {
    notFound();
  }

  const backdropUrl = getImageUrl(collection.backdrop_path, "original");
  const posterUrl = getImageUrl(collection.poster_path, "w400");
  
  const sortedParts = [...(collection.parts || [])].sort((a, b) => {
    if (!a.release_date) return 1;
    if (!b.release_date) return -1;
    return new Date(a.release_date).getTime() - new Date(b.release_date).getTime();
  });

  return (
    <div className="min-h-screen bg-zinc-950">
      <Header />

      {/* Hero Backdrop */}
      <div className="relative h-[45vh] min-h-[350px] overflow-hidden">
        <Image
          src={backdropUrl}
          alt={collection.name}
          fill
          priority
          className="object-cover"
          unoptimized
        />
        <div className="absolute inset-0 bg-gradient-to-r from-zinc-950 via-zinc-950/75 to-transparent" />
        <div className="absolute inset-0 bg-gradient-to-t from-zinc-950 via-transparent to-black/30" />
      </div>

      {/* Details */}
      <div className="max-w-[1400px] mx-auto px-4 md:px-8 -mt-24 relative z-10 pb-16">
        <div className="flex flex-col md:flex-row gap-8 items-start">
          {/* Poster */}
          <div className="w-44 xl:w-52 flex-shrink-0 rounded-2xl overflow-hidden shadow-2xl shadow-black/80 border border-zinc-800">
            <Image
              src={posterUrl}
              alt={collection.name}
              width={208}
              height={312}
              className="object-cover w-full h-auto"
              unoptimized
            />
          </div>

          {/* Text details */}
          <div className="flex-1 pt-4 md:pt-8">
            <span className="bg-amber-400/10 border border-amber-400/20 text-amber-400 text-xs font-bold px-3.5 py-1.5 rounded-lg uppercase tracking-wider">
              Movie Series
            </span>
            <h1 className="text-3xl md:text-5xl font-black text-white mt-3 leading-tight">
              {collection.name}
            </h1>
            <p className="text-zinc-400 text-sm md:text-base leading-relaxed mt-4 max-w-3xl">
              {collection.overview || "No overview available for this movie collection."}
            </p>
            <p className="text-zinc-500 text-xs mt-3 font-medium">
              Total Titles: <span className="text-white">{sortedParts.length} movies</span>
            </p>
          </div>
        </div>

        {/* Movies List in Order */}
        <div className="mt-16 border-t border-zinc-900 pt-10">
          <h2 className="text-xl font-black text-white mb-2 border-l-4 border-amber-400 pl-3 uppercase tracking-wider flex items-center gap-2">
            Collection Movies (In Watch Order)
          </h2>
          <p className="text-zinc-500 text-sm mb-8">
            Watch the entire series of {collection.name} chronologically.
          </p>

          <MediaGrid>
            {sortedParts.map((movie) => (
              <MovieCard key={movie.id} movie={movie} />
            ))}
          </MediaGrid>
        </div>
      </div>

      <Footer />
    </div>
  );
}

export default async function CollectionPage({ params }: CollectionPageProps) {
  const { id } = await params;
  return (
    <Suspense fallback={<DetailPageSkeleton />}>
      <CollectionPageContent id={id} />
    </Suspense>
  );
}