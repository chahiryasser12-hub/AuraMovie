"use client";

import { useState } from "react";
import { Header } from "@/components/layout/Header";
import { Footer } from "@/components/layout/Footer";
import { Button } from "@/components/ui/Button";

export default function RequestPage() {
  const [title, setTitle] = useState("");
  const [mediaType, setMediaType] = useState("movie");
  const [notes, setNotes] = useState("");
  const [loading, setLoading] = useState(false);
  const [success, setSuccess] = useState(false);
  const [error, setError] = useState("");

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError("");
    setSuccess(false);

    try {
      const res = await fetch("/api/request", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ title, mediaType, notes }),
      });

      if (!res.ok) throw new Error("Request failed");

      setSuccess(true);
      setTitle("");
      setNotes("");
    } catch (err) {
      setError("Something went wrong. Please try again later.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-zinc-950 flex flex-col justify-between">
      <Header />
      <main className="pt-28 pb-16 flex-1 max-w-xl mx-auto px-4 w-full">
        <div className="bg-zinc-900/50 border border-zinc-800 rounded-2xl p-6 md:p-8 shadow-2xl">
          <h1 className="text-2xl font-black text-white mb-2 border-l-4 border-amber-400 pl-3 uppercase tracking-wider">
            Request a Title
          </h1>
          <p className="text-zinc-500 text-sm mb-6 mt-3">
            Can&apos;t find your favorite title? Let us know, and we will do our best to add it as soon as possible.
          </p>

          {success && (
            <div className="mb-6 p-4 bg-green-500/10 border border-green-500/20 text-green-400 text-sm rounded-xl">
              Thank you! Your request has been recorded. We are looking into it.
            </div>
          )}

          {error && (
            <div className="mb-6 p-4 bg-red-500/10 border border-red-500/20 text-red-400 text-sm rounded-xl">
              {error}
            </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label className="block text-xs font-semibold text-zinc-400 uppercase tracking-wider mb-2">
                Title Name *
              </label>
              <input
                type="text"
                required
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                placeholder="e.g. Inception or Breaking Bad"
                className="w-full bg-zinc-950 border border-zinc-800 focus:border-amber-400 rounded-xl px-4 py-3 text-sm text-white placeholder-zinc-600 outline-none transition-colors"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-zinc-400 uppercase tracking-wider mb-2">
                Type *
              </label>
              <div className="flex gap-3">
                {["movie", "tv"].map((type) => (
                  <button
                    key={type}
                    type="button"
                    onClick={() => setMediaType(type)}
                    className={`flex-1 py-3 text-sm font-bold rounded-xl border transition-all cursor-pointer ${
                      mediaType === type
                        ? "bg-amber-400/10 border-amber-400 text-amber-400"
                        : "bg-zinc-950 border-zinc-800 text-zinc-500"
                    }`}
                  >
                    {type === "movie" ? "🎬 Movie" : "📺 TV Show"}
                  </button>
                ))}
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold text-zinc-400 uppercase tracking-wider mb-2">
                Additional Notes (Optional)
              </label>
              <textarea
                value={notes}
                onChange={(e) => setNotes(e.target.value)}
                placeholder="Release year, specific season or details..."
                className="w-full bg-zinc-950 border border-zinc-800 focus:border-amber-400 rounded-xl px-4 py-3 text-sm text-white placeholder-zinc-600 outline-none transition-colors h-24 resize-none"
              />
            </div>

            <Button type="submit" loading={loading} className="w-full py-3 mt-2">
              Submit Request
            </Button>
          </form>
        </div>
      </main>
      <Footer />
    </div>
  );
}