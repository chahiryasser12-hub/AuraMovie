import { Header } from "@/components/layout/Header";
import { Footer } from "@/components/layout/Footer";
import { getDictionary } from "@/lib/i18n";

export default async function DMCAPage({ params }: { params: Promise<{ locale: string }> }) {
  const { locale } = await params;
  const dict = getDictionary(locale);
  const isAr = locale === 'ar';

  return (
    <div className="min-h-screen bg-zinc-950 flex flex-col">
      <Header />
      <main className="flex-1 pt-32 pb-16 max-w-4xl mx-auto px-6">
        <h1 className="text-3xl md:text-5xl font-black text-white mb-8 border-l-4 border-red-500 pl-4 uppercase">
          DMCA Policy
        </h1>
        <div className="space-y-6 text-zinc-400">
          <div className="bg-red-500/5 border border-red-500/20 p-6 rounded-2xl text-red-200/80 leading-relaxed font-medium">
            {isAr 
              ? "AuraMovie هو موقع فهرسة وتلخيص للمعلومات. نحن لا نستضيف، نخزن، أو نرفع أي ملفات فيديو، أفلام، أو حلقات على خوادمنا الخاصة. جميع المحتويات التي تظهر في المشغل هي روابط من أطراف ثالثة خارجية." 
              : "AuraMovie is an online service provider as defined in the DMCA. We do not host, store, or upload any video files on our own servers. All content is provided by non-affiliated third parties."}
          </div>

          <h2 className="text-white font-extrabold text-xl mt-10 border-b border-zinc-800 pb-2">{isAr ? "بلاغات انتهاك حقوق النشر" : "Notification of Infringement"}</h2>
          <p>
            {isAr
              ? "نحن نحترم حقوق الملكية الفكرية للآخرين. إذا كنت صاحب حق طبع ونشر وتعتقد أن أي محتوى متاح عبر موقعنا ينتهك حقوقك، يرجى تزويدنا بالمعلومات التالية:"
              : "We respond to notices of alleged infringement that comply with the DMCA. If you believe your content is being infringed, please provide us with the necessary documentation."}
          </p>

          <div className="bg-zinc-900 border border-zinc-800 p-10 rounded-3xl text-center shadow-2xl">
            <h3 className="text-zinc-500 text-[10px] font-black uppercase tracking-[0.3em] mb-4">Official Compliance Email</h3>
            <p className="text-2xl md:text-3xl font-black text-white selection:bg-amber-400 selection:text-zinc-950">
              legal@auramovie.dpdns.org
            </p>
            <p className="text-xs text-zinc-600 mt-6 italic font-medium">
              Response time: 48 - 72 Business Hours.
            </p>
          </div>
        </div>
      </main>
      <Footer />
    </div>
  );
}