import { Suspense } from "react";
import { notFound } from "next/navigation";
import Image from "next/image";
import Link from "next/link";
import { getMovieDetails, getImageUrl } from "@/lib/tmdb";
import { Header } from "@/components/layout/Header";
import { Footer } from "@/components/layout/Footer";
import { Button } from "@/components/ui/Button";
import { WatchlistButton } from "@/components/ui/WatchlistButton";
import { ShareButton } from "@/components/ui/ShareButton";
import { JsonLd } from "@/components/seo/JsonLd";
import { buildLocalizedTitle, buildLocalizedDescription, buildMovieJsonLd, buildBreadcrumbJsonLd, buildFAQJsonLd, cleanJsonLd } from "@/lib/seo";
import { getDictionary, pickLocale } from "@/lib/i18n";
import { formatDate, formatRuntime, formatVoteAverage, slugify } from "@/lib/utils";
import { DetailPageSkeleton } from "@/components/ui/Skeleton";
import { db } from "@/db";
import { comments } from "@/db/schema";
import { eq, and, desc } from "drizzle-orm";
import { CommentsSection } from "@/components/media/CommentsSection";

interface MoviePageProps {
  params: Promise<{ id: string; locale: string }>;
}

export async function generateMetadata({ params }: MoviePageProps) {
  const { id, locale } = await params;
  const baseUrl = process.env.NEXT_PUBLIC_SITE_URL || "https://auramovie.dpdns.org";

  try {
    const movieId = parseInt(id, 10);
    // نجيبو النسخة الإنجليزية (مرجع ثابت للـ slug/year) + النسخة المترجمة (ar أو fr) إلا كانت اللغة ماشي en
    const [movieEn, movieLocalized] = await Promise.all([
      getMovieDetails(movieId, "en"),
      locale !== "en" ? getMovieDetails(movieId, locale).catch(() => null) : null
    ]);

    const year = movieEn.release_date ? movieEn.release_date.slice(0, 4) : "";
    const englishTitle = movieEn.title || movieEn.original_title;
    const slug = slugify(englishTitle);
    const overview = movieLocalized?.overview || movieEn.overview;

    const pageTitle = buildLocalizedTitle(englishTitle, year, locale, "movie");
    const pageDesc = buildLocalizedDescription(overview, englishTitle, locale);
    const imageUrl = getImageUrl(movieEn.backdrop_path, "w780");

    return {
      title: pageTitle,
      description: pageDesc,
      openGraph: {
        title: pageTitle,
        description: pageDesc,
        url: `${baseUrl}/${locale}/movies/${movieId}-${slug}`,
        siteName: 'AuraMovie',
        images: [{ url: imageUrl, width: 780, height: 439, alt: englishTitle }],
        locale: locale,
        type: 'video.movie',
      },
      twitter: {
        card: 'summary_large_image',
        title: pageTitle,
        description: pageDesc,
        images: [imageUrl],
      },
      alternates: {
        canonical: `${baseUrl}/${locale}/movies/${movieId}-${slug}`,
        languages: {
          ar: `${baseUrl}/ar/movies/${movieId}-${slug}`,
          en: `${baseUrl}/en/movies/${movieId}-${slug}`,
          fr: `${baseUrl}/fr/movies/${movieId}-${slug}`,
        }
      }
    };
  } catch { 
    return { title: "Movie – AuraMovie" }; 
  }
}

async function MoviePageContent({ id, locale }: { id: string; locale: string }) {
  let movieEn;
  let movieLocalized;
  const movieId = parseInt(id, 10);

  try {
    [movieEn, movieLocalized] = await Promise.all([
      getMovieDetails(movieId, "en"),
      locale !== "en" ? getMovieDetails(movieId, locale).catch(() => null) : null
    ]);
  } catch { notFound(); }

  const dict = getDictionary(locale);
  const englishTitle = movieEn.title || movieEn.original_title;
  const overview = locale !== "en" && movieLocalized?.overview ? movieLocalized.overview : movieEn.overview;
  const year = movieEn.release_date ? movieEn.release_date.slice(0, 4) : "";
  const slug = slugify(englishTitle);

  const backdropUrl = getImageUrl(movieEn.backdrop_path, "w780");
  const posterUrl = getImageUrl(movieEn.poster_path, "w400");
  const cast = movieEn.credits?.cast?.slice(0, 12) || [];

  const breadcrumbSchema = cleanJsonLd(
    buildBreadcrumbJsonLd([
      { name: dict.home, item: `/${locale}` },
      { name: dict.movies, item: `/${locale}/movies` },
      { name: englishTitle, item: `/${locale}/movies/${movieId}-${slug}` }
    ])
  );

  const faqSchema = cleanJsonLd(buildFAQJsonLd(englishTitle, "movie", locale));

  const movieComments = await db.select()
    .from(comments)
    .where(and(eq(comments.tmdbId, movieId), eq(comments.mediaType, "movie")))
    .orderBy(desc(comments.createdAt));

  return (
    <div className="min-h-screen bg-zinc-950 text-zinc-100">
      <JsonLd data={cleanJsonLd(buildMovieJsonLd(movieEn))} />
      <JsonLd data={breadcrumbSchema} />
      <JsonLd data={faqSchema} />
      <Header />

      <div className="pt-24 pb-6 bg-zinc-900/40 border-b border-zinc-900/60">
        <div className="max-w-[1400px] mx-auto px-4 md:px-8 flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
          <div>
            <h1 className="text-3xl md:text-5xl font-black text-white tracking-tight leading-tight">
              {pickLocale(locale, {
                ar: `مشاهدة فيلم ${englishTitle} ${year} مترجم HD`,
                fr: `Regarder ${englishTitle} (${year}) en streaming`,
                en: englishTitle,
              })}
            </h1>
            <div className="flex flex-wrap items-center gap-x-3 gap-y-1 text-sm text-zinc-400 mt-2 font-medium">
              <span className="text-amber-400">{year}</span>
              <span>•</span>
              {movieEn.genres?.map((g: any) => (
                <Link key={g.id} href={`/${locale}/genres/${g.id}?type=movie`} className="hover:text-white transition-colors">
                  {g.name}
                </Link>
              ))}
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-[1400px] mx-auto px-4 md:px-8 py-8">
        <div className="relative aspect-video bg-zinc-900 rounded-2xl overflow-hidden border border-zinc-800 shadow-lg mb-8">
            <Image src={backdropUrl} alt={englishTitle} fill className="object-cover opacity-40" priority unoptimized />
            <div className="absolute inset-0 flex items-center justify-center">
              <Link href={`/${locale}/watch/${movieId}?type=movie`}>
                <div className="w-20 h-20 bg-amber-400 hover:bg-amber-500 text-zinc-950 rounded-full flex items-center justify-center shadow-xl transition-all hover:scale-105 cursor-pointer animate-pulse">
                  <svg className="w-10 h-10 fill-current ml-1" viewBox="0 0 24 24"><path d="M8 5v14l11-7z" /></svg>
                </div>
              </Link>
            </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          <div className="lg:col-span-2">
            <h2 className="text-white font-bold text-lg mb-2">
              {pickLocale(locale, {
                ar: 'قصة فيلم ومخلص الأحداث',
                fr: 'Synopsis du film',
                en: 'Storyline & Summary',
              })}
            </h2>
            <p className="text-zinc-300 text-base leading-relaxed">{overview}</p>
            
            <div className="mt-6 p-4 bg-zinc-900/30 border border-zinc-800/50 rounded-xl">
              <p className="text-xs text-zinc-500 leading-relaxed text-justify">
                {pickLocale(locale, {
                  ar: `موقع AuraMovie يتمنى لكم مشاهدة ممتعة لفيلم ${englishTitle} مترجم وكامل بجودة عالية. الكلمات الدلالية: مشاهدة فيلم ${englishTitle} مترجم ايجي بست، تحميل ${englishTitle} سيما كلوب، فاصل اعلاني، ماي سيما، افلام ${year} اون لاين.`,
                  fr: `AuraMovie vous souhaite un excellent visionnage du film ${englishTitle} en streaming complet et en haute qualité. Regardez ${englishTitle} en VF et VOSTFR gratuitement, films ${year} en streaming en ligne.`,
                  en: `Watch ${englishTitle} full movie online in HD. Download ${englishTitle} subtitle free streaming. AuraMovie is your best choice to stream movies in 2026.`,
                })}
              </p>
            </div>

            {cast.length > 0 && (
              <div className="mt-8">
                <h3 className="text-white font-bold text-lg mb-4">{dict.topCast}</h3>
                <div className="flex gap-4 overflow-x-auto scrollbar-hide pb-2">
                  {cast.map((actor: any) => (
                    <Link key={actor.id} href={`/${locale}/people/${actor.id}`} className="flex flex-col items-center gap-2 group min-w-[80px]">
                      <div className="relative w-16 h-16 rounded-full overflow-hidden bg-zinc-800 border-2 border-transparent group-hover:border-amber-400 transition-all">
                        <Image src={getImageUrl(actor.profile_path, "w200")} alt={actor.name} fill className="object-cover" unoptimized />
                      </div>
                      <span className="text-[10px] text-zinc-300 text-center font-bold group-hover:text-amber-400">{actor.name}</span>
                    </Link>
                  ))}
                </div>
              </div>
            )}

            <CommentsSection 
              tmdbId={movieId} 
              mediaType="movie" 
              initialComments={movieComments} 
              locale={locale} 
            />
          </div>

          <div className="lg:col-span-1 flex flex-col gap-4">
            <Link href={`/${locale}/watch/${movieId}?type=movie`} className="w-full">
                <Button size="lg" className="w-full justify-center gap-2">
                  {pickLocale(locale, {
                    ar: 'شاهد الفيلم الآن',
                    fr: 'Regarder maintenant',
                    en: 'Watch Now',
                  })}
                </Button>
            </Link>
            <WatchlistButton id={movieEn.id} title={englishTitle} posterPath={movieEn.poster_path} type="movie" />
            <ShareButton title={englishTitle} path={`/${locale}/movies/${movieId}-${slug}`} />
          </div>
        </div>
      </div>
      <Footer />
    </div>
  );
}

export default async function MoviePage({ params }: MoviePageProps) {
  const { id, locale } = await params;
  return (
    <Suspense fallback={<DetailPageSkeleton />}>
      <MoviePageContent id={id} locale={locale} />
    </Suspense>
  );
}