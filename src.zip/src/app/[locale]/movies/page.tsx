import { getPopularMovies } from "@/lib/tmdb";
import { Header } from "@/components/layout/Header";
import { Footer } from "@/components/layout/Footer";
import { MovieCard } from "@/components/media/MovieCard";
import { MediaGrid } from "@/components/media/MediaGrid";
import { MOVIE_GENRES } from "@/lib/tmdb";
import Link from "next/link";

export const revalidate = 3600;

export const metadata = {
  title: "Browse Movies – AuraMovie",
  description: "Explore the most popular and top-rated movies online. Browse by genre and discover new titles to stream.",
};

export default async function MoviesPage() {
  const popular = await getPopularMovies(1);

  return (
    <div className="min-h-screen bg-zinc-950">
      <Header />
      <main className="pt-24 pb-16 max-w-[1400px] mx-auto px-4 md:px-8">
        {/* Genre Quick Links */}
        <div className="mb-10">
          <h2 className="text-lg font-bold text-white mb-4">Browse by Genre</h2>
          <div className="flex flex-wrap gap-2">
            {Object.entries(MOVIE_GENRES).map(([id, name]) => (
              <Link
                key={id}
                href={`/genres/${id}?type=movie`}
                className="px-4 py-2 bg-zinc-900 hover:bg-zinc-800 text-zinc-300 hover:text-white rounded-xl border border-zinc-800 text-xs font-medium transition-colors"
              >
                {name}
              </Link>
            ))}
          </div>
        </div>

        <div className="mb-6">
          <h1 className="text-3xl font-black text-white">🎬 All Movies</h1>
          <p className="text-zinc-500 text-sm mt-1">Discover trending and popular movies available to stream.</p>
        </div>

        <MediaGrid>
          {popular.results.map((movie) => (
            <MovieCard key={movie.id} movie={movie} />
          ))}
        </MediaGrid>
      </main>
      <Footer />
    </div>
  );
}