import { 
  getTrendingAnimeSeries, 
  getTrendingAnimeMovies, 
  discoverSeries 
} from "@/lib/tmdb";
import { Header } from "@/components/layout/Header";
import { Footer } from "@/components/layout/Footer";
import { AnimeClientPage } from "./AnimeClientPage";
import { getDictionary } from "@/lib/i18n";

interface AnimePageProps {
  params: Promise<{ locale: string }>;
}

export async function generateMetadata({ params }: AnimePageProps) {
  const { locale } = await params;
  const dict = getDictionary(locale);
  return {
    title: `${dict.anime} – ${dict.allAnime} – AuraMovie`,
    description: dict.discoverAnime,
  };
}

export default async function AnimePage({ params }: AnimePageProps) {
  const { locale } = await params;
  const dict = getDictionary(locale);

  const [
    seriesRes, 
    moviesRes,
    shonenRes,
    seinenRes,
    isekaiRes,
    thrillerRes,
    sliceOfLifeRes,
    legendaryRes,
    seasonalRes
  ] = await Promise.all([
    getTrendingAnimeSeries(1, locale),
    getTrendingAnimeMovies(1, locale),
    
    // Shonen
    discoverSeries({ 
      with_genres: "16,10759", 
      with_original_language: "ja", 
      sort_by: "popularity.desc", 
      language: locale 
    }),
    
    // Seinen
    discoverSeries({ 
      with_genres: "16,18", 
      with_original_language: "ja", 
      sort_by: "popularity.desc", 
      language: locale 
    }),
    
    // Isekai
    discoverSeries({ 
      with_genres: "16,10765", 
      with_original_language: "ja", 
      sort_by: "popularity.desc", 
      language: locale 
    }),
    
    // Thriller
    discoverSeries({ 
      with_genres: "16,9648", 
      with_original_language: "ja", 
      sort_by: "popularity.desc", 
      language: locale 
    }),
    
    // Slice of Life
    discoverSeries({ 
      with_genres: "16,35", 
      with_original_language: "ja", 
      sort_by: "popularity.desc", 
      language: locale 
    }),

    // أنميات أسطورية (التقييم الأعلى على الإطلاق مع حد أدنى من التصويتات لضمان الجودة)
    discoverSeries({
      with_genres: "16",
      with_original_language: "ja",
      "vote_count.gte": 250,
      sort_by: "vote_average.desc",
      language: locale
    }),

    // أنميات موسمية (الأكثر شعبية هذا العام الحالي 2026)
    discoverSeries({
      with_genres: "16",
      with_original_language: "ja",
      first_air_date_year: "2026",
      sort_by: "popularity.desc",
      language: locale
    })
  ]);

  return (
    <div className="min-h-screen bg-zinc-950">
      <Header />
      <AnimeClientPage 
        initialSeries={seriesRes.results} 
        initialMovies={moviesRes.results} 
        shonenAnime={shonenRes.results || []}
        seinenAnime={seinenRes.results || []}
        isekaiAnime={isekaiRes.results || []}
        thrillerAnime={thrillerRes.results || []}
        sliceOfLifeAnime={sliceOfLifeRes.results || []}
        legendaryAnime={legendaryRes.results || []}
        seasonalAnime={seasonalRes.results || []}
        locale={locale} 
        dict={dict} 
      />
      <Footer />
    </div>
  );
}