"use client";

import { useState, useEffect, useRef, useCallback } from "react";
import Link from "next/link";
import { AnimeCard } from "@/components/media/AnimeCard";
import { MediaGrid } from "@/components/media/MediaGrid";
import { AnimeGenreSection } from "@/components/sections/AnimeGenreSection";
import { sortSmartResults } from "@/lib/utils";
import { getImageUrl } from "@/lib/tmdb";
import type { TMDBMovie, TMDBSeries, TMDBPaginatedResponse, TMDBSearchMultiResult } from "@/types/tmdb";

interface AnimeClientPageProps {
  initialSeries: TMDBSeries[];
  initialMovies: TMDBMovie[];
  shonenAnime: TMDBSeries[];
  seinenAnime: TMDBSeries[];
  isekaiAnime: TMDBSeries[];
  thrillerAnime: TMDBSeries[];
  sliceOfLifeAnime: TMDBSeries[];
  legendaryAnime: TMDBSeries[];
  seasonalAnime: TMDBSeries[];
  locale: string;
  dict: Record<string, string>;
}

const DEBOUNCE_MS = 400;

export function AnimeClientPage({ 
  initialSeries, 
  initialMovies, 
  shonenAnime,
  seinenAnime,
  isekaiAnime,
  thrillerAnime,
  sliceOfLifeAnime,
  legendaryAnime,
  seasonalAnime,
  locale, 
  dict 
}: AnimeClientPageProps) {
  const [query, setQuery] = useState("");
  const [searchResults, setSearchResults] = useState<TMDBSearchMultiResult[]>([]);
  const [loading, setLoading] = useState(false);
  const [isSearching, setIsSearching] = useState(false);

  const debounceTimer = useRef<ReturnType<typeof setTimeout> | null>(null);
  const abortRef = useRef<AbortController | null>(null);

  const performSearch = useCallback(async (q: string) => {
    if (!q.trim()) {
      setSearchResults([]);
      setIsSearching(false);
      return;
    }

    abortRef.current?.abort();
    const controller = new AbortController();
    abortRef.current = controller;

    setLoading(true);
    setIsSearching(true);

    try {
      const res = await fetch(
        `/api/tmdb/search?q=${encodeURIComponent(q)}&type=multi&page=1`,
        { signal: controller.signal }
      );
      if (!res.ok) {
        setSearchResults([]);
        return;
      }
      const data = (await res.json()) as TMDBPaginatedResponse<TMDBSearchMultiResult>;
      
      const filtered = (data.results || []).filter((item: any) => {
        const isMedia = item.media_type === "tv" || item.media_type === "movie";
        if (!isMedia) return false;
        
        const hasAnimationGenre = item.genre_ids?.includes(16);
        const isJapanese = item.original_language === "ja";

        return hasAnimationGenre && isJapanese;
      });

      const sorted = sortSmartResults(filtered, q);
      setSearchResults(sorted);
    } catch (err) {
      if ((err as Error).name !== "AbortError") {
        setSearchResults([]);
      }
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    if (debounceTimer.current) clearTimeout(debounceTimer.current);

    const trimmed = query.trim();
    if (trimmed.length < 2) {
      setSearchResults([]);
      setIsSearching(false);
      setLoading(false);
      return;
    }

    debounceTimer.current = setTimeout(() => {
      performSearch(trimmed);
    }, DEBOUNCE_MS);

    return () => {
      if (debounceTimer.current) clearTimeout(debounceTimer.current);
    };
  }, [query, performSearch]);

  // دالة ذكية لتحويل الشهر لاسم الفصل (Spring, Summer, Fall, Winter)
  const formatSeason = (dateStr: string) => {
    if (!dateStr) return "";
    const date = new Date(dateStr);
    if (isNaN(date.getTime())) return "";
    const year = date.getFullYear();
    const month = date.getMonth() + 1;
    let season = "Winter";
    if (month >= 3 && month <= 5) season = "Spring";
    else if (month >= 6 && month <= 8) season = "Summer";
    else if (month >= 9 && month <= 11) season = "Fall";
    return `${season} ${year}`;
  };

  const isAr = locale === "ar";

  return (
    <main className="pt-24 pb-16 max-w-[1400px] mx-auto px-4 md:px-8">
      <div className="mb-10 select-none flex flex-col md:flex-row md:items-center md:justify-between gap-6">
        <div>
          <h1 className="text-3xl md:text-4xl font-black text-white flex items-center gap-2 border-l-4 border-amber-400 pl-3 uppercase tracking-widest">
            🌸 {dict.anime}
          </h1>
          <p className="text-zinc-550 text-sm mt-2 font-medium">
            {dict.discoverAnime}
          </p>
        </div>

        <div className="w-full md:w-80 relative">
          <div className="flex items-center gap-2 bg-zinc-900 border border-zinc-800 rounded-xl px-4 py-2.5 focus-within:border-amber-400 transition-colors">
            {loading ? (
              <svg className="w-4 h-4 text-amber-400 flex-shrink-0 animate-spin" fill="none" viewBox="0 0 24 24">
                <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" />
                <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4z" />
              </svg>
            ) : (
              <svg className="w-4 h-4 text-zinc-555 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
              </svg>
            )}
            <input
              type="text"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder={isAr ? "بحث في الأنمي..." : "Search anime..."}
              className="flex-1 bg-transparent text-xs text-white placeholder-zinc-550 outline-none"
            />
            {query && (
              <button
                type="button"
                onClick={() => setQuery("")}
                className="text-zinc-550 hover:text-white transition-colors cursor-pointer"
              >
                <svg className="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                </svg>
              </button>
            )}
          </div>
        </div>
      </div>

      {isSearching ? (
        <div>
          <h2 className="text-lg font-black text-white mb-6 border-l-4 border-amber-400 pl-2.5 uppercase tracking-wider">
            🔍 {isAr ? "نتائج البحث" : "Search Results"}
          </h2>

          {loading ? (
            <MediaGrid loading={true} skeletonCount={12} />
          ) : searchResults.length > 0 ? (
            <MediaGrid>
              {searchResults.map((item) => {
                const type: "movie" | "tv" = item.media_type === "movie" ? "movie" : "tv";
                return (
                  <AnimeCard 
                    key={`search-anime-${item.id}`} 
                    anime={item as any} 
                    type={type} 
                  />
                );
              })}
            </MediaGrid>
          ) : (
            <div className="flex flex-col items-center justify-center py-24 gap-4 text-center select-none">
              <div className="text-5xl">🌸</div>
              <h3 className="text-xl font-bold text-white">
                {isAr ? "لا توجد نتائج" : "No anime found"}
              </h3>
              <p className="text-zinc-555 text-xs font-medium max-w-sm">
                {isAr 
                  ? "لم نجد أي أنمي يطابق هذا البحث. تأكد من كتابة الاسم الإنجليزي بشكل صحيح." 
                  : "We couldn't find any anime matching your query. Please check your spelling."}
              </p>
            </div>
          )}
        </div>
      ) : (
        <>
          {/* 1. Shonen (Action & Adventure) */}
          <div className="mb-8">
            <AnimeGenreSection title="Shonen (Action & Adventure)" items={shonenAnime} />
          </div>

          {/* 2. Thriller & Mystery */}
          <div className="mt-8">
            <AnimeGenreSection title="Thriller & Mystery" items={thrillerAnime} />
          </div>

          {/* 3. Seinen (Dark & Psychological) */}
          <div className="mt-8">
            <AnimeGenreSection title="Seinen (Dark & Psychological)" items={seinenAnime} />
          </div>

          {/* 4. Isekai (Fantasy & Another World) */}
          <div className="mt-8">
            <AnimeGenreSection title="Isekai (Fantasy & Another World)" items={isekaiAnime} />
          </div>

          {/* 5. الوجت المزدوج: أنميات أسطورية ضد أنميات موسمية جنب لجنب كيما فالتصويرة */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 my-16 border-t border-zinc-900/60 pt-12 select-none">
            {/* العمود الأول: أنميات أسطورية */}
            <div>
              <h2 className="text-xl font-black text-white mb-6 border-l-4 border-amber-400 pl-3 uppercase tracking-wider flex items-center gap-2">
                🏆 {isAr ? "أنميات أسطورية" : "Legendary Anime"}
              </h2>
              <div className="flex flex-col gap-3">
                {legendaryAnime.slice(0, 7).map((item, idx) => {
                  const seasonYear = formatSeason(item.first_air_date);
                  const score = Math.round(item.vote_average * 10);
                  return (
                    <Link
                      key={`legendary-${item.id}`}
                      href={`/${locale}/anime/${item.id}?type=tv`}
                      className="group flex items-center justify-between gap-4 bg-zinc-900/30 hover:bg-zinc-900/60 border border-zinc-900/80 hover:border-amber-400/40 rounded-2xl p-4 transition-all duration-300"
                    >
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2 text-[10px] md:text-xs text-zinc-550 font-bold mb-1">
                          <span>TV Show</span>
                          <span>•</span>
                          <span>{isAr ? `الشعبية ${Math.round(item.popularity)}` : `Popularity ${Math.round(item.popularity)}`}</span>
                        </div>
                        <h3 className="text-sm md:text-base font-black text-white group-hover:text-amber-400 transition-colors truncate">
                          {item.name}
                        </h3>
                        <div className="flex items-center gap-2 text-xs text-zinc-400 mt-1">
                          <span className="font-semibold">{seasonYear}</span>
                          <span>•</span>
                          <span className="text-emerald-400 font-bold flex items-center gap-1">
                            {score}% <span className="text-[10px]">💚</span>
                          </span>
                        </div>
                      </div>

                      <div className="flex items-center gap-4 flex-shrink-0">
                        <div className="relative w-12 h-16 rounded-lg overflow-hidden bg-zinc-800 border border-zinc-800">
                          {item.poster_path ? (
                            <img
                              src={getImageUrl(item.poster_path, "w200")}
                              alt={item.name}
                              className="object-cover w-full h-full"
                              loading="lazy"
                            />
                          ) : (
                            <div className="w-full h-full flex items-center justify-center text-xs">🌸</div>
                          )}
                        </div>
                        <span className="text-lg md:text-xl font-black text-amber-400/80 group-hover:text-amber-400 transition-colors w-6 text-right">
                          #{idx + 1}
                        </span>
                      </div>
                    </Link>
                  );
                })}
              </div>
            </div>

            {/* العمود الثاني: أنميات موسمية */}
            <div>
              <h2 className="text-xl font-black text-white mb-6 border-l-4 border-[#FF1E46] pl-3 uppercase tracking-wider flex items-center gap-2">
                🌸 {isAr ? "أنميات موسمية" : "Seasonal Anime"}
              </h2>
              <div className="flex flex-col gap-3">
                {seasonalAnime.slice(0, 7).map((item, idx) => {
                  const seasonYear = formatSeason(item.first_air_date);
                  const score = Math.round(item.vote_average * 10);
                  return (
                    <Link
                      key={`seasonal-${item.id}`}
                      href={`/${locale}/anime/${item.id}?type=tv`}
                      className="group flex items-center justify-between gap-4 bg-zinc-900/30 hover:bg-zinc-900/60 border border-zinc-900/80 hover:border-[#FF1E46]/40 rounded-2xl p-4 transition-all duration-300"
                    >
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2 text-[10px] md:text-xs text-zinc-550 font-bold mb-1">
                          <span>TV Show</span>
                          <span>•</span>
                          <span>{isAr ? `الشعبية ${Math.round(item.popularity)}` : `Popularity ${Math.round(item.popularity)}`}</span>
                        </div>
                        <h3 className="text-sm md:text-base font-black text-white group-hover:text-[#FF1E46] transition-colors truncate">
                          {item.name}
                        </h3>
                        <div className="flex items-center gap-2 text-xs text-zinc-400 mt-1">
                          <span className="font-semibold">{seasonYear}</span>
                          <span>•</span>
                          <span className="text-emerald-400 font-bold flex items-center gap-1">
                            {score}% <span className="text-[10px]">💚</span>
                          </span>
                        </div>
                      </div>

                      <div className="flex items-center gap-4 flex-shrink-0">
                        <div className="relative w-12 h-16 rounded-lg overflow-hidden bg-zinc-800 border border-zinc-800">
                          {item.poster_path ? (
                            <img
                              src={getImageUrl(item.poster_path, "w200")}
                              alt={item.name}
                              className="object-cover w-full h-full"
                              loading="lazy"
                            />
                          ) : (
                            <div className="w-full h-full flex items-center justify-center text-xs">🌸</div>
                          )}
                        </div>
                        <span className="text-lg md:text-xl font-black text-zinc-550 group-hover:text-white transition-colors w-6 text-right">
                          #{idx + 1}
                        </span>
                      </div>
                    </Link>
                  );
                })}
              </div>
            </div>
          </div>

          {/* 6. الأفلام الأكثر شعبية (Popular Anime Movies) */}
          <div className="mt-16 border-t border-zinc-900/60 pt-10">
            <h2 className="text-lg font-black text-white mb-6 border-l-4 border-amber-400 pl-2.5 uppercase tracking-wider flex items-center gap-2">
              🎬 {isAr ? "الأفلام الأكثر شعبية" : "Popular Anime Movies"}
            </h2>
            <MediaGrid>
              {initialMovies.slice(0, 18).map((movie) => (
                <AnimeCard key={`anime-movie-${movie.id}`} anime={movie} type="movie" />
              ))}
            </MediaGrid>
          </div>

          {/* 7. الأكثر شهرة هذا الموسم (Trending / Season Series) */}
          <div className="mt-16 border-t border-zinc-900/60 pt-10">
            <h2 className="text-lg font-black text-white mb-6 border-l-4 border-amber-400 pl-2.5 uppercase tracking-wider flex items-center gap-2">
              📺 {isAr ? "الأكثر شهرة هذا الموسم" : "Most Popular This Season"}
            </h2>
            <MediaGrid>
              {initialSeries.slice(0, 18).map((series) => (
                <AnimeCard key={`anime-tv-${series.id}`} anime={series} type="tv" />
              ))}
            </MediaGrid>
          </div>

          {/* 8. Slice of Life & Drama */}
          <div className="mt-16 border-t border-zinc-900/60 pt-10">
            <AnimeGenreSection title="Slice of Life & Drama" items={sliceOfLifeAnime} />
          </div>
        </>
      )}
    </main>
  );
}