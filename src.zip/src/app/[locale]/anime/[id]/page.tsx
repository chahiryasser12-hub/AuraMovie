import { Suspense } from "react";
import { notFound } from "next/navigation";
import Image from "next/image";
import Link from "next/link";
import { getMovieDetails, getSeriesDetails, getImageUrl, getFranchisePack } from "@/lib/tmdb";
import { Header } from "@/components/layout/Header";
import { Footer } from "@/components/layout/Footer";
import { AnimeCard } from "@/components/media/AnimeCard";
import { FranchiseSection } from "@/components/sections/FranchiseSection";
import { Button } from "@/components/ui/Button";
import { WatchlistButton } from "@/components/ui/WatchlistButton";
import { ShareButton } from "@/components/ui/ShareButton";
import { JsonLd } from "@/components/seo/JsonLd";
import { buildMovieJsonLd, buildSeriesJsonLd, buildBreadcrumbJsonLd, buildFAQJsonLd, cleanJsonLd } from "@/lib/seo";
import { getDictionary, pickLocale } from "@/lib/i18n";
import { formatDate, formatRuntime, formatVoteAverage, formatNumber, slugify } from "@/lib/utils";
import { DetailPageSkeleton } from "@/components/ui/Skeleton";
import { db } from "@/db";
import { comments } from "@/db/schema";
import { eq, and, desc } from "drizzle-orm";
import { CommentsSection } from "@/components/media/CommentsSection";

interface AnimeDetailPageProps {
  params: Promise<{ id: string; locale: string }>;
  searchParams: Promise<{ type?: string }>;
}

export async function generateMetadata({ params, searchParams }: AnimeDetailPageProps) {
  const { id, locale } = await params;
  const { type = "tv" } = await searchParams;
  const sanitizedType = type === "movie" ? "movie" : "tv";
  const baseUrl = process.env.NEXT_PUBLIC_SITE_URL || "https://auramovie.dpdns.org";

  try {
    const tmdbId = parseInt(id, 10);
    const media = sanitizedType === "movie" 
      ? await getMovieDetails(tmdbId, "en") 
      : await getSeriesDetails(tmdbId, "en");
    
    const title = "title" in media ? media.title : media.name;
    const date = "release_date" in media ? media.release_date : media.first_air_date;
    const year = date ? date.slice(0, 4) : "";
    const slug = slugify(title);

    const pageTitle = pickLocale(locale, {
      ar: `مشاهدة أنمي "${title} ${year}" مترجم كامل بجودة عالية HD – AuraMovie`,
      fr: `Regarder l'anime ${title} (${year}) en streaming VF/VOSTFR – AuraMovie`,
      en: `${title} (${year}) – Anime – AuraMovie`,
    });

    const pageDescription = pickLocale(locale, {
      ar: `شاهد وتفرج أنمي ${title} مترجم حصرياً على AuraMovie. قصة الأنمي: ${media.overview?.slice(0, 100)}...`,
      fr: `Regardez l'anime ${title} en streaming VF/VOSTFR exclusivement sur AuraMovie. Synopsis : ${media.overview?.slice(0, 100)}...`,
      en: media.overview,
    });
    
    const imageUrl = getImageUrl(media.backdrop_path, "w780");

    return {
      title: pageTitle,
      description: pageDescription,
      openGraph: {
        title: pageTitle,
        description: pageDescription,
        url: `${baseUrl}/${locale}/anime/${tmdbId}-${slug}?type=${sanitizedType}`,
        siteName: 'AuraMovie',
        images: [{ url: imageUrl, width: 780, height: 439, alt: title }],
        locale: locale,
        type: sanitizedType === "movie" ? 'video.movie' : 'video.tv_show',
      },
      twitter: {
        card: 'summary_large_image',
        title: pageTitle,
        description: pageDescription,
        images: [imageUrl],
      },
      alternates: {
        canonical: `${baseUrl}/${locale}/anime/${tmdbId}-${slug}?type=${sanitizedType}`,
        languages: {
          ar: `${baseUrl}/ar/anime/${tmdbId}-${slug}?type=${sanitizedType}`,
          en: `${baseUrl}/en/anime/${tmdbId}-${slug}?type=${sanitizedType}`,
          fr: `${baseUrl}/fr/anime/${tmdbId}-${slug}?type=${sanitizedType}`,
        }
      }
    };
  } catch {
    return { title: "Anime Details – AuraMovie" };
  }
}

async function AnimeDetailPageContent({ 
  id, 
  locale, 
  type 
}: { 
  id: string; 
  locale: string; 
  type: "movie" | "tv"; 
}) {
  const tmdbId = parseInt(id, 10);
  let mediaEn;
  let mediaLocalized;

  try {
    if (locale !== "en") {
      const [enData, locData] = await Promise.all([
        type === "movie" ? getMovieDetails(tmdbId, "en") : getSeriesDetails(tmdbId, "en"),
        type === "movie" ? getMovieDetails(tmdbId, locale).catch(() => null) : getSeriesDetails(tmdbId, locale).catch(() => null)
      ]);
      mediaEn = enData;
      mediaLocalized = locData || enData;
    } else {
      mediaEn = type === "movie" ? await getMovieDetails(tmdbId, "en") : await getSeriesDetails(tmdbId, "en");
      mediaLocalized = mediaEn;
    }
  } catch {
    notFound();
  }

  const dict = getDictionary(locale);
  const isMovie = "title" in mediaEn;
  
  const englishTitle = isMovie ? (mediaEn as any).title : (mediaEn as any).name;
  const overview = mediaLocalized.overview || mediaEn.overview;
  const slug = slugify(englishTitle);

  const backdropUrl = getImageUrl(mediaEn.backdrop_path, "w780");
  const posterUrl = getImageUrl(mediaEn.poster_path, "w400");
  const similar = mediaEn.similar?.results?.slice(0, 6) || [];
  const rating = formatVoteAverage(mediaEn.vote_average);
  const cast = mediaEn.credits?.cast?.slice(0, 12) || [];

  const seasons = !isMovie && (mediaEn as any).seasons
    ? ((mediaEn as any).seasons as any[])
        .filter((s) => s.season_number > 0)
        .sort((a, b) => a.season_number - b.season_number)
    : [];

  const firstSeason = seasons[0];
  const startJourneyUrl = !isMovie && firstSeason
    ? `/${locale}/watch/${mediaEn.id}?type=tv&season=${firstSeason.season_number}&seasons=${(mediaEn as any).number_of_seasons}`
    : `/${locale}/watch/${mediaEn.id}?type=movie`;

  const isAnimation = mediaEn.genres?.some((g: any) => g.id === 16) || false;
  const originalLanguage = mediaEn.original_language || "ja";

  const franchiseItems = await getFranchisePack(englishTitle, "en", null, originalLanguage, isAnimation);

  const schema = isMovie 
    ? cleanJsonLd(buildMovieJsonLd(mediaEn as any)) 
    : cleanJsonLd(buildSeriesJsonLd(mediaEn as any));

  const breadcrumbSchema = cleanJsonLd(
    buildBreadcrumbJsonLd([
      { name: dict.home, item: `/${locale}` },
      { name: dict.anime, item: `/${locale}/anime` },
      { name: englishTitle, item: `/${locale}/anime/${tmdbId}-${slug}?type=${type}` }
    ])
  );
  
  const faqSchema = cleanJsonLd(buildFAQJsonLd(englishTitle, "anime", locale));

  const animeComments = await db.select()
    .from(comments)
    .where(and(eq(comments.tmdbId, tmdbId), eq(comments.mediaType, type)))
    .orderBy(desc(comments.createdAt));

  return (
    <div className="min-h-screen bg-zinc-950 text-zinc-100">
      <JsonLd data={schema} />
      <JsonLd data={breadcrumbSchema} />
      <JsonLd data={faqSchema} />
      <Header />

      <div className="pt-24 pb-6 bg-zinc-900/40 border-b border-zinc-900/60">
        <div className="max-w-[1400px] mx-auto px-4 md:px-8 flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
          <div>
            <h1 className="text-3xl md:text-5xl font-black text-white tracking-tight leading-tight">
              {pickLocale(locale, {
                ar: `مشاهدة أنمي ${englishTitle} مترجم HD`,
                fr: `Regarder l'anime ${englishTitle} en streaming`,
                en: englishTitle,
              })}
            </h1>
            <div className="flex flex-wrap items-center gap-x-3 gap-y-1 text-sm text-zinc-400 mt-2 font-medium">
              <span>
                {isMovie 
                  ? ((mediaEn as any).release_date ? (mediaEn as any).release_date.slice(0, 4) : "N/A") 
                  : ((mediaEn as any).first_air_date ? (mediaEn as any).first_air_date.slice(0, 4) : "N/A")}
              </span>
              <span>•</span>
              <span>{isMovie ? "Anime Movie" : `${(mediaEn as any).number_of_seasons} Season(s)`}</span>
              <span>•</span>
              <span>{isMovie && (mediaEn as any).runtime ? formatRuntime((mediaEn as any).runtime) : "TV Show"}</span>
            </div>
          </div>

          <div className="flex items-center gap-6">
            <div className="flex flex-col gap-1 items-start">
              <span className="text-xs font-bold text-zinc-500 uppercase tracking-widest leading-none">Rating</span>
              <div className="flex items-center gap-2">
                <svg className="w-6 h-6 text-amber-400 fill-current" viewBox="0 0 24 24">
                  <path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z" />
                </svg>
                <div className="flex flex-col leading-none">
                  <div className="text-lg font-black text-white">
                    {rating}<span className="text-zinc-500 text-sm font-normal">/10</span>
                  </div>
                  <span className="text-[10px] text-zinc-500 font-bold mt-0.5">
                    {formatNumber(mediaEn.vote_count)} VOTES
                  </span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-[1400px] mx-auto px-4 md:px-8 py-8">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
          <div className="md:col-span-1 hidden md:block">
            <div className="relative aspect-[2/3] rounded-xl overflow-hidden shadow-lg border border-zinc-800">
              <Image src={posterUrl} alt={englishTitle} fill priority className="object-cover" unoptimized />
            </div>
          </div>
          <div className="md:col-span-3 relative aspect-video bg-zinc-900 rounded-xl overflow-hidden border border-zinc-800 shadow-lg">
            <Image src={backdropUrl} alt={englishTitle} fill priority className="object-cover" unoptimized />
            <div className="absolute inset-0 bg-black/40 flex items-center justify-center">
              <Link href={startJourneyUrl}>
                <div className="w-20 h-20 bg-amber-400 hover:bg-amber-500 text-zinc-950 rounded-full flex items-center justify-center shadow-xl transition-all hover:scale-105 cursor-pointer animate-pulse">
                  <svg className="w-10 h-10 fill-current ml-1" viewBox="0 0 24 24">
                    <path d="M8 5v14l11-7z" />
                  </svg>
                </div>
              </Link>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 mt-8">
          <div className="lg:col-span-2 flex flex-col gap-6">
            <div className="flex flex-wrap gap-2">
              {mediaEn.genres?.map((g: any) => (
                <span key={g.id} className="px-3.5 py-1 bg-zinc-900 border border-zinc-800 rounded-full text-xs font-semibold text-zinc-300">
                  {g.name}
                </span>
              ))}
              <span className="px-3.5 py-1 bg-red-950/40 border border-red-900/40 rounded-full text-xs font-semibold text-red-350">
                Anime
              </span>
            </div>

            <h2 className="text-white font-bold text-lg">
              {pickLocale(locale, {
                ar: 'قصة الأنمي ومخلص الأحداث',
                fr: "Synopsis de l'anime",
                en: 'Anime Storyline',
              })}
            </h2>
            <p className="text-zinc-300 text-base leading-relaxed">{overview}</p>
            
            <div className="p-4 bg-zinc-900/30 border border-zinc-800/50 rounded-xl">
              <p className="text-xs text-zinc-500 leading-relaxed text-justify">
                {pickLocale(locale, {
                  ar: `موقع AuraMovie يتمنى لكم مشاهدة ممتعة لأنمي ${englishTitle} مترجم. الكلمات الدلالية: مشاهدة انمي ${englishTitle} مترجم انمي كلاود، انمي سلاير، وايت انمي، تحميل ${englishTitle} جودة عالية.`,
                  fr: `AuraMovie vous souhaite un excellent visionnage de l'anime ${englishTitle} en streaming VF/VOSTFR. Regardez ${englishTitle} en HD, téléchargement gratuit sur AuraMovie.`,
                  en: `Watch ${englishTitle} full anime online in HD. Download ${englishTitle} subtitle free streaming. AuraMovie is your best choice for anime.`,
                })}
              </p>
            </div>

            {cast.length > 0 && (
              <div className="mt-2">
                <h3 className="text-white font-bold text-lg mb-4">Voice Actors (Seiyuu)</h3>
                <div className="flex gap-4 overflow-x-auto scrollbar-hide pb-2">
                  {cast.map((actor: any) => (
                    <Link key={actor.id} href={`/${locale}/people/${actor.id}`} className="flex flex-col items-center gap-2 group min-w-[80px]">
                      <div className="relative w-16 h-16 rounded-full overflow-hidden bg-zinc-800 border-2 border-transparent group-hover:border-amber-400 transition-all">
                        <Image src={getImageUrl(actor.profile_path, "w200")} alt={actor.name} fill className="object-cover" unoptimized />
                      </div>
                      <span className="text-[10px] text-zinc-300 text-center font-bold group-hover:text-amber-400">{actor.name}</span>
                    </Link>
                  ))}
                </div>
              </div>
            )}

            <CommentsSection 
              tmdbId={tmdbId} 
              mediaType={type} 
              initialComments={animeComments} 
              locale={locale} 
            />
          </div>

          <div className="lg:col-span-1 flex flex-col gap-4">
            {!isMovie && firstSeason && (
              <Link href={startJourneyUrl} className="w-full">
                <Button size="lg" className="w-full justify-center gap-2 bg-gradient-to-r from-amber-400 to-amber-500 hover:from-amber-500 hover:to-amber-600 text-zinc-950 font-black tracking-wide border-0 shadow-xl shadow-amber-400/10">
                  <span>🌸</span>
                  {pickLocale(locale, {
                    ar: 'ابدأ الرحلة (الموسم 1)',
                    fr: 'Commencer (Saison 1)',
                    en: 'Start Journey (S1 E1)',
                  })}
                </Button>
              </Link>
            )}

            <Link href={`/${locale}/watch/${mediaEn.id}?type=${type}`} className="w-full">
              <Button size="lg" variant="secondary" className="w-full justify-center gap-2">
                <svg className="w-5 h-5 fill-current" viewBox="0 0 24 24"><path d="M8 5v14l11-7z" /></svg>
                {dict.watchStreamingNow}
              </Button>
            </Link>

            <WatchlistButton id={mediaEn.id} title={englishTitle} posterPath={mediaEn.poster_path} type={type as "tv"|"movie"} />
            
            <div className="border-t border-zinc-900/60 pt-4 mt-2">
              <ShareButton title={englishTitle} path={`/${locale}/anime/${tmdbId}-${slug}?type=${type}`} />
            </div>
          </div>
        </div>

        <FranchiseSection items={franchiseItems} currentId={mediaEn.id} />

        {!isMovie && seasons.length > 0 && (
          <section className="py-10 border-t border-zinc-900 mt-12">
            <h2 className="text-xl font-black text-white mb-6 border-l-4 border-amber-400 pl-3 uppercase tracking-wider flex items-center gap-2">
              🍿 {dict.seasons} ({pickLocale(locale, {
                ar: 'بالترتيب الزمني',
                fr: 'Ordre chronologique',
                en: 'Chronological Order',
              })})
            </h2>
            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-4">
              {seasons.map((season) => (
                <Link
                  key={season.id}
                  href={`/${locale}/watch/${mediaEn.id}?type=tv&season=${season.season_number}&seasons=${(mediaEn as any).number_of_seasons}`}
                  className="group flex flex-col gap-2 bg-zinc-900/30 border border-zinc-900/60 rounded-xl overflow-hidden p-2.5 hover:border-zinc-700 transition-colors"
                >
                  <div className="relative aspect-[2/3] rounded-lg overflow-hidden bg-zinc-800 shadow-md">
                    {season.poster_path ? (
                      <Image src={getImageUrl(season.poster_path, "w300")} alt={season.name} fill className="object-cover" unoptimized />
                    ) : (
                      <div className="w-full h-full flex items-center justify-center gap-2 text-zinc-600 text-xs">🎬</div>
                    )}
                  </div>
                  <div className="px-1 mt-1">
                    <p className="text-white text-xs font-bold truncate group-hover:text-amber-400 transition-colors">{season.name}</p>
                    <p className="text-zinc-500 text-[10px] font-bold mt-0.5">{season.episode_count} Episodes</p>
                  </div>
                </Link>
              ))}
            </div>
          </section>
        )}

        {similar.length > 0 && (
          <section className="py-10 border-t border-zinc-900 mt-12">
            <h2 className="text-xl font-black text-white mb-6 border-l-4 border-amber-400 pl-3 uppercase tracking-wider select-none">
              {dict.moreLikeThis}
            </h2>
            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-4">
              {similar.map((item: any) => (
                <AnimeCard key={`similar-${item.id}`} anime={item} type={type as "tv"|"movie"} />
              ))}
            </div>
          </section>
        )}
      </div>

      <Footer />
    </div>
  );
}

export default async function AnimeDetailPage({ params, searchParams }: AnimeDetailPageProps) {
  const { id, locale } = await params;
  const { type = "tv" } = await searchParams;
  const sanitizedType = type === "movie" ? "movie" : "tv";

  return (
    <Suspense fallback={<DetailPageSkeleton />}>
      <AnimeDetailPageContent id={id} locale={locale} type={sanitizedType} />
    </Suspense>
  );
}