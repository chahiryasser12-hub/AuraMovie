import { Header } from "@/components/layout/Header";
import { Footer } from "@/components/layout/Footer";
import { getDictionary } from "@/lib/i18n";

export default async function AboutPage({ params }: { params: Promise<{ locale: string }> }) {
  const { locale } = await params;
  const dict = getDictionary(locale);
  const isAr = locale === 'ar';

  return (
    <div className="min-h-screen bg-zinc-950 flex flex-col">
      <Header />
      <main className="flex-1 pt-32 pb-16 max-w-4xl mx-auto px-6">
        <h1 className="text-3xl md:text-5xl font-black text-white mb-8 border-l-4 border-amber-400 pl-4 tracking-tight">
          {dict.aboutUs}
        </h1>
        <div className="space-y-6 text-zinc-400 text-sm md:text-base leading-relaxed">
          <p className="text-lg text-zinc-200 font-medium">
            {isAr 
              ? "مرحباً بك في أورا موفي (AuraMovie)، رائد منصات استكشاف السينما والأنمي في الوطن العربي."
              : "Welcome to AuraMovie, the leading platform for cinema and anime exploration in the MENA region."}
          </p>
          <p>
            {isAr
              ? "نحن نهدف إلى توفير تجربة تصفح عالمية للمستخدم العربي. AuraMovie هو قاعدة بيانات مستقلة تعتمد على أحدث التقنيات لتقديم معلومات دقيقة حول الأفلام، المسلسلات، والأنمي، بما في ذلك طاقم العمل، التقييمات العالمية، وتواريخ الإصدار."
              : "We aim to provide a world-class browsing experience for our users. AuraMovie is an independent database using cutting-edge tech to deliver accurate info about movies, series, and anime."}
          </p>
          <div className="bg-zinc-900/40 p-8 rounded-3xl border border-zinc-800 shadow-xl">
            <h2 className="text-white font-black text-lg mb-4 uppercase tracking-wider">{isAr ? "لماذا أورا موفي؟" : "Why AuraMovie?"}</h2>
            <ul className="list-disc list-inside space-y-3">
              <li>{isAr ? "بيانات دقيقة ومحدثة يومياً." : "Accurate and daily updated metadata."}</li>
              <li>{isAr ? "واجهة مستخدم عصرية وسريعة جداً." : "Modern and lightning-fast user interface."}</li>
              <li>{isAr ? "دعم كامل للغة العربية والاتجاه من اليمين لليسار." : "Full support for Arabic language and RTL layout."}</li>
            </ul>
          </div>
        </div>
      </main>
      <Footer />
    </div>
  );
}