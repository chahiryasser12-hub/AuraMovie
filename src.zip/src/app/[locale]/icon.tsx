import { ImageResponse } from "next/og";

// Define the dimensions of the browser tab icon
export const size = {
  width: 32,
  height: 32,
};
export const contentType = "image/png";

export default function Icon() {
  return new ImageResponse(
    (
      <div
        style={{
          fontSize: 22,
          background: "#f5c518", // Coordinated brand yellow
          width: "100%",
          height: "100%",
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
          color: "#09090b", // Dark background text
          fontWeight: 900,
          borderRadius: "7px",
          fontFamily: "system-ui, sans-serif",
          textTransform: "uppercase",
          letterSpacing: "-0.05em",
        }}
      >
        A
      </div>
    ),
    {
      ...size,
    }
  );
}