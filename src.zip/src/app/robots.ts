import type { MetadataRoute } from 'next';

export default function robots(): MetadataRoute.Robots {
  const baseUrl = process.env.NEXT_PUBLIC_SITE_URL || 'https://auramovie.dpdns.org';

  return {
    rules: {
      userAgent: '*',
      allow: '/',
      disallow: [
        '/api/', 
        '/_next/', 
        '/search?', 
        '*/watch/*', // اختياري: منع أرشفة المشغل لتركيز القوة على صفحات التفاصيل
      ],
    },
    sitemap: `${baseUrl}/sitemap.xml`,
  };
}