"use client";

import { useState } from "react";
import { Button } from "./Button";

interface ShareButtonProps {
  title: string;
  path: string;
}

export function ShareButton({ title, path }: ShareButtonProps) {
  const [copied, setCopied] = useState(false);

  const absoluteUrl = typeof window !== "undefined" ? `${window.location.origin}${path}` : "";

  const handleShare = async () => {
    if (navigator.share) {
      try {
        await navigator.share({
          title: `${title} on AuraMovie`,
          url: absoluteUrl,
        });
      } catch (err) {
        console.log("Error sharing", err);
      }
    } else {
      try {
        await navigator.clipboard.writeText(absoluteUrl);
        setCopied(true);
        setTimeout(() => setCopied(false), 2000);
      } catch (err) {
        console.log("Clipboard error", err);
      }
    }
  };

  const shareWhatsApp = () => {
    const url = `https://api.whatsapp.com/send?text=${encodeURIComponent(`${title} - Watch on AuraMovie: ${absoluteUrl}`)}`;
    window.open(url, "_blank");
  };

  const shareTelegram = () => {
    const url = `https://t.me/share/url?url=${encodeURIComponent(absoluteUrl)}&text=${encodeURIComponent(`${title} on AuraMovie`)}`;
    window.open(url, "_blank");
  };

  return (
    <div className="flex items-center gap-2">
      <Button size="lg" variant="outline" onClick={handleShare} className="gap-2">
        <svg className="w-5 h-5 text-zinc-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8.684 13.342C8.886 12.938 9 12.482 9 12c0-.482-.118-.938-.316-1.342m0 2.684a3 3 0 110-2.684m0 2.243l4.243 2.122m-4.243-3.53l4.243-2.83M16.24 7.5a3 3 0 11-6 0 3 3 0 016 0zm0 6a3 3 0 11-6 0 3 3 0 016 0z" />
        </svg>
        {copied ? "Link Copied!" : "Share"}
      </Button>

      <button
        type="button"
        onClick={shareWhatsApp}
        className="w-11 h-11 rounded-lg border border-zinc-700/50 bg-zinc-900/20 flex items-center justify-center text-zinc-400 hover:text-green-500 hover:border-green-500/50 transition-all active:scale-95 cursor-pointer"
        title="Share on WhatsApp"
      >
        <svg className="w-5 h-5 fill-current" viewBox="0 0 24 24">
          <path d="M.057 24l1.687-6.163c-1.041-1.804-1.588-3.849-1.587-5.946C.06 5.348 5.397.01 12.008.01c3.202.001 6.212 1.246 8.477 3.514 2.266 2.268 3.507 5.28 3.505 8.484-.004 6.657-5.34 11.997-11.953 11.997-2.005-.001-3.973-.502-5.724-1.455L0 24zm6.59-4.846c1.6.95 3.167 1.485 4.896 1.486 5.45 0 9.886-4.384 9.89-9.773.001-2.61-1.011-5.064-2.852-6.908-1.84-1.841-4.29-2.853-6.91-2.855-5.455 0-9.89 4.385-9.894 9.774-.002 1.83.514 3.61 1.493 5.176l-.978 3.57 3.345-.877z" />
        </svg>
      </button>

      <button
        type="button"
        onClick={shareTelegram}
        className="w-11 h-11 rounded-lg border border-zinc-700/50 bg-zinc-900/20 flex items-center justify-center text-zinc-400 hover:text-blue-400 hover:border-blue-500/50 transition-all active:scale-95 cursor-pointer"
        title="Share on Telegram"
      >
        <svg className="w-5 h-5 fill-current" viewBox="0 0 24 24">
          <path d="M22.422 1.346c-.328-.152-.705-.125-1.002.072L.416 15.111c-.381.25-.562.723-.453 1.185.11.463.502.802.978.847l5.22.483 1.83 5.419c.148.438.535.736.997.771.05.004.1.006.15.006.411 0 .8-.204 1.04-.548l2.955-4.225 4.902 3.633c.31.23.708.286 1.066.15.358-.135.617-.449.69-.838L23.957 2.4c.088-.475-.15-1.02-.535-1.054z" />
        </svg>
      </button>
    </div>
  );
}