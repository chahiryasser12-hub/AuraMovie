import { cn } from "@/lib/utils";

interface SkeletonProps {
  className?: string;
}

export function Skeleton({ className }: SkeletonProps) {
  return (
    <div
      className={cn(
        "animate-pulse rounded-lg bg-zinc-800/60",
        className
      )}
    />
  );
}

export function MovieCardSkeleton() {
  return (
    <div className="flex flex-col gap-3">
      <Skeleton className="aspect-[2/3] w-full rounded-xl" />
      <Skeleton className="h-4 w-3/4" />
      <Skeleton className="h-3 w-1/2" />
    </div>
  );
}

export function HeroBannerSkeleton() {
  return (
    <div className="relative h-[70vh] min-h-[500px] w-full animate-pulse bg-zinc-900">
      <div className="absolute bottom-0 left-0 right-0 p-8 md:p-16 flex flex-col gap-4">
        <Skeleton className="h-8 w-64" />
        <Skeleton className="h-5 w-96" />
        <Skeleton className="h-4 w-80" />
        <div className="flex gap-3 mt-4">
          <Skeleton className="h-11 w-32 rounded-xl" />
          <Skeleton className="h-11 w-36 rounded-xl" />
        </div>
      </div>
    </div>
  );
}

export function DetailPageSkeleton() {
  return (
    <div className="min-h-screen bg-zinc-950 animate-pulse">
      <Skeleton className="h-[50vh] w-full rounded-none" />
      <div className="max-w-7xl mx-auto px-4 py-8 flex gap-8">
        <Skeleton className="w-48 aspect-[2/3] rounded-xl flex-shrink-0 hidden md:block" />
        <div className="flex-1 flex flex-col gap-4">
          <Skeleton className="h-8 w-80" />
          <Skeleton className="h-5 w-48" />
          <Skeleton className="h-4 w-full" />
          <Skeleton className="h-4 w-5/6" />
          <Skeleton className="h-4 w-4/6" />
          <div className="flex gap-3 mt-4">
            <Skeleton className="h-11 w-32 rounded-xl" />
            <Skeleton className="h-11 w-36 rounded-xl" />
          </div>
        </div>
      </div>
    </div>
  );
}