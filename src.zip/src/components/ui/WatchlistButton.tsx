"use client";

import { useState, useEffect } from "react";
import { Button } from "./Button";

interface WatchlistButtonProps {
  id: number;
  title: string;
  posterPath: string | null;
  type: "movie" | "tv";
}

export function WatchlistButton({ id, title, posterPath, type }: WatchlistButtonProps) {
  const [isSaved, setIsSaved] = useState(false);
  const [mounted, setMounted] = useState(false);

  useEffect(() => {
    setMounted(true);
    const list = JSON.parse(localStorage.getItem("watchlist") || "[]");
    setIsSaved(list.some((item: any) => item.id === id && item.type === type));
  }, [id, type]);

  const toggleWatchlist = () => {
    const list = JSON.parse(localStorage.getItem("watchlist") || "[]");
    let updated;
    
    if (isSaved) {
      updated = list.filter((item: any) => !(item.id === id && item.type === type));
      localStorage.setItem("watchlist", JSON.stringify(updated));
      setIsSaved(false);
    } else {
      list.push({ id, title, posterPath, type, addedAt: Date.now() });
      localStorage.setItem("watchlist", JSON.stringify(list));
      setIsSaved(true);
    }

    // Dispatches storage synchronization event globally to update header counters in real-time
    window.dispatchEvent(new Event("watchlist-updated"));
  };

  if (!mounted) {
    return (
      <Button size="lg" variant="outline" className="gap-2">
        <div className="w-5 h-5 bg-zinc-800 animate-pulse rounded-full" />
        My List
      </Button>
    );
  }

  return (
    <Button 
      size="lg" 
      variant={isSaved ? "secondary" : "outline"} 
      onClick={toggleWatchlist} 
      className="gap-2 cursor-pointer select-none"
    >
      {isSaved ? (
        <>
          <svg className="w-5 h-5 text-amber-400 fill-current" viewBox="0 0 24 24">
            <path d="M9 16.17L4.83 12l-1.42 1.41L9 19 21 7l-1.41-1.41z"/>
          </svg>
          In Your List
        </>
      ) : (
        <>
          <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4v16m8-8H4" />
          </svg>
          My List
        </>
      )}
    </Button>
  );
}