"use client";

import { EMBED_PROVIDERS } from "@/config/providers";
import { cn } from "@/lib/utils";

interface ProviderSelectorProps {
  selectedId: string;
  onSelect: (id: string) => void;
}

export function ProviderSelector({ selectedId, onSelect }: ProviderSelectorProps) {
  return (
    <div className="flex gap-2 overflow-x-auto scrollbar-hide pb-1 -mx-4 px-4 sm:mx-0 sm:px-0 select-none">
      {EMBED_PROVIDERS.map((provider) => {
        const isActive = selectedId === provider.id;
        return (
          <button
            key={provider.id}
            onClick={() => onSelect(provider.id)}
            className={cn(
              "flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs md:text-sm font-semibold transition-all duration-200 border cursor-pointer select-none whitespace-nowrap flex-shrink-0",
              isActive
                ? "border-amber-400 bg-amber-400/10 text-white shadow-md shadow-amber-400/5"
                : "border-zinc-800 bg-zinc-950/60 text-zinc-400 hover:border-zinc-700 hover:text-zinc-200"
            )}
          >
            <span>{provider.logo}</span>
            <span>{provider.name}</span>
            {isActive && (
              <span className="w-1.5 h-1.5 rounded-full bg-amber-400 animate-pulse" />
            )}
          </button>
        );
      })}
    </div>
  );
}