/**
 * Renders a schema.org JSON-LD <script> tag.
 * Usage: <JsonLd data={buildMovieJsonLd(movie)} />
 */
export function JsonLd({ data }: { data: object }) {
  return (
    <script
      type="application/ld+json"
      // eslint-disable-next-line react/no-danger
      dangerouslySetInnerHTML={{ __html: JSON.stringify(data) }}
    />
  );
}