"use client";

import { useState, useEffect } from "react";
import Image from "next/image";
import Link from "next/link";
import { useParams } from "next/navigation";
import type { TMDBMovie, TMDBSeries } from "@/types/tmdb";
import { getImageUrl } from "@/lib/tmdb";
import { formatYear } from "@/lib/utils";

type HeroItem = (TMDBMovie | TMDBSeries) & { media_type?: string };

function isMovie(item: HeroItem): item is TMDBMovie & { media_type?: string } {
  return "title" in item;
}

interface HeroBannerProps {
  items: HeroItem[];
}

export function HeroBanner({ items }: HeroBannerProps) {
  const params = useParams();
  const locale = (params?.locale as string) || "en";
  const [currentIndex, setCurrentIndex] = useState(0);

  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentIndex((prev) => (prev + 1) % items.length);
    }, 8000);
    return () => clearInterval(interval);
  }, [items.length]);

  if (!items.length) return null;

  const item = items[currentIndex];
  const movie = isMovie(item);
  const title = movie ? item.title : item.name;
  const year = formatYear(movie ? item.release_date : item.first_air_date);

  return (
    <section aria-label="Featured movies and series" className="relative isolate min-h-[500px] overflow-hidden bg-zinc-950 sm:min-h-[540px] md:min-h-[620px]">
      <div key={item.id} className="absolute inset-0 animate-in fade-in duration-700">
        <Image src={getImageUrl(item.backdrop_path, "w1280")} alt="" fill priority={currentIndex === 0} sizes="100vw" className="object-cover object-center" />
      </div>
      <div className="absolute inset-0 bg-[linear-gradient(90deg,rgba(9,9,11,0.96)_0%,rgba(9,9,11,0.72)_72%,rgba(9,9,11,0.25)_100%)] md:bg-[linear-gradient(90deg,rgba(9,9,11,0.98)_0%,rgba(9,9,11,0.88)_33%,rgba(9,9,11,0.36)_64%,rgba(9,9,11,0.12)_100%)]" />
      <div className="absolute inset-0 bg-[linear-gradient(0deg,rgba(9,9,11,1)_0%,rgba(9,9,11,0)_45%)]" />
      <div className="absolute -left-24 top-12 h-72 w-72 rounded-full bg-amber-400/10 blur-3xl" />

      <div className="relative z-10 mx-auto flex min-h-[500px] max-w-7xl items-end px-4 pb-20 pt-24 sm:min-h-[540px] sm:px-5 md:min-h-[620px] md:items-center md:px-12 md:py-20">
        <div className="max-w-2xl md:rounded-3xl md:border md:border-white/10 md:bg-zinc-950/35 md:p-9 md:shadow-2xl md:shadow-black/30 md:backdrop-blur-[3px]">
          <div className="mb-4 flex items-center gap-2.5 text-[10px] font-bold tracking-[0.14em] sm:text-xs sm:tracking-[0.18em] md:mb-5 md:gap-3">
            <span className="rounded-full bg-amber-400 px-3 py-1.5 text-zinc-950">{movie ? "MOVIE" : "TV SERIES"}</span>
            <span className="text-zinc-200">{year}</span>
            <span className="h-1 w-1 rounded-full bg-zinc-400" />
            <span className="text-zinc-300">FEATURED NOW</span>
          </div>
          <h2 aria-live="polite" className="max-w-xl text-[2.15rem] font-black leading-[0.94] tracking-tight text-white sm:text-5xl md:text-6xl lg:text-7xl">{title}</h2>
          <p className="mt-4 max-w-xl line-clamp-2 text-sm leading-6 text-zinc-200 sm:line-clamp-3 md:mt-5 md:text-base md:leading-7 md:text-zinc-300">{item.overview}</p>
          <div className="mt-6 flex gap-3 md:mt-8 md:flex-wrap">
            <Link href={`/${locale}/watch/${item.id}?type=${movie ? "movie" : "tv"}`} className="inline-flex min-h-12 flex-1 items-center justify-center gap-2 rounded-xl bg-amber-400 px-4 text-sm font-black text-zinc-950 shadow-lg shadow-amber-400/15 transition hover:-translate-y-0.5 hover:bg-amber-300 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-amber-400 focus-visible:ring-offset-2 focus-visible:ring-offset-zinc-950 md:flex-none md:px-5">
              <svg aria-hidden="true" className="h-5 w-5 fill-current" viewBox="0 0 24 24"><path d="M8 5v14l11-7z" /></svg>
              WATCH NOW
            </Link>
            <Link href={`/${locale}/${movie ? "movies" : "series"}/${item.id}`} className="inline-flex min-h-12 flex-1 items-center justify-center rounded-xl border border-white/15 bg-white/10 px-4 text-sm font-bold text-white transition hover:-translate-y-0.5 hover:bg-white/15 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-amber-400 focus-visible:ring-offset-2 focus-visible:ring-offset-zinc-950 md:flex-none md:px-5">DETAILS</Link>
          </div>
        </div>
      </div>

      <div className="absolute bottom-5 left-4 z-20 flex items-center gap-2.5 sm:left-5 md:bottom-8 md:left-12 md:gap-3">
        <span className="text-xs font-black tracking-[0.2em] text-white">{String(currentIndex + 1).padStart(2, "0")}</span>
        <div className="flex gap-2" role="tablist" aria-label="Featured titles">
          {items.map((featuredItem, index) => (
            <button key={featuredItem.id} type="button" role="tab" aria-selected={index === currentIndex} aria-label={`Show ${isMovie(featuredItem) ? featuredItem.title : featuredItem.name}`} onClick={() => setCurrentIndex(index)} className={`h-1.5 rounded-full transition-all ${index === currentIndex ? "w-10 bg-amber-400" : "w-4 bg-white/35 hover:bg-white/70"}`} />
          ))}
        </div>
        <span className="text-xs font-bold tracking-[0.2em] text-zinc-400">/{String(items.length).padStart(2, "0")}</span>
      </div>
    </section>
  );
}
