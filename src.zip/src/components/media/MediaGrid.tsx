import { cn } from "@/lib/utils";
import { MovieCardSkeleton } from "@/components/ui/Skeleton";

interface MediaGridProps {
  children?: React.ReactNode;
  className?: string;
  loading?: boolean;
  skeletonCount?: number;
}

export function MediaGrid({
  children,
  className,
  loading = false,
  skeletonCount = 12,
}: MediaGridProps) {
  if (loading) {
    return (
      <div
        className={cn(
          "grid grid-cols-2 xs:grid-cols-3 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-3 md:gap-4 px-1 sm:px-0",
          className
        )}
      >
        {Array.from({ length: skeletonCount }).map((_, i) => (
          <MovieCardSkeleton key={i} />
        ))}
      </div>
    );
  }

  return (
    <div
      className={cn(
        "grid grid-cols-2 xs:grid-cols-3 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-3 md:gap-4 px-1 sm:px-0",
        className
      )}
    >
      {children}
    </div>
  );
}