"use client";

import Link from "next/link";
import Image from "next/image";
import { useParams } from "next/navigation";
import type { TMDBMovie } from "@/types/tmdb";
import { getImageUrl } from "@/lib/tmdb";
import { formatYear, formatVoteAverage, getRatingColor, slugify, cn } from "@/lib/utils";

export function MovieCard({ movie, className }: { movie: TMDBMovie; className?: string }) {
  const params = useParams();
  const locale = (params?.locale as string) || "ar";

  const posterUrl = getImageUrl(movie.poster_path, "w400");
  const year = formatYear(movie.release_date);
  const rating = formatVoteAverage(movie.vote_average);
  
  const englishTitle = movie.original_title || movie.title;
  const displayTitle = locale === "ar" ? `مشاهدة فيلم ${englishTitle} ${year} مترجم` : englishTitle;
  
  // SEO Friendly URL
  const slug = slugify(englishTitle);
  const movieUrl = `/${locale}/movies/${movie.id}-${slug}`;

  return (
    <div className={cn("group relative flex flex-col overflow-hidden rounded-xl border border-zinc-800/80 bg-zinc-900/40 transition-all duration-300 hover:-translate-y-1.5 sm:rounded-2xl", className)}>
      <Link href={movieUrl} className="relative aspect-[2/3] w-full overflow-hidden block bg-zinc-900">
        <Image
          src={posterUrl}
          alt={englishTitle}
          fill
          sizes="(max-width: 768px) 50vw, 20vw"
          className="object-cover transition-transform duration-500 group-hover:scale-105"
          loading="lazy"
        />
        <div className="absolute top-2 right-2 bg-black/60 backdrop-blur-md px-1.5 py-0.5 rounded text-[10px] font-black text-amber-400 border border-white/10">
          {rating}
        </div>
      </Link>

      <div className="flex flex-col gap-1 p-2.5 sm:p-3">
        <Link href={movieUrl}>
          <h3 className="line-clamp-1 text-[11px] font-bold text-zinc-100 transition-colors hover:text-amber-400 sm:text-xs">
            {displayTitle}
          </h3>
        </Link>
        <div className="flex items-center justify-between text-[10px] font-bold text-zinc-500 uppercase tracking-wider">
          <span>Movie</span>
          <span>{year}</span>
        </div>
      </div>
    </div>
  );
}
