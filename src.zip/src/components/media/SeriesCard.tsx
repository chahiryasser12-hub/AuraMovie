"use client";

import Link from "next/link";
import Image from "next/image";
import { useParams } from "next/navigation";
import type { TMDBSeries } from "@/types/tmdb";
import { getImageUrl } from "@/lib/tmdb";
import { formatYear, slugify, cn } from "@/lib/utils";

export function SeriesCard({ series, className }: { series: TMDBSeries; className?: string }) {
  const params = useParams();
  const locale = (params?.locale as string) || "ar";

  const englishTitle = series.original_name || series.name;
  const year = formatYear(series.first_air_date);
  const displayTitle = locale === "ar" ? `مشاهدة مسلسل ${englishTitle} ${year} مترجم` : englishTitle;

  // SEO Friendly URL
  const slug = slugify(englishTitle);
  const seriesUrl = `/${locale}/series/${series.id}-${slug}`;

  return (
    <div className={cn("group relative flex flex-col bg-zinc-900/40 border border-zinc-800/80 rounded-2xl overflow-hidden transition-all duration-300 hover:-translate-y-1.5", className)}>
      <Link href={seriesUrl} className="relative aspect-[2/3] w-full overflow-hidden block bg-zinc-900">
        <Image
          src={getImageUrl(series.poster_path, "w400")}
          alt={englishTitle}
          fill
          sizes="(max-width: 768px) 50vw, 20vw"
          className="object-cover transition-transform duration-500 group-hover:scale-105"
          loading="lazy"
        />
      </Link>
      <div className="p-3 flex flex-col gap-1">
        <Link href={seriesUrl}>
          <h3 className="text-xs font-bold text-zinc-100 line-clamp-1 hover:text-amber-400 transition-colors">
            {displayTitle}
          </h3>
        </Link>
        <span className="text-[10px] font-bold text-zinc-500 uppercase">{year}</span>
      </div>
    </div>
  );
}
