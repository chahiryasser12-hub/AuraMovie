"use client";

import { useState } from "react";
import { Button } from "@/components/ui/Button";
import { cn } from "@/lib/utils";

interface Comment {
  id: number;
  userName: string;
  content: string;
  rating: number | null;
  createdAt: Date;
}

interface CommentsSectionProps {
  tmdbId: number;
  mediaType: "movie" | "tv" | "anime";
  initialComments: Comment[];
  locale: string;
}

export function CommentsSection({ tmdbId, mediaType, initialComments, locale }: CommentsSectionProps) {
  const [commentsList, setCommentsList] = useState<Comment[]>(initialComments);
  const [name, setName] = useState("");
  const [content, setContent] = useState("");
  const [rating, setRating] = useState(5);
  const [loading, setLoading] = useState(false);
  
  const isAr = locale === "ar";

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim() || !content.trim()) return;

    setLoading(true);
    try {
      const res = await fetch("/api/comments", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ 
          tmdbId, 
          mediaType, 
          userName: name, 
          content, 
          rating 
        }),
      });

      if (res.ok) {
        const newComment: Comment = {
          id: Date.now(),
          userName: name,
          content,
          rating,
          createdAt: new Date(),
        };
        setCommentsList([newComment, ...commentsList]);
        setName("");
        setContent("");
        setRating(5);
      }
    } catch (error) {
      console.error("Error posting comment:", error);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="mt-12 border-t border-zinc-900 pt-8">
      <h2 className="text-xl font-black text-white mb-6 border-l-4 border-amber-400 pl-3 uppercase tracking-wider">
        {isAr ? "التعليقات والمراجعات" : "User Reviews & Comments"}
      </h2>

      {/* نموذج إضافة تعليق */}
      <form onSubmit={handleSubmit} className="bg-zinc-900/40 border border-zinc-800 p-4 md:p-6 rounded-2xl mb-8">
        <div className="flex flex-col gap-4">
          <input
            type="text"
            placeholder={isAr ? "اسمك..." : "Your Name..."}
            value={name}
            onChange={(e) => setName(e.target.value)}
            required
            className="w-full bg-zinc-950 border border-zinc-800 focus:border-amber-400 rounded-xl px-4 py-3 text-sm text-white outline-none transition-colors"
          />
          
          {/* نظام تقييم النجوم */}
          <div className="flex items-center gap-2">
            <span className="text-xs font-bold text-zinc-500 uppercase">{isAr ? "التقييم:" : "Rating:"}</span>
            <div className="flex gap-1">
              {[1, 2, 3, 4, 5].map((star) => (
                <button
                  key={star}
                  type="button"
                  onClick={() => setRating(star)}
                  className={cn(
                    "text-xl transition-colors cursor-pointer",
                    star <= rating ? "text-amber-400" : "text-zinc-700 hover:text-zinc-500"
                  )}
                >
                  ★
                </button>
              ))}
            </div>
          </div>

          <textarea
            placeholder={isAr ? "ما رأيك في هذا العمل؟" : "What do you think about this?"}
            value={content}
            onChange={(e) => setContent(e.target.value)}
            required
            rows={4}
            className="w-full bg-zinc-950 border border-zinc-800 focus:border-amber-400 rounded-xl px-4 py-3 text-sm text-white outline-none resize-none transition-colors"
          />
          
          <Button type="submit" loading={loading} className="self-end px-8">
            {isAr ? "نشر التعليق" : "Post Comment"}
          </Button>
        </div>
      </form>

      {/* قائمة التعليقات */}
      <div className="flex flex-col gap-4">
        {commentsList.length > 0 ? (
          commentsList.map((c) => (
            <div key={c.id} className="bg-zinc-900/20 border border-zinc-800/60 p-4 rounded-xl">
              <div className="flex items-center justify-between mb-2">
                <div className="flex items-center gap-3">
                  <div className="w-8 h-8 rounded-full bg-amber-400/20 flex items-center justify-center text-amber-400 font-bold text-sm uppercase">
                    {c.userName.charAt(0)}
                  </div>
                  <div>
                    <h4 className="text-white font-bold text-sm">{c.userName}</h4>
                    <span className="text-[10px] text-zinc-500">{new Date(c.createdAt).toLocaleDateString(locale)}</span>
                  </div>
                </div>
                {c.rating && (
                  <div className="text-amber-400 text-xs font-bold flex items-center gap-0.5">
                    {c.rating} <span className="text-zinc-700">/ 5 ★</span>
                  </div>
                )}
              </div>
              <p className="text-zinc-300 text-sm leading-relaxed whitespace-pre-wrap">{c.content}</p>
            </div>
          ))
        ) : (
          <p className="text-zinc-500 text-sm text-center py-8">
            {isAr ? "لا توجد تعليقات بعد. كن أول من يشارك رأيه!" : "No comments yet. Be the first to share your thoughts!"}
          </p>
        )}
      </div>
    </div>
  );
}