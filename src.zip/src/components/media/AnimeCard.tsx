"use client";

import Link from "next/link";
import Image from "next/image";
import { useParams } from "next/navigation";
import type { TMDBMovie, TMDBSeries } from "@/types/tmdb";
import { getImageUrl } from "@/lib/tmdb";
import { formatYear, formatVoteAverage, getRatingColor, slugify, cn } from "@/lib/utils";

interface AnimeCardProps {
  anime: TMDBMovie | TMDBSeries;
  type: "movie" | "tv";
  className?: string;
}

export function AnimeCard({ anime, type, className }: AnimeCardProps) {
  const params = useParams();
  const locale = (params?.locale as string) || "ar";

  const title = "title" in anime ? anime.title : anime.name;
  const date = "release_date" in anime ? anime.release_date : anime.first_air_date;
  const posterUrl = getImageUrl(anime.poster_path, "w400");
  const year = formatYear(date);
  const rating = formatVoteAverage(anime.vote_average);

  let displayTitle = title;
  if (locale === "ar") {
    displayTitle = type === "tv" ? `انمي ${title} مترجم` : `فيلم انمي ${title} مترجم`;
  }

  // SEO Friendly URL
  const slug = slugify(title);
  const animeUrl = `/${locale}/anime/${anime.id}-${slug}?type=${type}`;

  return (
    <div className={cn("group relative flex flex-col bg-zinc-900/40 border border-zinc-800/80 rounded-2xl overflow-hidden transition-all duration-300 hover:-translate-y-1.5", className)}>
      <Link href={animeUrl} className="relative aspect-[2/3] w-full overflow-hidden block bg-zinc-900">
        <Image
          src={posterUrl}
          alt={title}
          fill
          sizes="(max-width: 768px) 50vw, 20vw"
          className="object-cover transition-transform duration-500 group-hover:scale-105"
          unoptimized
          loading="lazy"
        />
        <div className="absolute top-2 left-2 bg-amber-400 text-zinc-950 font-black px-1.5 py-0.5 rounded text-[9px] uppercase tracking-wider">
          Anime
        </div>
      </Link>

      <div className="p-3 flex flex-col gap-1">
        <Link href={animeUrl}>
          <h3 className="text-xs font-bold text-zinc-100 line-clamp-1 hover:text-amber-400 transition-colors">
            {displayTitle}
          </h3>
        </Link>
        <div className="flex items-center justify-between mt-1">
          <div className="flex items-center gap-1">
            <span className={cn("text-[10px] font-black", getRatingColor(anime.vote_average))}>{rating}</span>
          </div>
          <span className="text-[10px] font-bold text-zinc-500 uppercase">{year}</span>
        </div>
      </div>
    </div>
  );
}