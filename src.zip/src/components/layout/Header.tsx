"use client";

import { useState, useEffect, useRef, useCallback } from "react";
import Link from "next/link";
import Image from "next/image";
import { useRouter, usePathname } from "next/navigation";
import { cn, sortSmartResults } from "@/lib/utils";
import { getImageUrl } from "@/lib/tmdb";
import { getDictionary } from "@/lib/i18n";
import type { TMDBSearchMultiResult, TMDBPaginatedResponse } from "@/types/tmdb";

const LANGUAGES = [
  { code: "en", label: "EN", title: "English" },
  { code: "ar", label: "AR", title: "العربية" },
  { code: "fr", label: "FR", title: "Français" },
];

const MAX_SUGGESTIONS = 6;
const DEBOUNCE_MS = 300;
const MIN_QUERY_LENGTH = 2;

function getResultTitle(item: TMDBSearchMultiResult): string {
  return item.title || item.name || "Untitled";
}

function getResultYear(item: TMDBSearchMultiResult): string {
  const date = item.release_date || item.first_air_date;
  return date ? date.slice(0, 4) : "";
}

function getResultHref(item: TMDBSearchMultiResult, locale: string): string {
  return item.media_type === "tv" ? `/${locale}/series/${item.id}` : `/${locale}/movies/${item.id}`;
}

function SearchBox({
  variant,
  locale,
  onNavigate,
}: {
  variant: "desktop" | "mobile";
  locale: string;
  onNavigate: () => void;
}) {
  const router = useRouter();
  const [query, setQuery] = useState("");
  const [suggestions, setSuggestions] = useState<TMDBSearchMultiResult[]>([]);
  const [loading, setLoading] = useState(false);
  const [open, setOpen] = useState(false);
  const [focused, setFocused] = useState(false);

  const inputRef = useRef<HTMLInputElement>(null);
  const containerRef = useRef<HTMLDivElement>(null);
  const debounceTimer = useRef<ReturnType<typeof setTimeout> | null>(null);
  const abortRef = useRef<AbortController | null>(null);

  const runSearch = useCallback(async (q: string) => {
    abortRef.current?.abort();
    const controller = new AbortController();
    abortRef.current = controller;

    setLoading(true);
    try {
      const res = await fetch(
        `/api/tmdb/search?q=${encodeURIComponent(q)}&type=multi&page=1`,
        { signal: controller.signal }
      );
      if (!res.ok) {
        setSuggestions([]);
        return;
      }
      const data = (await res.json()) as TMDBPaginatedResponse<TMDBSearchMultiResult>;
      const filtered = (data.results || [])
        .filter((r) => r.media_type !== "person");

      const sorted = sortSmartResults(filtered, q).slice(0, MAX_SUGGESTIONS);

      setSuggestions(sorted);
      setOpen(true);
    } catch (err) {
      if ((err as Error).name !== "AbortError") setSuggestions([]);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    if (debounceTimer.current) clearTimeout(debounceTimer.current);

    const trimmed = query.trim();
    if (trimmed.length < MIN_QUERY_LENGTH) {
      setSuggestions([]);
      setOpen(false);
      return;
    }

    debounceTimer.current = setTimeout(() => runSearch(trimmed), DEBOUNCE_MS);
    return () => {
      if (debounceTimer.current) clearTimeout(debounceTimer.current);
    };
  }, [query, runSearch]);

  useEffect(() => {
    function handleClickOutside(e: MouseEvent) {
      if (containerRef.current && !containerRef.current.contains(e.target as Node)) {
        setOpen(false);
        setFocused(false);
      }
    }
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  const closeAndReset = () => {
    setOpen(false);
    setFocused(false);
    setQuery("");
    setSuggestions([]);
    inputRef.current?.blur();
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (query.trim()) {
      router.push(`/${locale}/search?q=${encodeURIComponent(query.trim())}`);
      closeAndReset();
      onNavigate();
    }
  };

  const handleSelect = (item: TMDBSearchMultiResult) => {
    router.push(getResultHref(item, locale));
    closeAndReset();
    onNavigate();
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === "Escape") {
      setOpen(false);
      inputRef.current?.blur();
    }
  };

  const showDropdown = open && query.trim().length >= MIN_QUERY_LENGTH;

  if (variant === "mobile") {
    return (
      <div ref={containerRef} className="relative">
        <form onSubmit={handleSubmit} role="search">
          <label htmlFor="mobile-site-search" className="sr-only">Search AuraMovie</label>
          <div className="flex items-center gap-2 bg-zinc-900 border border-zinc-700 rounded-xl px-3 py-2">
            <svg className="w-4 h-4 text-zinc-550" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
            </svg>
            <input
              ref={inputRef}
              id="mobile-site-search"
              type="text"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              onKeyDown={handleKeyDown}
              placeholder="Search..."
              className="flex-1 bg-transparent text-sm text-white placeholder-zinc-550 outline-none"
            />
          </div>
        </form>

        {showDropdown && (
          <SuggestionsList
            suggestions={suggestions}
            loading={loading}
            query={query}
            onSelect={handleSelect}
            onSeeAll={handleSubmit}
          />
        )}
      </div>
    );
  }

  return (
    <div ref={containerRef} className="relative hidden md:block">
      <form
        onSubmit={handleSubmit}
        role="search"
        className={cn(
          "flex items-center rounded-xl border transition-all duration-250 overflow-hidden",
          focused ? "w-72 border-amber-400 bg-zinc-900 shadow-md shadow-amber-400/5" : "w-44 border-zinc-850 bg-zinc-900/50 hover:border-zinc-750"
        )}
      >
        <svg className="w-4 h-4 text-zinc-555 ml-3 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
        </svg>
        <input
          ref={inputRef}
          aria-label="Search AuraMovie"
          type="text"
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          onFocus={() => setFocused(true)}
          onKeyDown={handleKeyDown}
          placeholder="Search..."
          className="flex-1 bg-transparent px-3 py-2 text-sm text-white placeholder-zinc-550 outline-none"
        />
      </form>

      {showDropdown && (
        <SuggestionsList
          suggestions={suggestions}
          loading={loading}
          query={query}
          onSelect={handleSelect}
          onSeeAll={handleSubmit}
        />
      )}
    </div>
  );
}

function SuggestionsList({
  suggestions,
  loading,
  query,
  onSelect,
  onSeeAll,
}: {
  suggestions: TMDBSearchMultiResult[];
  loading: boolean;
  query: string;
  onSelect: (item: TMDBSearchMultiResult) => void;
  onSeeAll: (e: React.FormEvent) => void;
}) {
  return (
    <div className="absolute top-full left-0 right-0 mt-2 bg-zinc-900 border border-zinc-800 rounded-xl shadow-2xl shadow-black/75 overflow-hidden z-50 max-h-[70vh] overflow-y-auto">
      {loading ? (
        <div className="flex items-center justify-center gap-2 py-6 text-zinc-500 text-sm font-semibold select-none">
          <svg className="w-4 h-4 animate-spin text-amber-400" fill="none" viewBox="0 0 24 24">
            <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" />
            <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4z" />
          </svg>
          Searching...
        </div>
      ) : suggestions.length > 0 ? (
        <>
          <ul>
            {suggestions.map((item) => (
              <li key={`${item.media_type}-${item.id}`}>
                <button
                  type="button"
                  onClick={() => onSelect(item)}
                  className="w-full flex items-center gap-3 px-3 py-2.5 hover:bg-zinc-850 transition-colors text-left"
                >
                  <div className="w-9 h-12 flex-shrink-0 rounded-md overflow-hidden bg-zinc-800 relative border border-zinc-700/50">
                    {item.poster_path ? (
                      <Image
                        src={getImageUrl(item.poster_path, "w200")}
                        alt={getResultTitle(item)}
                        fill
                        className="object-cover"
                        unoptimized
                      />
                    ) : (
                      <div className="w-full h-full flex items-center justify-center text-zinc-600 text-xs">
                        🎬
                      </div>
                    )}
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-bold text-white truncate">
                      {getResultTitle(item)}
                    </p>
                    <p className="text-xs text-zinc-555 flex items-center gap-1 font-semibold mt-0.5">
                      {item.media_type === "tv" ? "📺 TV" : "🎬 Movie"}
                      {getResultYear(item) && <span>· {getResultYear(item)}</span>}
                    </p>
                  </div>
                </button>
              </li>
            ))}
          </ul>
          <button
            type="button"
            onClick={onSeeAll}
            className="w-full text-center py-3 text-sm font-bold text-amber-400 hover:bg-zinc-850 transition-colors border-t border-zinc-800"
          >
            See all results for &ldquo;{query}&rdquo;
          </button>
        </>
      ) : (
        <div className="py-6 text-center text-sm text-zinc-500 font-semibold select-none">
          No results found for &ldquo;{query}&rdquo;
        </div>
      )}
    </div>
  );
}

export function Header() {
  const [scrolled, setScrolled] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);
  const [surpriseLoading, setSurpriseLoading] = useState(false);
  const [watchlistCount, setWatchlistCount] = useState(0);
  const [isLangMenuOpen, setIsLangMenuOpen] = useState(false);

  const router = useRouter();
  const pathname = usePathname();
  const langMenuRef = useRef<HTMLDivElement>(null);

  const segments = pathname.split("/");
  const currentLocale = LANGUAGES.some((l) => l.code === segments[1]) ? segments[1] : "en";
  const dict = getDictionary(currentLocale);

  const NAV_LINKS = [
    { href: `/${currentLocale}`, label: dict.home },
    { href: `/${currentLocale}/movies`, label: dict.movies },
    { href: `/${currentLocale}/series`, label: dict.series },
    { href: `/${currentLocale}/anime`, label: dict.anime },
    { 
      href: `/${currentLocale}/coming-soon`, 
      label: currentLocale === "ar" ? "قريباً" : currentLocale === "fr" ? "Bientôt" : "Coming Soon" 
    },
  ];

  const handleLanguageChange = (langCode: string) => {
    setIsLangMenuOpen(false);
    const newSegments = [...segments];
    newSegments[1] = langCode;
    const newPath = newSegments.join("/");
    router.push(newPath);
  };

  useEffect(() => {
    const updateCount = () => {
      try {
        const list = JSON.parse(localStorage.getItem("watchlist") || "[]");
        setWatchlistCount(list.length);
      } catch (err) {
        console.error(err);
      }
    };

    updateCount();
    window.addEventListener("storage", updateCount);
    window.addEventListener("watchlist-updated", updateCount);
    
    return () => {
      window.removeEventListener("storage", updateCount);
      window.removeEventListener("watchlist-updated", updateCount);
    };
  }, []);

  useEffect(() => {
    const handleOutsideClick = (e: MouseEvent) => {
      if (langMenuRef.current && !langMenuRef.current.contains(e.target as Node)) {
        setIsLangMenuOpen(false);
      }
    };
    document.addEventListener("mousedown", handleOutsideClick);
    return () => document.removeEventListener("mousedown", handleOutsideClick);
  }, []);

  useEffect(() => {
    const handleScroll = () => setScrolled(window.scrollY > 20);
    window.addEventListener("scroll", handleScroll, { passive: true });
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  useEffect(() => {
    setMobileOpen(false);
  }, [pathname]);

  const handleSurpriseMe = async () => {
    setSurpriseLoading(true);
    try {
      const res = await fetch("/api/tmdb/random");
      if (!res.ok) throw new Error("Failed to pick random");
      const data = (await res.json()) as { id: number; type: string };
      
      setMobileOpen(false);
      router.push(`/${currentLocale}/watch/${data.id}?type=${data.type}`);
    } catch (err) {
      console.error("Surprise Me error:", err);
    } finally {
      setSurpriseLoading(false);
    }
  };

  const isWatchlistActive = pathname === `/${currentLocale}/watchlist`;
  const matchedActiveLang = LANGUAGES.find((l) => l.code === currentLocale) || LANGUAGES[0];

  return (
    <header
      className={cn(
        "fixed top-0 left-0 right-0 z-50 transition-all duration-350",
        scrolled
          ? "bg-zinc-950/95 backdrop-blur-md border-b border-zinc-900 shadow-xl shadow-black/20"
          : "bg-gradient-to-b from-black/85 via-black/40 to-transparent"
      )}
    >
      <div className="max-w-[1400px] mx-auto px-3 sm:px-4 md:px-8">
        <div className="flex h-14 items-center gap-3 md:h-16 md:gap-6">
          <Link 
            href={`/${currentLocale}`} 
            className="flex flex-shrink-0 items-center gap-1.5 rounded-lg p-0.5 outline-none focus-visible:ring-2 focus-visible:ring-amber-400 group select-none sm:gap-2"
          >
            <div className="rounded-md bg-amber-400 px-2 py-0.5 text-base font-black tracking-tight text-zinc-950 shadow-md transition-all duration-200 group-hover:scale-105 active:scale-95 sm:px-2.5 sm:text-lg">
              AURA
            </div>
            <span className="text-white font-extrabold text-lg tracking-tight hidden sm:inline transition-colors duration-250 group-hover:text-amber-400">
              Movie
            </span>
          </Link>

          <nav className="hidden md:flex items-center gap-1">
            {NAV_LINKS.map(({ href, label }) => {
              const isActive = pathname === href;
              return (
                <Link
                  key={href}
                  href={href}
                  className={cn(
                    "px-4 py-2 rounded-lg text-sm font-semibold transition-all duration-200 flex items-center gap-2 whitespace-nowrap relative",
                    isActive
                      ? "text-white bg-white/10"
                      : "text-zinc-400 hover:text-white hover:bg-white/5"
                  )}
                >
                  {label}
                </Link>
              );
            })}
            
            <button
              onClick={handleSurpriseMe}
              disabled={surpriseLoading}
              aria-label="Choose a random movie or series"
              className="px-4 py-2 rounded-lg text-sm font-semibold text-zinc-400 hover:text-amber-400 hover:bg-white/5 active:scale-95 transition-all disabled:opacity-50 flex items-center gap-2 cursor-pointer select-none"
            >
              <span>{surpriseLoading ? "🎲 ..." : "🎲 Surprise Me"}</span>
            </button>
          </nav>

          <div className="hidden md:flex items-center gap-3.5 ml-auto select-none">
            <Link
              href={`/${currentLocale}/watchlist`}
              className={cn(
                "h-9 px-3 rounded-xl border flex items-center gap-2 transition-all duration-250 cursor-pointer shadow-md shadow-black/20 group outline-none active:scale-95",
                isWatchlistActive 
                  ? "bg-amber-400/10 border-amber-400 text-white font-bold" 
                  : "bg-zinc-900 border-zinc-800 hover:border-amber-400 text-zinc-350 hover:text-white"
              )}
            >
              <div className="relative flex-shrink-0 flex items-center justify-center">
                <svg className="w-3.5 h-4.5 text-white transition-colors group-hover:text-amber-400" viewBox="0 0 24 24" fill="currentColor">
                  <path d="M17 3H7c-1.1 0-2 .9-2 2v16l7-3 7 3V5c0-1.1-.9-2-2-2z" />
                  <path d="M13 7h-2v4H9v2h2v4h2v-4h2v-2h-2V7z" className="text-zinc-950" fill="currentColor" />
                </svg>
              </div>
              <span className="text-sm font-bold hidden lg:inline select-none">{dict.myWatchlist}</span>
              {watchlistCount > 0 && (
                <span className="bg-amber-400 text-zinc-950 text-[10px] font-black px-1.5 py-0.5 rounded-full shadow-sm animate-fade-in">
                  {watchlistCount}
                </span>
              )}
            </Link>

            <div ref={langMenuRef} className="relative z-50">
              <button
                onClick={() => setIsLangMenuOpen(!isLangMenuOpen)}
                type="button"
                aria-label="Select language"
                aria-expanded={isLangMenuOpen}
                className="h-9 px-3.5 rounded-xl bg-zinc-900 border border-zinc-800 hover:border-amber-400 text-white hover:text-amber-400 flex items-center gap-1.5 transition-all duration-250 cursor-pointer outline-none shadow-md shadow-black/20"
              >
                <span className="text-xs font-black tracking-wider uppercase select-none">
                  {matchedActiveLang.label}
                </span>
                <svg className="w-3.5 h-3.5 text-zinc-550 group-hover:text-amber-450 fill-current" viewBox="0 0 20 20">
                  <path d="M5.293 7.293a1 1 0 011.414 0L10 10.586l3.293-3.293a1 1 0 111.414 1.414l-4 4a1 1 0 01-1.414 0l-4-4a1 1 0 010-1.414z" />
                </svg>
              </button>

              {isLangMenuOpen && (
                <div className="absolute top-11 right-0 w-36 bg-zinc-900 border border-zinc-800 rounded-xl p-1.5 shadow-2xl animate-scale-up">
                  {LANGUAGES.map((lang) => (
                    <button
                      key={lang.code}
                      onClick={() => handleLanguageChange(lang.code)}
                      type="button"
                      className={cn(
                        "w-full text-left px-3 py-2 text-xs font-bold rounded-lg transition-colors flex items-center justify-between cursor-pointer outline-none",
                        currentLocale === lang.code 
                          ? "bg-amber-400 text-zinc-950" 
                          : "text-zinc-350 hover:bg-zinc-850 hover:text-white"
                      )}
                    >
                      <span>{lang.title}</span>
                      <span className="text-[10px] opacity-65 uppercase">{lang.code}</span>
                    </button>
                  ))}
                </div>
              )}
            </div>

            <SearchBox variant="desktop" locale={currentLocale} onNavigate={() => {}} />
          </div>

          <div className="ml-auto flex items-center gap-1.5 md:hidden">
            <button
              onClick={() => router.push(`/${currentLocale}/search`)}
              className="flex h-10 w-10 items-center justify-center rounded-xl bg-black/20 text-zinc-300 transition-colors hover:bg-white/10 hover:text-white cursor-pointer"
              aria-label="Open search"
            >
              <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
              </svg>
            </button>
            <button
              onClick={() => setMobileOpen(!mobileOpen)}
              className="flex h-10 w-10 items-center justify-center rounded-xl bg-zinc-900/80 text-zinc-200 ring-1 ring-white/10 transition-colors hover:bg-zinc-800 hover:text-white cursor-pointer"
              aria-label={mobileOpen ? "Close menu" : "Open menu"}
              aria-expanded={mobileOpen}
            >
              <div className="w-5 h-5 flex flex-col justify-center gap-1">
                <span className={cn("block h-0.5 bg-current transition-all", mobileOpen ? "rotate-45 translate-y-1.5" : "")} />
                <span className={cn("block h-0.5 bg-current transition-all", mobileOpen ? "opacity-0 scale-x-0" : "")} />
                <span className={cn("block h-0.5 bg-current transition-all", mobileOpen ? "-rotate-45 -translate-y-1.5" : "")} />
              </div>
            </button>
          </div>
        </div>
      </div>

      {mobileOpen && (
        <div className="md:hidden max-h-[calc(100dvh-3.5rem)] overflow-y-auto border-t border-white/10 bg-zinc-950/98 px-3 py-3 pb-[max(1rem,env(safe-area-inset-bottom))] shadow-xl shadow-black/80 backdrop-blur-xl animate-fade-in animate-duration-250 select-none">
          <div className="grid grid-cols-2 gap-2">
          {NAV_LINKS.map(({ href, label }) => {
            const isActive = pathname === href;
            return (
              <Link
                key={href}
                href={href}
                className={cn(
                  "min-h-12 px-3 py-3 rounded-xl text-sm font-semibold transition-colors flex items-center justify-between",
                  isActive ? "bg-amber-400 text-zinc-950" : "bg-zinc-900/80 text-zinc-300 hover:bg-zinc-800 hover:text-white"
                )}
              >
                <span>{label}</span>
              </Link>
            );
          })}
          </div>

          <Link
            href={`/${currentLocale}/watchlist`}
            className={cn(
              "mt-2 min-h-12 px-4 py-3 rounded-xl text-sm font-semibold transition-colors flex items-center justify-between group",
              isWatchlistActive ? "border border-amber-400/40 bg-amber-400/10 text-white" : "bg-zinc-900/80 text-zinc-300 hover:bg-zinc-800 hover:text-white"
            )}
          >
            <div className="flex items-center gap-2">
              <svg className="w-4 h-5 text-white transition-colors group-hover:text-amber-400" viewBox="0 0 24 24" fill="currentColor">
                <path d="M17 3H7c-1.1 0-2 .9-2 2v16l7-3 7 3V5c0-1.1-.9-2-2-2z" />
                <path d="M13 7h-2v4H9v2h2v4h2v-4h2v-2h-2V7z" className="text-zinc-950" fill="currentColor" />
              </svg>
              <span>{dict.myWatchlist}</span>
            </div>
            {watchlistCount > 0 && (
              <span className="bg-amber-400 text-zinc-950 text-[10px] font-black px-1.5 py-0.5 rounded-full shadow-sm">
                {watchlistCount}
              </span>
            )}
          </Link>

          <div className="border-t border-zinc-900/60 pt-2.5 mt-1">
            <p className="px-4 py-1 text-[10px] font-black text-zinc-550 uppercase tracking-wider">
              Language / لغة
            </p>
            <div className="grid grid-cols-3 gap-2 px-4 mt-2">
              {LANGUAGES.map((lang) => (
                <button
                  key={lang.code}
                  onClick={() => handleLanguageChange(lang.code)}
                  type="button"
                  className={cn(
                    "min-h-10 py-2 text-xs font-black rounded-lg border text-center transition-all cursor-pointer outline-none uppercase",
                    currentLocale === lang.code 
                      ? "bg-amber-400 border-amber-400 text-zinc-950" 
                      : "bg-zinc-900/50 border-zinc-850 text-zinc-400 hover:text-white"
                  )}
                  title={lang.title}
                >
                  {lang.code}
                </button>
              ))}
            </div>
          </div>
          
          <button
            onClick={handleSurpriseMe}
            disabled={surpriseLoading}
            className="mt-2 flex min-h-12 w-full items-center gap-2 rounded-xl bg-zinc-900/80 px-4 py-3 text-left text-sm font-semibold text-zinc-300 transition-colors hover:bg-zinc-800 hover:text-amber-400 cursor-pointer select-none"
          >
            <span>{surpriseLoading ? "🎲 ..." : "🎲 Surprise Me"}</span>
          </button>
          
          <div className="mt-2">
            <SearchBox variant="mobile" locale={currentLocale} onNavigate={() => setMobileOpen(false)} />
          </div>
        </div>
      )}
    </header>
  );
}
