"use client";

import Link from "next/link";
import { useParams } from "next/navigation";
import { getDictionary } from "@/lib/i18n";

export function Footer() {
  const currentYear = new Date().getFullYear();
  const params = useParams();
  const locale = (params?.locale as string) || "ar";
  const dict = getDictionary(locale);

  return (
    <footer className="bg-zinc-950 border-t border-zinc-900 py-12 mt-16 text-zinc-500">
      <div className="max-w-[1400px] mx-auto px-4 md:px-8">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-12 items-start">
          
          {/* العمود الأول: اللوجو والوصف */}
          <div className="flex flex-col gap-4 items-center md:items-start text-center md:text-left">
            <Link href={`/${locale}`} className="flex items-center gap-2 group select-none">
              <div className="bg-amber-400 text-zinc-950 font-black text-sm px-2.5 py-0.5 rounded shadow-sm transition-transform group-hover:scale-105">
                AURA
              </div>
              <span className="text-white font-extrabold text-sm tracking-tight">Movie</span>
            </Link>
            <p className="text-xs leading-relaxed max-w-xs text-zinc-500 font-medium">
              {locale === 'ar' 
                ? "أورا موفي هو أكبر قاعدة بيانات مستقلة للأفلام والأنمي في العالم العربي، نوفر لك أدق المعلومات والتقييمات الحصرية." 
                : "AuraMovie is the premier independent database for movies and anime, offering accurate metadata and top-tier user experiences."}
            </p>
          </div>

          {/* العمود الثاني: روابط سريعة */}
          <nav className="flex flex-col items-center md:items-start gap-4">
            <h3 className="text-white font-bold text-xs uppercase tracking-widest border-b border-amber-400 pb-1">Navigation</h3>
            <div className="grid grid-cols-2 gap-x-8 gap-y-2 text-center md:text-left">
              <Link href={`/${locale}/movies`} className="hover:text-amber-400 transition-colors text-xs font-semibold">{dict.movies}</Link>
              <Link href={`/${locale}/series`} className="hover:text-amber-400 transition-colors text-xs font-semibold">{dict.series}</Link>
              <Link href={`/${locale}/anime`} className="hover:text-amber-400 transition-colors text-xs font-semibold">{dict.anime}</Link>
              <Link href={`/${locale}/request`} className="hover:text-amber-400 transition-colors text-xs font-semibold">{dict.requestTitle}</Link>
            </div>
          </nav>

          {/* العمود الثالث: صفحات الثقة (جوجل كيحماق عليهم) */}
          <nav className="flex flex-col items-center md:items-start gap-4">
            <h3 className="text-white font-bold text-xs uppercase tracking-widest border-b border-amber-400 pb-1">{dict.legalTrust}</h3>
            <div className="flex flex-col gap-2.5 text-center md:text-left">
              <Link href={`/${locale}/about`} className="hover:text-zinc-100 transition-colors text-xs font-medium">{dict.aboutUs}</Link>
              <Link href={`/${locale}/privacy`} className="hover:text-zinc-100 transition-colors text-xs font-medium">{dict.privacyPolicy}</Link>
              <Link href={`/${locale}/dmca`} className="hover:text-zinc-100 transition-colors text-xs font-medium">{dict.dmca}</Link>
            </div>
          </nav>
        </div>

        {/* الحقوق والنسب */}
        <div className="border-t border-zinc-900/60 mt-12 pt-8 flex flex-col md:flex-row justify-between items-center gap-6">
          <p className="text-[10px] font-black tracking-[0.2em] uppercase text-zinc-600">
            © {currentYear} AURAMOVIE. ALL RIGHTS RESERVED.
          </p>
          <p className="text-[10px] text-zinc-600 font-bold max-w-sm text-center md:text-right leading-relaxed">
            Data provided by <a href="https://www.themoviedb.org" target="_blank" rel="noreferrer" className="text-zinc-500 hover:text-amber-400">TMDB</a>. 
            AuraMovie does not host video files on its servers.
          </p>
        </div>
      </div>
    </footer>
  );
}