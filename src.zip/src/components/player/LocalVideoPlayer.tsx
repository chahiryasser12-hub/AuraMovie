"use client";

import { useState, useRef, useEffect } from "react";
import { cn } from "@/lib/utils";

interface SubtitleTrack {
  src: string;
  label: string;
  srcLang: string;
  default?: boolean;
}

interface LocalVideoPlayerProps {
  videoUrl: string;
  tmdbId: number;
  mediaType: "movie" | "tv";
  title: string;
  subtitles?: SubtitleTrack[];
  season?: number;
  episode?: number;
}

export function LocalVideoPlayer({
  videoUrl,
  tmdbId,
  mediaType,
  title,
  subtitles = [],
  season = 1,
  episode = 1,
}: LocalVideoPlayerProps) {
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [isCinemaMode, setIsCinemaMode] = useState(false);
  const videoRef = useRef<HTMLVideoElement>(null);
  const containerRef = useRef<HTMLDivElement>(null);

  // Monitor playback progress to update the "recently-watched" tracking system
  const handleTimeUpdate = () => {
    const video = videoRef.current;
    if (!video) return;

    const progress = (video.currentTime / video.duration) * 100;

    try {
      const rawHistory = localStorage.getItem("recently-watched") || "[]";
      const list = JSON.parse(rawHistory);

      // Check if item already exists in local storage
      const exists = list.some(
        (item: any) => String(item.id) === String(tmdbId) && item.type === mediaType
      );

      let updated;
      if (exists) {
        updated = list.map((item: any) => {
          if (String(item.id) === String(tmdbId) && item.type === mediaType) {
            return {
              ...item,
              progress: Math.round(progress),
              season: mediaType === "tv" ? season : undefined,
              episode: mediaType === "tv" ? episode : undefined,
              watchedAt: Date.now(),
            };
          }
          return item;
        });
      } else {
        // If it does not exist, add a fallback object
        updated = [
          {
            id: tmdbId,
            title,
            posterPath: null, // Poster will fall back to default or can be updated dynamically
            type: mediaType,
            progress: Math.round(progress),
            season: mediaType === "tv" ? season : undefined,
            episode: mediaType === "tv" ? episode : undefined,
            watchedAt: Date.now(),
          },
          ...list,
        ];
      }

      localStorage.setItem("recently-watched", JSON.stringify(updated.slice(0, 12)));
    } catch (err) {
      console.warn("Could not save playback history", err);
    }
  };

  const toggleFullscreen = () => {
    if (!containerRef.current) return;
    if (!isFullscreen) {
      containerRef.current.requestFullscreen?.();
      setIsFullscreen(true);
    } else {
      document.exitFullscreen?.();
      setIsFullscreen(false);
    }
  };

  // Adjust local state if the user exits fullscreen using system keys (like ESC)
  useEffect(() => {
    const handleFullscreenChange = () => {
      setIsFullscreen(document.fullscreenElement === containerRef.current);
    };
    document.addEventListener("fullscreenchange", handleFullscreenChange);
    return () => {
      document.removeEventListener("fullscreenchange", handleFullscreenChange);
      setIsCinemaMode(false);
    };
  }, []);

  return (
    <div className="flex flex-col gap-5">
      {/* Cinema Mode Dark Overlay */}
      {isCinemaMode && (
        <div
          onClick={() => setIsCinemaMode(false)}
          className="fixed inset-0 bg-black/98 backdrop-blur-sm z-40 transition-all duration-500 cursor-pointer animate-fade-in"
          title="Click to turn on the lights"
        />
      )}

      {/* Video Container */}
      <div
        ref={containerRef}
        className={cn(
          "relative w-full bg-black rounded-2xl overflow-hidden border transition-all duration-350",
          isCinemaMode
            ? "z-50 border-amber-400/40 shadow-[0_0_50px_rgba(245,197,24,0.15)] scale-[1.01]"
            : "z-30 border-zinc-900 shadow-2xl"
        )}
        style={{ aspectRatio: "16/9" }}
      >
        <video
          ref={videoRef}
          src={videoUrl}
          className="absolute inset-0 w-full h-full"
          controls
          crossOrigin="anonymous" // Essential for loading WebVTT track files from other domains/CDNs
          onTimeUpdate={handleTimeUpdate}
          preload="metadata"
        >
          {subtitles.map((track, idx) => (
            <track
              key={idx}
              kind="subtitles"
              src={track.src}
              label={track.label}
              srcLang={track.srcLang}
              default={track.default}
            />
          ))}
          Your browser does not support HTML5 video playback.
        </video>

        {/* Custom Controller Buttons overlayed on video header */}
        <div className="absolute top-3 right-3 md:top-4 md:right-4 z-20 flex gap-1.5">
          <button
            onClick={() => setIsCinemaMode(!isCinemaMode)}
            className={cn(
              "w-8 h-8 md:w-10 md:h-10 backdrop-blur-md rounded-xl flex items-center justify-center border transition-all hover:scale-105 active:scale-95 cursor-pointer",
              isCinemaMode
                ? "bg-amber-400 text-zinc-950 border-amber-400 shadow-lg shadow-amber-400/20"
                : "bg-black/60 text-zinc-300 border-white/5 hover:bg-black/80 hover:text-white"
            )}
            title={isCinemaMode ? "Turn on Lights" : "Cinema Mode (Lights Out)"}
          >
            <svg className="w-4 h-4 md:w-5 md:h-5 fill-current" viewBox="0 0 24 24">
              <path d="M12 22c1.1 0 2-.9 2-2h-4c0 1.1.9 2 2 2zm6-6v-5c0-3.07-1.64-5.64-4.5-6.32V4c0-.83-.67-1.5-1.5-1.5s-1.5.67-1.5 1.5v.68C7.63 5.36 6 7.92 6 11v5l-2 2v1h16v-1l-2-2z" />
            </svg>
          </button>

          <button
            onClick={toggleFullscreen}
            className="w-8 h-8 md:w-10 md:h-10 bg-black/60 hover:bg-black/80 border border-white/5 backdrop-blur-md rounded-xl flex items-center justify-center text-white transition-all hover:scale-105 active:scale-95 cursor-pointer"
            title="Full Screen"
          >
            <svg className="w-4 h-4 md:w-5 md:h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                strokeWidth={2.2}
                d={
                  isFullscreen
                    ? "M8 3v3a2 2 0 01-2 2H3m18 0h-3a2 2 0 01-2-2V3m0 18v-3a2 2 0 012-2h3M3 16h3a2 2 0 012 2v3"
                    : "M4 8V4m0 0h4M4 4l5 5m11-1V4m0 0h-4m4 0l-5 5M4 16v4m0 0h4m-4 0l5-5m11 5l-5-5m5 5v-4m0 4h-4"
                }
              />
            </svg>
          </button>
        </div>
      </div>
    </div>
  );
}