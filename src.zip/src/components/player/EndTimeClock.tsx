"use client";

import { useState, useEffect } from "react";

interface EndTimeClockProps {
  runtimeMinutes: number;
}

export function EndTimeClock({ runtimeMinutes }: EndTimeClockProps) {
  const [endTime, setEndTime] = useState<string>("");

  useEffect(() => {
    const calculateTime = () => {
      const now = new Date();
      const finish = new Date(now.getTime() + runtimeMinutes * 60 * 1000);
      setEndTime(
        finish.toLocaleTimeString("en-US", {
          hour: "numeric",
          minute: "2-digit",
          hour12: true,
        })
      );
    };

    calculateTime();
    // Update calculation every 30 seconds
    const interval = setInterval(calculateTime, 30000);
    return () => clearInterval(interval);
  }, [runtimeMinutes]);

  if (!runtimeMinutes || !endTime) return null;

  return (
    <div className="flex items-center gap-2 bg-zinc-900/60 border border-zinc-800 rounded-xl px-4 py-2.5 text-zinc-400 text-xs select-none w-full shadow-sm">
      <span className="text-amber-400 text-sm animate-pulse">🕒</span>
      <span>
        Ready to watch? If you start now, you&apos;ll finish at{" "}
        <strong className="text-zinc-100 font-extrabold">{endTime}</strong>.
      </span>
    </div>
  );
}