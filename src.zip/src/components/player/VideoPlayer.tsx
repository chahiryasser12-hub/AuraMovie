"use client";

import { useState, useRef, useEffect } from "react";
import { EMBED_PROVIDERS } from "@/config/providers";
import { ProviderSelector } from "@/components/ui/ProviderSelector";
import { DEFAULT_PROVIDER_ID } from "@/config/providers";
import { getImageUrl } from "@/lib/tmdb";
import type { TMDBSeason } from "@/types/tmdb";
import { cn } from "@/lib/utils";

interface VideoPlayerProps {
  tmdbId: number;
  mediaType: "movie" | "tv";
  title: string;
  season?: number;
  episode?: number;
  totalSeasons?: number;
  seasonsData?: TMDBSeason[];
  onEpisodeChange?: (season: number, episode: number) => void;
}

export function VideoPlayer({
  tmdbId,
  mediaType,
  title,
  season = 1,
  episode = 1,
  totalSeasons,
  seasonsData,
  onEpisodeChange,
}: VideoPlayerProps) {
  const [selectedProviderId, setSelectedProviderId] = useState(DEFAULT_PROVIDER_ID);
  const [currentSeason, setCurrentSeason] = useState(season);
  const [currentEpisode, setCurrentEpisode] = useState(episode);
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [isCinemaMode, setIsCinemaMode] = useState(false);
  const [loaded, setLoaded] = useState(false);
  const iframeRef = useRef<HTMLIFrameElement>(null);
  const containerRef = useRef<HTMLDivElement>(null);

  const provider = EMBED_PROVIDERS.find((p) => p.id === selectedProviderId) || EMBED_PROVIDERS[0];

  const embedUrl =
    mediaType === "movie"
      ? provider.getMovieUrl(tmdbId)
      : provider.getSeriesUrl(tmdbId, currentSeason, currentEpisode);

  const validSeasons = seasonsData?.filter((s) => s.season_number > 0) || [];
  const currentSeasonInfo = validSeasons.find((s) => s.season_number === currentSeason);
  const maxEpisodes = currentSeasonInfo ? currentSeasonInfo.episode_count : 24;

  const handleEpisodeChange = (s: number, e: number) => {
    setCurrentSeason(s);
    setCurrentEpisode(e);
    onEpisodeChange?.(s, e);
  };

  const handleProviderChange = (id: string) => {
    setSelectedProviderId(id);
  };

  const toggleFullscreen = () => {
    if (!containerRef.current) return;
    if (!isFullscreen) {
      containerRef.current.requestFullscreen?.();
      setIsFullscreen(true);
    } else {
      document.exitFullscreen?.();
      setIsFullscreen(false);
    }
  };

  useEffect(() => {
    return () => setIsCinemaMode(false);
  }, []);

  useEffect(() => {
    setLoaded(false);
    const failSafeTimer = setTimeout(() => {
      setLoaded(true);
    }, 5000);
    return () => clearTimeout(failSafeTimer);
  }, [embedUrl]);

  useEffect(() => {
    const handleWatchProgressEvents = (event: MessageEvent) => {
      try {
        if (typeof event.data !== "string") return;
        const data = JSON.parse(event.data);

        if (data && String(data.id) === String(tmdbId)) {
          setLoaded(true);

          if (data.progress !== undefined) {
            const rawHistory = localStorage.getItem("recently-watched") || "[]";
            const list = JSON.parse(rawHistory);

            const updated = list.map((item: any) => {
              if (String(item.id) === String(tmdbId) && item.type === mediaType) {
                return {
                  ...item,
                  progress: Math.round(data.progress),
                  season: mediaType === "tv" ? data.season || currentSeason : undefined,
                  episode: mediaType === "tv" ? data.episode || currentEpisode : undefined,
                  watchedAt: Date.now(),
                };
              }
              return item;
            });

            localStorage.setItem("recently-watched", JSON.stringify(updated));
          }
        }
      } catch {
        // Safe bypass
      }
    };

    window.addEventListener("message", handleWatchProgressEvents);
    return () => {
      window.removeEventListener("message", handleWatchProgressEvents);
    };
  }, [tmdbId, mediaType, currentSeason, currentEpisode]);

  const episodesList = Array.from({ length: maxEpisodes }, (_, i) => i + 1);

  return (
    <div className="flex flex-col gap-5">
      {isCinemaMode && (
        <div 
          onClick={() => setIsCinemaMode(false)}
          className="fixed inset-0 bg-black/98 backdrop-blur-sm z-40 transition-all duration-500 cursor-pointer animate-fade-in"
          title="Click to turn on the lights"
        />
      )}

      {/* Video Container Area */}
      <div
        ref={containerRef}
        className={cn(
          "relative w-full bg-black rounded-2xl overflow-hidden border transition-all duration-350",
          isCinemaMode 
            ? "z-50 border-amber-400/40 shadow-[0_0_50px_rgba(245,197,24,0.15)] scale-[1.01]" 
            : "z-30 border-zinc-900 shadow-2xl"
        )}
        style={{ aspectRatio: "16/9" }}
      >
        {!loaded && (
          <div className="absolute inset-0 bg-zinc-950/95 flex flex-col items-center justify-center gap-4 z-10 pointer-events-none select-none">
            <div className="relative flex items-center justify-center">
              <div className="w-12 h-16 md:w-16 md:h-16 rounded-full border-4 border-zinc-800 border-t-amber-400 animate-spin" />
              <svg className="w-5 h-5 md:w-6 md:h-6 text-amber-400 fill-current absolute" viewBox="0 0 24 24">
                <path d="M8 5v14l11-7z" />
              </svg>
            </div>
            <p className="text-zinc-400 font-bold text-xs md:text-sm tracking-wide text-center px-4">
              Loading stream from <span className="text-amber-400 font-extrabold">{provider.name}</span>...
            </p>
          </div>
        )}

        <iframe
          ref={iframeRef}
          src={embedUrl}
          className="absolute inset-0 w-full h-full"
          allowFullScreen
          allow="autoplay; encrypted-media; picture-in-picture"
          title={title}
          onLoad={() => setLoaded(true)}
          loading="lazy"
          // Sandbox removed to satisfy rigid third-party anti-sandbox detectors and allow streaming
        />

        <div className="absolute top-3 right-3 md:top-4 md:right-4 z-20 flex gap-1.5">
          <button
            onClick={() => setIsCinemaMode(!isCinemaMode)}
            className={cn(
              "w-8 h-8 md:w-10 md:h-10 backdrop-blur-md rounded-xl flex items-center justify-center border transition-all hover:scale-105 active:scale-95 cursor-pointer",
              isCinemaMode 
                ? "bg-amber-400 text-zinc-950 border-amber-400 shadow-lg shadow-amber-400/20" 
                : "bg-black/60 text-zinc-300 border-white/5 hover:bg-black/80 hover:text-white"
            )}
            title={isCinemaMode ? "Turn on Lights" : "Cinema Mode (Lights Out)"}
          >
            <svg className="w-4 h-4 md:w-5 md:h-5 fill-current" viewBox="0 0 24 24">
              <path d="M12 22c1.1 0 2-.9 2-2h-4c0 1.1.9 2 2 2zm6-6v-5c0-3.07-1.64-5.64-4.5-6.32V4c0-.83-.67-1.5-1.5-1.5s-1.5.67-1.5 1.5v.68C7.63 5.36 6 7.92 6 11v5l-2 2v1h16v-1l-2-2z" />
            </svg>
          </button>

          <button
            onClick={toggleFullscreen}
            className="w-8 h-8 md:w-10 md:h-10 bg-black/60 hover:bg-black/80 border border-white/5 backdrop-blur-md rounded-xl flex items-center justify-center text-white transition-all hover:scale-105 active:scale-95 cursor-pointer"
            title="Full Screen"
          >
            <svg className="w-4 h-4 md:w-5 md:h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                strokeWidth={2.2}
                d={
                  isFullscreen
                    ? "M8 3v3a2 2 0 01-2 2H3m18 0h-3a2 2 0 01-2-2V3m0 18v-3a2 2 0 012-2h3M3 16h3a2 2 0 012 2v3"
                    : "M4 8V4m0 0h4M4 4l5 5m11-1V4m0 0h-4m4 0l-5 5M4 16v4m0 0h4m-4 0l5-5m11 5l-5-5m5 5v-4m0 4h-4"
                }
              />
            </svg>
          </button>
        </div>
      </div>

      {/* Stream Source Panel */}
      <div className="flex flex-col gap-3.5 bg-zinc-950/40 border border-zinc-900 rounded-2xl p-4 md:p-5 relative z-30">
        <div className="flex items-center gap-2">
          <div className="w-1 h-3.5 bg-amber-400 rounded-full" />
          <p className="text-xs md:text-sm font-bold text-zinc-200 tracking-wider uppercase">
            Stream Source
          </p>
        </div>
        
        <ProviderSelector
          selectedId={selectedProviderId}
          onSelect={handleProviderChange}
        />
        
        <p className="text-[10px] text-zinc-500 font-semibold select-none leading-relaxed">
          If you experience playback lag or failure, please switch to alternative stream sources above.
        </p>
      </div>

      {/* Episode / Seasons Lists (Only for TV series) */}
      {mediaType === "tv" && validSeasons.length > 0 && (
        <div className="flex flex-col gap-6 md:gap-8 w-full mt-1 relative z-30">
          
          {/* Episode List Section */}
          <div>
            <h3 className="text-sm md:text-base font-black text-white mb-4 border-l-4 border-amber-400 pl-2.5 uppercase tracking-widest flex items-center gap-2">
              Episode List
            </h3>
            
            <div className="grid grid-cols-4 sm:grid-cols-6 md:grid-cols-8 gap-2">
              {episodesList.map((epNum) => {
                const isActive = currentEpisode === epNum;
                return (
                  <button
                    key={epNum}
                    type="button"
                    onClick={() => handleEpisodeChange(currentSeason, epNum)}
                    className={cn(
                      "py-2 md:py-3 px-1 rounded-xl text-center border text-[11px] md:text-sm font-bold cursor-pointer transition-all active:scale-95 select-none",
                      isActive
                        ? "bg-amber-400 text-zinc-950 border-amber-400 shadow-lg shadow-amber-400/10"
                        : "bg-zinc-950/40 border-zinc-900 text-zinc-400 hover:border-zinc-700 hover:text-white hover:bg-zinc-900"
                    )}
                  >
                    Ep {epNum}
                  </button>
                );
              })}
            </div>
          </div>

          {/* Series Seasons list */}
          <div className="border-t border-zinc-900/60 pt-5 md:pt-6">
            <h3 className="text-sm md:text-base font-black text-white mb-3 border-l-4 border-amber-400 pl-2.5 uppercase tracking-widest">
              Series Seasons
            </h3>
            
            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-5 gap-3">
              {validSeasons.map((s) => {
                const isSelected = currentSeason === s.season_number;
                const posterUrl = getImageUrl(s.poster_path, "w300");

                return (
                  <button
                    key={s.id}
                    type="button"
                    onClick={() => handleEpisodeChange(s.season_number, 1)}
                    className="flex flex-col gap-1.5 text-left group outline-none cursor-pointer"
                  >
                    <div
                      className={cn(
                        "relative aspect-[2/3] w-full rounded-xl overflow-hidden bg-zinc-900 transition-all duration-300 shadow-xl border",
                        isSelected
                          ? "border-amber-400 scale-[1.02] ring-4 ring-amber-400/15"
                          : "border-zinc-900 group-hover:border-zinc-700"
                      )}
                    >
                      <img
                        src={posterUrl}
                        alt={s.name}
                        className="object-cover w-full h-full"
                        loading="lazy"
                      />
                      <div className="absolute bottom-1.5 right-1.5 bg-amber-400 text-zinc-950 text-[8px] font-black px-1.5 py-0.5 rounded tracking-wide uppercase">
                        Series
                      </div>
                    </div>
                    
                    <div className="px-0.5">
                      <p
                        className={cn(
                          "text-[11px] md:text-sm font-bold truncate transition-colors",
                          isSelected ? "text-amber-400" : "text-zinc-200 group-hover:text-amber-400"
                        )}
                      >
                        {title} {s.name}
                      </p>
                      <p className="text-[9px] text-zinc-500 font-bold mt-0.5 uppercase tracking-wide">
                        {s.episode_count} Episodes
                      </p>
                    </div>
                  </button>
                );
              })}
            </div>
          </div>

        </div>
      )}
    </div>
  );
}