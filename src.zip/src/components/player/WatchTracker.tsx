"use client";

import { useEffect } from "react";

interface WatchTrackerProps {
  id: number;
  title: string;
  posterPath: string | null;
  type: "movie" | "tv";
  season?: number;
  episode?: number;
}

export function WatchTracker({ id, title, posterPath, type, season, episode }: WatchTrackerProps) {
  useEffect(() => {
    try {
      const list = JSON.parse(localStorage.getItem("recently-watched") || "[]");
      const filtered = list.filter((item: any) => !(item.id === id && item.type === type));
      
      filtered.unshift({
        id,
        title,
        posterPath,
        type,
        season: type === "tv" ? season || 1 : undefined,
        episode: type === "tv" ? episode || 1 : undefined,
        watchedAt: Date.now()
      });

      // Keep only last 12 items to save storage
      localStorage.setItem("recently-watched", JSON.stringify(filtered.slice(0, 12)));
    } catch (err) {
      console.error("Failed to update recently watched", err);
    }
  }, [id, title, posterPath, type, season, episode]);

  return null;
}