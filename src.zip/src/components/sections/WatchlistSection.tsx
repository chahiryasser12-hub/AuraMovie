"use client";

import { useEffect, useState } from "react";
import Image from "next/image";
import Link from "next/link";
import { useParams } from "next/navigation";
import { getImageUrl } from "@/lib/tmdb";

export function WatchlistSection() {
  const [items, setItems] = useState<any[]>([]);
  const [mounted, setMounted] = useState(false);
  const { locale = "en" } = useParams() as { locale?: string };

  useEffect(() => {
    setMounted(true);
    const list = JSON.parse(localStorage.getItem("watchlist") || "[]");
    setItems(list);
  }, []);

  if (!mounted || items.length === 0) return null;

  return (
    <section className="py-6 px-4 md:px-8 border-t border-zinc-900">
      <h2 className="text-base font-black text-white border-l-4 border-amber-400 pl-3 uppercase tracking-widest mb-5">
        My List
      </h2>
      <div className="flex gap-4 overflow-x-auto scrollbar-hide pb-2">
        {items.map((item) => {
          const detailUrl = item.type === "tv" ? `/${locale}/series/${item.id}` : `/${locale}/movies/${item.id}`;

          return (
            <Link
              key={`${item.type}-${item.id}`}
              href={detailUrl}
              className="flex-shrink-0 group relative w-32"
            >
              <div className="relative aspect-[2/3] rounded-xl overflow-hidden bg-zinc-800 shadow-lg transition-transform duration-300 group-hover:scale-[1.03]">
                <Image
                  src={getImageUrl(item.posterPath, "w300")}
                  alt={item.title}
                  fill
                  className="object-cover"
                  unoptimized
                />
              </div>
              <div className="mt-2 px-0.5">
                <p className="text-white text-xs font-bold truncate group-hover:text-amber-400 transition-colors">
                  {item.title}
                </p>
              </div>
            </Link>
          );
        })}
      </div>
    </section>
  );
}