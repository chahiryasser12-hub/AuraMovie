"use client";

import { useState, useRef } from "react";
import Link from "next/link";
import Image from "next/image";
import { useParams } from "next/navigation";
import type { TMDBMovie, TMDBSeries } from "@/types/tmdb";
import { getImageUrl } from "@/lib/tmdb";
import { formatYear, formatVoteAverage, getRatingColor, cn } from "@/lib/utils";

type TrendingItem = (TMDBMovie | TMDBSeries) & { media_type?: string };

function isMovie(item: TrendingItem): item is TMDBMovie {
  return "title" in item;
}

interface TrendingSectionProps {
  movies: TMDBMovie[];
  series: TMDBSeries[];
}

export function TrendingSection({ movies, series }: TrendingSectionProps) {
  const [activeTab, setActiveTab] = useState<"movies" | "series">("movies");
  const scrollRef = useRef<HTMLDivElement>(null);
  const { locale = "en" } = useParams() as { locale?: string };

  const items: TrendingItem[] = activeTab === "movies" ? movies : series;

  const scroll = (direction: "left" | "right") => {
    if (!scrollRef.current) return;
    const amount = 300;
    scrollRef.current.scrollBy({
      left: direction === "left" ? -amount : amount,
      behavior: "smooth",
    });
  };

  return (
    <section className="py-8">
      <div className="flex items-center justify-between mb-5 px-4 md:px-8">
        <div className="flex items-center gap-4">
          <h2 className="text-base font-black text-white border-l-4 border-amber-400 pl-3 uppercase tracking-widest">
            Trending
          </h2>
          
          <div className="flex bg-zinc-950 border border-zinc-900 rounded-lg p-0.5">
            <button
              onClick={() => setActiveTab("movies")}
              className={cn(
                "px-4 py-1.5 text-xs font-semibold rounded-md transition-all duration-200 cursor-pointer",
                activeTab === "movies"
                  ? "bg-amber-400 text-zinc-950 shadow font-bold"
                  : "text-zinc-500 hover:text-white"
              )}
            >
              Movies
            </button>
            <button
              onClick={() => setActiveTab("series")}
              className={cn(
                "px-4 py-1.5 text-xs font-semibold rounded-md transition-all duration-200 cursor-pointer",
                activeTab === "series"
                  ? "bg-amber-400 text-zinc-950 shadow font-bold"
                  : "text-zinc-500 hover:text-white"
              )}
            >
              Series
            </button>
          </div>
        </div>
        
        {/* Navigation triggers */}
        <div className="hidden md:flex gap-2">
          <button
            type="button"
            onClick={() => scroll("left")}
            aria-label="Scroll trending titles left"
            className="w-8 h-8 rounded-full bg-zinc-900 hover:bg-zinc-800 text-white flex items-center justify-center transition-colors cursor-pointer"
          >
            <svg aria-hidden="true" className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M15 19l-7-7 7-7" />
            </svg>
          </button>
          <button
            type="button"
            onClick={() => scroll("right")}
            aria-label="Scroll trending titles right"
            className="w-8 h-8 rounded-full bg-zinc-800 hover:bg-zinc-700 text-white flex items-center justify-center transition-colors cursor-pointer"
          >
            <svg aria-hidden="true" className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M9 5l7 7-7 7" />
            </svg>
          </button>
        </div>
      </div>

      <div
        ref={scrollRef}
        className="flex gap-4 overflow-x-auto scrollbar-hide px-4 md:px-8 pb-2"
        style={{ scrollbarWidth: "none", msOverflowStyle: "none" }}
      >
        {items.slice(0, 8).map((item, idx) => {
          const movie = isMovie(item);
          const title = movie 
            ? (item as TMDBMovie).original_title || (item as TMDBMovie).title 
            : (item as TMDBSeries).original_name || (item as TMDBSeries).name;

          const date = movie ? (item as TMDBMovie).release_date : (item as TMDBSeries).first_air_date;
          const href = movie ? `/${locale}/movies/${item.id}` : `/${locale}/series/${item.id}`;
          const posterUrl = getImageUrl(item.poster_path, "w300");

          return (
            <Link
              key={item.id}
              href={href}
              className="flex-shrink-0 group relative bg-zinc-950/40 border border-zinc-900 hover:border-zinc-700/60 p-2 rounded-2xl transition-all duration-200"
              style={{ width: "152px" }}
            >
              <div className="relative overflow-hidden rounded-xl bg-zinc-800 aspect-[2/3] shadow transition-transform duration-300 group-hover:scale-[1.02]">
                <div className="absolute top-0 left-0 z-10 bg-black/80 backdrop-blur-sm w-8 h-8 flex items-center justify-center rounded-br-xl border-r border-b border-white/5">
                  <span className="text-white font-black text-xs leading-none">{idx + 1}</span>
                </div>
                <Image
                  src={posterUrl}
                  alt={title}
                  fill
                  sizes="152px"
                  className="object-cover"
                  loading="lazy"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
                <div className="absolute bottom-2 right-2 bg-black/80 rounded-lg px-2 py-0.5 flex items-center gap-0.5">
                  <svg className="w-2.5 h-2.5 text-amber-400 fill-current" viewBox="0 0 24 24">
                    <path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z" />
                  </svg>
                  <span className={cn("text-[10px] font-extrabold", getRatingColor(item.vote_average))}>
                    {formatVoteAverage(item.vote_average)}
                  </span>
                </div>
              </div>
              <div className="mt-2 px-1">
                <p className="text-white text-xs font-bold line-clamp-1 group-hover:text-amber-400 transition-colors">
                  {title}
                </p>
                <p className="text-zinc-550 font-bold text-[10px] mt-0.5">{formatYear(date)}</p>
              </div>
            </Link>
          );
        })}
      </div>
    </section>
  );
}
