"use client";

import { useRef } from "react";
import { AnimeCard } from "@/components/media/AnimeCard";
import type { TMDBSeries, TMDBMovie } from "@/types/tmdb";

interface AnimeGenreSectionProps {
  title: string;
  items: (TMDBSeries | TMDBMovie)[];
  type?: "tv" | "movie";
}

export function AnimeGenreSection({ title, items, type = "tv" }: AnimeGenreSectionProps) {
  const scrollRef = useRef<HTMLDivElement>(null);

  const scroll = (direction: "left" | "right") => {
    if (!scrollRef.current) return;
    const amount = 340;
    scrollRef.current.scrollBy({
      left: direction === "left" ? -amount : amount,
      behavior: "smooth",
    });
  };

  if (!items || items.length === 0) return null;

  return (
    <section className="py-8 border-t border-zinc-900/60 mt-12">
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-4 mb-6 px-4 md:px-8">
        <div className="select-none">
          <h2 className="text-xl font-black text-white border-l-4 border-amber-400 pl-3 uppercase tracking-wider">
            {title}
          </h2>
        </div>

        {/* Navigation Triggers */}
        <div className="hidden md:flex gap-1.5 self-end">
          <button
            type="button"
            onClick={() => scroll("left")}
            aria-label={`Scroll ${title} left`}
            className="w-8 h-8 rounded-full bg-zinc-900 hover:bg-zinc-800 text-white flex items-center justify-center border border-zinc-850 hover:border-zinc-700 transition-all cursor-pointer"
          >
            <svg aria-hidden="true" className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M15 19l-7-7 7-7" />
            </svg>
          </button>
          <button
            type="button"
            onClick={() => scroll("right")}
            aria-label={`Scroll ${title} right`}
            className="w-8 h-8 rounded-full bg-zinc-900 hover:bg-zinc-800 text-white flex items-center justify-center border border-zinc-850 hover:border-zinc-700 transition-all cursor-pointer"
          >
            <svg aria-hidden="true" className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M9 5l7 7-7 7" />
            </svg>
          </button>
        </div>
      </div>

      <div
        ref={scrollRef}
        className="flex gap-4 overflow-x-auto scrollbar-hide px-4 md:px-8 pb-3"
        style={{ scrollbarWidth: "none", msOverflowStyle: "none" }}
      >
        {items.map((item) => (
          <div key={`${type}-${item.id}`} className="w-[172px] flex-shrink-0">
            <AnimeCard anime={item} type={type} />
          </div>
        ))}
      </div>
    </section>
  );
}
