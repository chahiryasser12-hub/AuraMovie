import Link from "next/link";
import type { TMDBSeries } from "@/types/tmdb";
import { SeriesCard } from "@/components/media/SeriesCard";

interface TopRatedSectionProps {
  series: TMDBSeries[];
}

export function TopRatedSection({ series }: TopRatedSectionProps) {
  return (
    <section className="py-8 px-4 md:px-8">
      <div className="flex items-center justify-between mb-5">
        <h2 className="text-base font-black text-white border-l-4 border-[#FF1E46] pl-3 uppercase tracking-widest">
          Top Rated Series
        </h2>
        <Link
          href="/series"
          className="text-xs font-bold text-zinc-400 hover:text-[#FF1E46] transition-colors flex items-center gap-1 uppercase tracking-wider"
        >
          View All
          <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M9 5l7 7-7 7" />
          </svg>
        </Link>
      </div>
      <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-4" style={{ contentVisibility: "auto", containIntrinsicSize: "850px" }}>
        {series.slice(0, 8).map((s) => (
          <SeriesCard key={s.id} series={s} />
        ))}
      </div>
    </section>
  );
}
