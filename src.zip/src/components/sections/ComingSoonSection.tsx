"use client";

import { useState } from "react";
import Image from "next/image";
import { getImageUrl } from "@/lib/tmdb";
import { formatYear, cn } from "@/lib/utils";
import type { TMDBMovie, TMDBSeries } from "@/types/tmdb";

interface ComingSoonSectionProps {
  movies: TMDBMovie[];
  anime: TMDBSeries[];
  locale: string;
}

export function ComingSoonSection({ movies, anime, locale }: ComingSoonSectionProps) {
  const [activeTab, setActiveTab] = useState<"movies" | "anime">("movies");
  const [isOpen, setIsOpen] = useState(false);
  const [activeVideoKey, setActiveVideoKey] = useState<string | null>(null);
  const [loadingId, setLoadingId] = useState<number | null>(null);

  const isAr = locale === "ar";
  const items = activeTab === "movies" ? movies : anime;

  // دالة جلب وعرض التريلر مباشرة فالموقع
  const handlePlayTrailer = async (id: number, mediaType: "movie" | "tv") => {
    setLoadingId(id);
    try {
      const res = await fetch(`/api/tmdb/details/${id}?type=${mediaType}`);
      if (!res.ok) throw new Error();
      
      // We cast the parsed JSON to satisfy the TypeScript compiler
      const data = (await res.json()) as any;
      
      const videos = data.videos?.results || [];
      // البحث عن Trailer رسمي من يوتيوب أولاً، وإلا نأخذ أول فيديو يوتيوب متاح
      const trailer = videos.find((v: any) => v.type === "Trailer" && v.site === "YouTube") 
                   || videos.find((v: any) => v.site === "YouTube");
      
      if (trailer && trailer.key) {
        setActiveVideoKey(trailer.key);
        setIsOpen(true);
      } else {
        alert(isAr ? "المقطع الدعائي غير متوفر حالياً لهذا العمل." : "Trailer not available for this title.");
      }
    } catch (err) {
      console.error(err);
    } finally {
      setLoadingId(null);
    }
  };

  if (!items || items.length === 0) return null;

  return (
    <section className="py-8 px-4 md:px-8 border-t border-zinc-900 mt-6 select-none">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-6">
        <div>
          <h2 className="text-xl font-black text-white border-l-4 border-amber-400 pl-3 uppercase tracking-widest flex items-center gap-2">
            ⏳ {isAr ? "قريباً / إصدارات 2026" : "Coming Soon / 2026 Releases"}
          </h2>
          <p className="text-zinc-550 text-xs mt-1 font-medium">
            {isAr ? "شاهد العروض الدعائية الحصرية لأحدث الأفلام والأنميات القادمة قريباً." : "Watch exclusive official trailers for highly anticipated upcoming movies and anime."}
          </p>
        </div>

        {/* أزرار التبديل الفخمة */}
        <div className="flex bg-zinc-900/60 border border-zinc-850 rounded-xl p-1 self-start sm:self-auto">
          <button
            onClick={() => setActiveTab("movies")}
            className={cn(
              "px-4 py-2 text-xs font-semibold rounded-lg transition-all duration-200 cursor-pointer whitespace-nowrap",
              activeTab === "movies"
                ? "bg-amber-400 text-zinc-950 font-bold shadow-md"
                : "text-zinc-400 hover:text-white"
            )}
          >
            🎬 {isAr ? "أفلام قادمة" : "Upcoming Movies"}
          </button>
          <button
            onClick={() => setActiveTab("anime")}
            className={cn(
              "px-4 py-2 text-xs font-semibold rounded-lg transition-all duration-200 cursor-pointer whitespace-nowrap",
              activeTab === "anime"
                ? "bg-amber-400 text-zinc-950 font-bold shadow-md"
                : "text-zinc-400 hover:text-white"
            )}
          >
            🌸 {isAr ? "أنمي قادم" : "Upcoming Anime"}
          </button>
        </div>
      </div>

      {/* شريط السحب الأفقي الفخم */}
      <div className="flex gap-4 overflow-x-auto scrollbar-hide pb-4">
        {items.slice(0, 15).map((item) => {
          const title = "title" in item ? item.title : item.name;
          const date = "release_date" in item ? item.release_date : item.first_air_date;
          const year = formatYear(date);
          const posterUrl = getImageUrl(item.poster_path, "w300");
          const mediaType = activeTab === "movies" ? "movie" : "tv";

          return (
            <div
              key={item.id}
              className="flex-shrink-0 w-36 group relative flex flex-col bg-zinc-900/20 border border-zinc-900 rounded-2xl overflow-hidden p-2.5 transition-all hover:border-amber-400/40"
            >
              <div className="relative aspect-[2/3] rounded-xl overflow-hidden bg-zinc-800">
                <Image
                  src={posterUrl}
                  alt={title}
                  fill
                  className="object-cover transition-transform duration-500 group-hover:scale-103"
                  unoptimized
                />

                {/* زر تشغيل التريلر يظهر عند مرور الفأرة */}
                <div className="absolute inset-0 bg-black/60 flex flex-col items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity p-2">
                  <button
                    onClick={() => handlePlayTrailer(item.id, mediaType)}
                    disabled={loadingId === item.id}
                    className="w-11 h-11 bg-amber-400 hover:bg-amber-500 text-zinc-950 rounded-full flex items-center justify-center shadow-xl transition-transform hover:scale-105 disabled:opacity-50 cursor-pointer"
                    title={isAr ? "شاهد الإعلان" : "Watch Trailer"}
                  >
                    {loadingId === item.id ? (
                      <svg className="w-5 h-5 animate-spin" fill="none" viewBox="0 0 24 24">
                        <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" />
                        <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4z" />
                      </svg>
                    ) : (
                      <svg className="w-5 h-5 fill-current ml-0.5" viewBox="0 0 24 24">
                        <path d="M8 5v14l11-7z" />
                      </svg>
                    )}
                  </button>
                  <span className="text-[10px] text-amber-400 font-extrabold tracking-wider uppercase mt-2.5">
                    {isAr ? "شاهد الإعلان" : "Trailer"}
                  </span>
                </div>
              </div>

              <div className="mt-2.5 px-1 flex-1 flex flex-col justify-between">
                <p className="text-white text-xs font-bold line-clamp-2 leading-snug group-hover:text-amber-400 transition-colors">
                  {title}
                </p>
                <p className="text-zinc-550 text-[10px] font-bold mt-1.5 border-t border-zinc-900/60 pt-1">
                  {year !== "Unknown" ? year : "2026/Upcoming"}
                </p>
              </div>
            </div>
          );
        })}
      </div>

      {/* مشغل التريلر المنبثق التفاعلي داخل موقعك */}
      {isOpen && activeVideoKey && (
        <div 
          onClick={() => { setIsOpen(false); setActiveVideoKey(null); }}
          className="fixed inset-0 bg-black/95 backdrop-blur-md z-[9999] flex items-center justify-center p-4 animate-fade-in"
        >
          <div 
            onClick={(e) => e.stopPropagation()} 
            className="relative w-full max-w-4xl aspect-video bg-black rounded-2xl overflow-hidden border border-zinc-800 shadow-2xl"
          >
            <button
              onClick={() => { setIsOpen(false); setActiveVideoKey(null); }}
              className="absolute top-3 right-3 md:top-4 md:right-4 z-50 bg-black/60 hover:bg-zinc-800 text-white rounded-full w-9 h-9 md:w-10 md:h-10 flex items-center justify-center border border-white/10 transition-transform hover:scale-105 active:scale-95 cursor-pointer"
            >
              ✕
            </button>
            <iframe
              src={`https://www.youtube.com/embed/${activeVideoKey}?autoplay=1&rel=0`}
              className="w-full h-full"
              allow="autoplay; encrypted-media"
              allowFullScreen
              title="Trailer Player"
            />
          </div>
        </div>
      )}
    </section>
  );
}