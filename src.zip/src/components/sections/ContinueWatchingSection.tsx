"use client";

import { useEffect, useState } from "react";
import Image from "next/image";
import Link from "next/link";
import { useParams } from "next/navigation";
import { getImageUrl } from "@/lib/tmdb";

export function ContinueWatchingSection() {
  const [items, setItems] = useState<any[]>([]);
  const [mounted, setMounted] = useState(false);
  const { locale = "en" } = useParams() as { locale?: string };

  useEffect(() => {
    setMounted(true);
    const list = JSON.parse(localStorage.getItem("recently-watched") || "[]");
    setItems(list);
  }, []);

  const handleRemove = (e: React.MouseEvent, itemId: number, itemType: string) => {
    e.preventDefault();
    e.stopPropagation();
    
    const list = JSON.parse(localStorage.getItem("recently-watched") || "[]");
    const updated = list.filter((item: any) => !(item.id === itemId && item.type === itemType));
    
    localStorage.setItem("recently-watched", JSON.stringify(updated));
    setItems(updated);
  };

  if (!mounted || items.length === 0) return null;

  return (
    <section className="py-6 px-4 md:px-8">
      <h2 className="text-base font-black text-white border-l-4 border-amber-400 pl-3 uppercase tracking-widest mb-5">
        Continue Watching
      </h2>
      <div className="flex gap-4 overflow-x-auto scrollbar-hide pb-2">
        {items.map((item) => {
          const resumeUrl = item.type === "tv"
            ? `/${locale}/watch/${item.id}?type=tv&season=${item.season || 1}`
            : `/${locale}/watch/${item.id}?type=movie`;

          return (
            <Link
              key={`${item.type}-${item.id}`}
              href={resumeUrl}
              className="flex-shrink-0 group relative w-36"
            >
              <div className="relative aspect-[2/3] rounded-xl overflow-hidden bg-zinc-800 shadow-lg transition-transform duration-300 group-hover:scale-[1.03] group-hover:shadow-2xl">
                {/* Remove button */}
                <button
                  type="button"
                  onClick={(e) => handleRemove(e, item.id, item.type)}
                  className="absolute top-2 right-2 z-30 w-7 h-7 bg-black/85 hover:bg-zinc-800 text-zinc-300 hover:text-white border border-white/5 rounded-full flex items-center justify-center transition-all opacity-0 group-hover:opacity-100 hover:scale-105 shadow-lg cursor-pointer"
                  title="Remove from history"
                >
                  <svg className="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M6 18L18 6M6 6l12 12" />
                  </svg>
                </button>

                <Image
                  src={getImageUrl(item.posterPath, "w300")}
                  alt={item.title}
                  fill
                  sizes="144px"
                  className="object-cover"
                  loading="lazy"
                />
                
                {/* Play icon overlay */}
                <div className="absolute inset-0 bg-black/45 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                  <div className="w-10 h-10 rounded-full bg-amber-400 text-zinc-950 flex items-center justify-center shadow-lg">
                    <svg className="w-5 h-5 fill-current ml-0.5" viewBox="0 0 24 24">
                      <path d="M8 5v14l11-7z" />
                    </svg>
                  </div>
                </div>
              </div>
              <div className="mt-2 px-0.5">
                <p className="text-white text-xs font-bold truncate group-hover:text-amber-400 transition-colors">
                  {item.title}
                </p>
                <p className="text-zinc-550 font-bold text-[10px] mt-0.5 uppercase tracking-wide">
                  {item.type === "tv" ? `Season ${item.season || 1}` : "Movie"}
                </p>
              </div>
            </Link>
          );
        })}
      </div>
    </section>
  );
}
