"use client";

import Link from "next/link";
import Image from "next/image";
import { useParams } from "next/navigation";
import { getImageUrl } from "@/lib/tmdb";
import { formatYear, cn } from "@/lib/utils";

interface FranchiseItem {
  id: number;
  title: string;
  poster_path: string | null;
  backdrop_path: string | null;
  release_date: string;
  vote_average: number;
  media_type: "movie" | "tv";
}

interface FranchiseSectionProps {
  items: FranchiseItem[];
  currentId: number;
}

export function FranchiseSection({ items, currentId }: FranchiseSectionProps) {
  const params = useParams();
  const locale = (params?.locale as string) || "en";

  if (items.length <= 1) return null;

  return (
    <section className="py-10 border-t border-zinc-900 mt-12 select-none">
      <div className="mb-6">
        <h2 className="text-xl font-black text-white border-l-4 border-amber-400 pl-3 uppercase tracking-wider flex items-center gap-2">
          📦 {locale === "ar" ? "الحزمة الكاملة والترتيب الزمني للقصة" : "Complete Saga / Franchise Chronological Pack"}
        </h2>
        <p className="text-zinc-550 text-xs mt-1 font-medium">
          {locale === "ar" 
            ? "شاهد القصة بالترتيب الزمني الصحيح للإصدار من البداية (رقم 1) وحتى أحدث عمل." 
            : "Watch the complete series and movies in the precise chronological timeline of release."}
        </p>
      </div>

      <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-4">
        {items.map((item, idx) => {
          const isCurrent = item.id === currentId;
          const year = formatYear(item.release_date);
          
          const detailUrl = item.media_type === "tv"
            ? `/${locale}/series/${item.id}`
            : `/${locale}/movies/${item.id}`;

          return (
            <Link
              key={`${item.media_type}-${item.id}`}
              href={detailUrl}
              className={cn(
                "group relative flex flex-col bg-zinc-900/40 border rounded-2xl overflow-hidden p-2.5 transition-all duration-300",
                isCurrent 
                  ? "border-amber-400/70 shadow-xl shadow-amber-400/5 bg-amber-400/5" 
                  : "border-zinc-800/80 hover:border-zinc-700/60 hover:-translate-y-1"
              )}
            >
              <div className="relative aspect-[2/3] rounded-xl overflow-hidden bg-zinc-800">
                <div className="absolute top-2 left-2 z-10 bg-black/85 backdrop-blur-sm w-7 h-7 flex items-center justify-center rounded-lg border border-white/5 shadow-md">
                  <span className="text-amber-400 font-black text-xs">{idx + 1}</span>
                </div>

                {item.poster_path ? (
                  <Image
                    src={getImageUrl(item.poster_path, "w300")}
                    alt={item.title}
                    fill
                    className="object-cover transition-transform duration-500 group-hover:scale-103"
                    unoptimized
                  />
                ) : (
                  <div className="w-full h-full bg-zinc-900 flex flex-col items-center justify-center p-4 text-center">
                    <span className="text-2xl">🎬</span>
                    <span className="text-[10px] text-zinc-500 font-bold mt-2 uppercase tracking-wider">
                      No Poster
                    </span>
                  </div>
                )}

                {isCurrent && (
                  <div className="absolute bottom-2 left-2 right-2 bg-amber-400 text-zinc-950 text-[9px] font-black py-0.5 rounded text-center uppercase tracking-wide">
                    {locale === "ar" ? "أنت هنا حالياً" : "Watching Now"}
                  </div>
                )}
              </div>

              <div className="mt-2.5 px-1 flex-1 flex flex-col justify-between">
                <div>
                  <p className="text-white text-xs font-bold line-clamp-2 leading-snug group-hover:text-amber-400 transition-colors">
                    {item.title}
                  </p>
                </div>
                <div className="flex items-center justify-between text-[10px] text-zinc-500 font-bold mt-2 border-t border-zinc-900/60 pt-1.5">
                  <span className="uppercase tracking-wider">
                    {item.media_type === "tv" ? "📺 Series" : "🎬 Movie"}
                  </span>
                  <span>{year}</span>
                </div>
              </div>
            </Link>
          );
        })}
      </div>
    </section>
  );
}