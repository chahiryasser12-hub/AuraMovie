"use client";

import { useRef } from "react";
import Link from "next/link";
import type { TMDBMovie } from "@/types/tmdb";
import { MovieCard } from "@/components/media/MovieCard";

interface GenreSectionProps {
  title: string;
  movies: TMDBMovie[];
  explorePath?: string;
}

export function GenreSection({ title, movies, explorePath }: GenreSectionProps) {
  const scrollRef = useRef<HTMLDivElement>(null);

  const scroll = (direction: "left" | "right") => {
    if (!scrollRef.current) return;
    const amount = 340;
    scrollRef.current.scrollBy({
      left: direction === "left" ? -amount : amount,
      behavior: "smooth",
    });
  };

  if (!movies || movies.length === 0) return null;

  return (
    <section className="py-6">
      {/* Title block */}
      <div className="flex items-center justify-between mb-5 px-4 md:px-8">
        <h2 className="text-base font-black text-white border-l-4 border-amber-400 pl-3 uppercase tracking-widest select-none">
          {title}
        </h2>
        
        <div className="flex items-center gap-4">
          {explorePath && (
            <Link
              href={explorePath}
              className="text-xs font-bold text-zinc-400 hover:text-amber-400 transition-colors flex items-center gap-1 uppercase tracking-wider select-none"
            >
              Explore More
              <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M9 5l7 7-7 7" />
              </svg>
            </Link>
          )}
          
          {/* Scroll Triggers */}
          <div className="hidden md:flex gap-1.5">
            <button
              type="button"
              onClick={() => scroll("left")}
              aria-label={`Scroll ${title} left`}
              className="w-8 h-8 rounded-full bg-zinc-900 hover:bg-zinc-800 text-white flex items-center justify-center border border-zinc-850 hover:border-zinc-700 transition-all cursor-pointer"
            >
              <svg aria-hidden="true" className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M15 19l-7-7 7-7" />
              </svg>
            </button>
            <button
              type="button"
              onClick={() => scroll("right")}
              aria-label={`Scroll ${title} right`}
              className="w-8 h-8 rounded-full bg-zinc-900 hover:bg-zinc-800 text-white flex items-center justify-center border border-zinc-850 hover:border-zinc-700 transition-all cursor-pointer"
            >
              <svg aria-hidden="true" className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M9 5l7 7-7 7" />
              </svg>
            </button>
          </div>
        </div>
      </div>

      {/* Horizontal Scroller */}
      <div
        ref={scrollRef}
        className="flex gap-4 overflow-x-auto scrollbar-hide px-4 md:px-8 pb-3"
        style={{ contentVisibility: "auto", containIntrinsicSize: "320px", scrollbarWidth: "none", msOverflowStyle: "none" }}
      >
        {movies.slice(0, 8).map((movie) => (
          <div key={movie.id} className="w-[172px] flex-shrink-0">
            <MovieCard movie={movie} />
          </div>
        ))}
      </div>
    </section>
  );
}
