export * from "./tmdb";

export interface EmbedProvider {
  id: string;
  name: string;
  logo: string;
  color: string;
  getMovieUrl: (tmdbId: number) => string;
  getSeriesUrl: (tmdbId: number, season?: number, episode?: number) => string;
}

export interface WatchlistItem {
  id: number;
  tmdbId: number;
  mediaType: "movie" | "tv";
  title: string;
  posterPath: string | null;
  addedAt: Date;
}

export interface RecentlyWatched {
  id: number;
  tmdbId: number;
  mediaType: "movie" | "tv";
  title: string;
  posterPath: string | null;
  watchedAt: Date;
  progress?: number;
}
