import type {
  TMDBMovie,
  TMDBSeries,
  TMDBMovieDetails,
  TMDBSeriesDetails,
  TMDBPaginatedResponse,
  TMDBSearchMultiResult,
} from "@/types/tmdb";

const BASE_URL = process.env.TMDB_BASE_URL || "https://api.themoviedb.org/3";
const API_KEY = process.env.TMDB_API_KEY || "";
export const IMAGE_BASE_URL =
  process.env.TMDB_IMAGE_BASE_URL || "https://image.tmdb.org/t/p";

export function getImageUrl(
  path: string | null,
  size: "w200" | "w300" | "w400" | "w500" | "w780" | "w1280" | "original" = "w500"
): string {
  if (!path) return "/images/placeholder.jpg";
  return `${IMAGE_BASE_URL}/${size}${path}`;
}

async function tmdbFetch<T>(
  endpoint: string,
  params: Record<string, string> = {}
): Promise<T> {
  const url = new URL(`${BASE_URL}${endpoint}`);
  url.searchParams.set("api_key", API_KEY);
  Object.entries(params).forEach(([key, value]) => {
    url.searchParams.set(key, value);
  });

  const res = await fetch(url.toString(), {
    next: { revalidate: 3600 },
  });

  if (!res.ok) {
    throw new Error(
      `TMDB API error: ${res.status} ${res.statusText} for ${endpoint}`
    );
  }

  return res.json() as Promise<T>;
}

export interface TMDBCollection {
  id: number;
  name: string;
  overview: string;
  poster_path: string | null;
  backdrop_path: string | null;
  parts: TMDBMovie[];
}

export async function getCollection(id: number, lang: string = "en"): Promise<TMDBCollection> {
  return tmdbFetch(`/collection/${id}`, { language: lang });
}

// Movies
export async function getTrendingMovies(
  timeWindow: "day" | "week" = "week",
  lang: string = "en"
): Promise<TMDBPaginatedResponse<TMDBMovie>> {
  return tmdbFetch(`/trending/movie/${timeWindow}`, { language: lang });
}

export async function getPopularMovies(
  page = 1,
  lang: string = "en"
): Promise<TMDBPaginatedResponse<TMDBMovie>> {
  return tmdbFetch("/movie/popular", { page: String(page), language: lang });
}

export async function getTopRatedMovies(
  page = 1,
  lang: string = "en"
): Promise<TMDBPaginatedResponse<TMDBMovie>> {
  return tmdbFetch("/movie/top_rated", { page: String(page), language: lang });
}

export async function getNowPlayingMovies(
  page = 1,
  lang: string = "en"
): Promise<TMDBPaginatedResponse<TMDBMovie>> {
  return tmdbFetch("/movie/now_playing", { page: String(page), language: lang });
}

export async function getUpcomingMovies(
  page = 1,
  lang: string = "en"
): Promise<TMDBPaginatedResponse<TMDBMovie>> {
  return tmdbFetch("/movie/upcoming", { page: String(page), language: lang });
}

export async function getMovieDetails(id: number, lang: string = "en"): Promise<TMDBMovieDetails> {
  return tmdbFetch(`/movie/${id}`, {
    append_to_response: "credits,videos,similar,recommendations",
    language: lang,
  });
}

export async function discoverMovies(params: {
  page?: number;
  with_genres?: string;
  sort_by?: string;
  year?: string;
  language?: string;
  with_original_language?: string;
  [key: string]: any; // يسمح بفلتر متقدم مخصص
}): Promise<TMDBPaginatedResponse<TMDBMovie>> {
  const stringParams: Record<string, string> = {};
  Object.entries(params).forEach(([k, v]) => {
    if (v !== undefined) stringParams[k] = String(v);
  });
  return tmdbFetch("/discover/movie", stringParams);
}

// Series
export async function getTrendingSeries(
  timeWindow: "day" | "week" = "week",
  lang: string = "en"
): Promise<TMDBPaginatedResponse<TMDBSeries>> {
  return tmdbFetch(`/trending/tv/${timeWindow}`, { language: lang });
}

export async function getPopularSeries(
  page = 1,
  lang: string = "en"
): Promise<TMDBPaginatedResponse<TMDBSeries>> {
  return tmdbFetch("/tv/popular", { page: String(page), language: lang });
}

export async function getTopRatedSeries(
  page = 1,
  lang: string = "en"
): Promise<TMDBPaginatedResponse<TMDBSeries>> {
  return tmdbFetch("/tv/top_rated", { page: String(page), language: lang });
}

export async function getOnAirSeries(
  page = 1,
  lang: string = "en"
): Promise<TMDBPaginatedResponse<TMDBSeries>> {
  return tmdbFetch("/tv/on_the_air", { page: String(page), language: lang });
}

export async function getSeriesDetails(
  id: number,
  lang: string = "en"
): Promise<TMDBSeriesDetails> {
  return tmdbFetch(`/tv/${id}`, {
    append_to_response: "credits,videos,similar,recommendations",
    language: lang,
  });
}

export async function discoverSeries(params: {
  page?: number;
  with_genres?: string;
  sort_by?: string;
  first_air_date_year?: string;
  language?: string;
  with_original_language?: string;
  [key: string]: any; // يسمح بفلتر متقدم مخصص
}): Promise<TMDBPaginatedResponse<TMDBSeries>> {
  const stringParams: Record<string, string> = {};
  Object.entries(params).forEach(([k, v]) => {
    if (v !== undefined) stringParams[k] = String(v);
  });
  return tmdbFetch("/discover/tv", stringParams);
}

// People
export interface TMDBPersonDetails {
  id: number;
  name: string;
  biography: string;
  profile_path: string | null;
  birthday: string | null;
  place_of_birth: string | null;
  combined_credits?: {
    cast: Array<{
      id: number;
      title?: string;
      name?: string;
      poster_path: string | null;
      media_type: "movie" | "tv";
      release_date?: string;
      first_air_date?: string;
      vote_average: number;
      character?: string;
    }>;
  };
}

export async function getPersonDetails(id: number, lang: string = "en"): Promise<TMDBPersonDetails> {
  return tmdbFetch(`/person/${id}`, {
    append_to_response: "combined_credits",
    language: lang,
  });
}

export async function searchPeople(
  query: string,
  page = 1,
  lang: string = "en"
): Promise<TMDBPaginatedResponse<TMDBSearchMultiResult>> {
  return tmdbFetch("/search/person", {
    query,
    page: String(page),
    include_adult: "false",
    language: lang,
  });
}

// Search
export async function searchMulti(
  query: string,
  page = 1,
  lang: string = "en"
): Promise<TMDBPaginatedResponse<TMDBSearchMultiResult>> {
  return tmdbFetch("/search/multi", {
    query,
    page: String(page),
    include_adult: "false",
    language: lang,
  });
}

export async function searchMovies(
  query: string,
  page = 1,
  lang: string = "en"
): Promise<TMDBPaginatedResponse<TMDBMovie>> {
  return tmdbFetch("/search/movie", {
    query,
    page: String(page),
    include_adult: "false",
    language: lang,
  });
}

export async function searchSeries(
  query: string,
  page = 1,
  lang: string = "en"
): Promise<TMDBPaginatedResponse<TMDBSeries>> {
  return tmdbFetch("/search/tv", {
    query,
    page: String(page),
    include_adult: "false",
    language: lang,
  });
}

export const MOVIE_GENRES: Record<number, string> = {
  28: "Action",
  12: "Adventure",
  16: "Animation",
  35: "Comedy",
  80: "Crime",
  99: "Documentary",
  18: "Drama",
  10751: "Family",
  14: "Fantasy",
  36: "History",
  27: "Horror",
  10402: "Music",
  9648: "Mystery",
  10749: "Romance",
  878: "Sci-Fi",
  10770: "TV Movie",
  53: "Thriller",
  10752: "War",
  37: "Western",
};

export const TV_GENRES: Record<number, string> = {
  10759: "Action & Adventure",
  16: "Animation",
  35: "Comedy",
  80: "Crime",
  99: "Documentary",
  18: "Drama",
  10751: "Family",
  10762: "Kids",
  9648: "Mystery",
  10763: "News",
  10764: "Reality",
  10765: "Sci-Fi & Fantasy",
  10766: "Soap",
  10767: "Talk",
  10768: "War & Politics",
  37: "Western",
};

export async function getTrendingAnimeSeries(
  page = 1,
  lang: string = "en"
): Promise<TMDBPaginatedResponse<TMDBSeries>> {
  return tmdbFetch("/discover/tv", {
    page: String(page),
    with_genres: "16",
    with_original_language: "ja",
    sort_by: "popularity.desc",
    language: lang,
  });
}

export async function getTrendingAnimeMovies(
  page = 1,
  lang: string = "en"
): Promise<TMDBPaginatedResponse<TMDBMovie>> {
  return tmdbFetch("/discover/movie", {
    page: String(page),
    with_genres: "16",
    with_original_language: "ja",
    sort_by: "popularity.desc",
    language: lang,
  });
}

export interface FranchiseItem {
  id: number;
  title: string;
  poster_path: string | null;
  backdrop_path: string | null;
  release_date: string;
  vote_average: number;
  media_type: "movie" | "tv";
  original_language?: string;
  is_animation?: boolean;
}

const FRANCHISE_STOP_WORDS = new Set([
  "the", "a", "an", "of", "in", "on", "at", "to", "for", "with", "by", "from",
  "bad", "good", "love", "life", "man", "one", "go", "all", "out", "no", "new",
  "old", "lost", "red", "black", "white", "blue", "dark", "light", "last", "first",
  "my", "your", "our", "their", "his", "her", "its", "it", "me", "you", "him", "us",
  "part", "chapter", "episode", "season", "volume", "movie", "series", "saga"
]);

export async function getFranchisePack(
  title: string, 
  lang: string = "en",
  collectionId?: number | null,
  originalLanguage?: string | null,
  isAnimation?: boolean
): Promise<FranchiseItem[]> {
  
  if (collectionId) {
    try {
      const collection = await getCollection(collectionId, lang);
      if (collection && collection.parts) {
        return collection.parts.map((m): FranchiseItem => ({
          id: m.id,
          title: m.title,
          poster_path: m.poster_path,
          backdrop_path: m.backdrop_path,
          release_date: m.release_date || "",
          vote_average: m.vote_average,
          media_type: "movie" as "movie" | "tv"
        })).sort((a, b) => {
          if (!a.release_date) return 1;
          if (!b.release_date) return -1;
          return new Date(a.release_date).getTime() - new Date(b.release_date).getTime();
        });
      }
    } catch (err) {
      console.warn("Failed to fetch official collection, falling back to smart search filter", err);
    }
  }

  let rootName = title.trim();
  const splitParts = title.split(/[:\-–]/);
  
  if (splitParts.length > 1) {
    const candidate1 = splitParts[0].trim();
    const candidate2 = splitParts[1].trim();

    if (candidate2.toLowerCase().includes("kimetsu no yaiba") || candidate2.toLowerCase().includes("demon slayer")) {
      rootName = "Kimetsu no Yaiba";
    } else {
      const isStopWord = FRANCHISE_STOP_WORDS.has(candidate1.toLowerCase());
      if (candidate1.length >= 4 && !isStopWord) {
        rootName = candidate1;
      }
    }
  }

  const lowerTitle = title.toLowerCase();
  if (lowerTitle.includes("demon slayer") || lowerTitle.includes("kimetsu no yaiba")) {
    rootName = "Kimetsu no Yaiba";
  } else if (lowerTitle.includes("jujutsu kaisen")) {
    rootName = "Jujutsu Kaisen";
  } else if (lowerTitle.includes("attack on titan") || lowerTitle.includes("shingeki no kyojin")) {
    rootName = "Attack on Titan";
  } else if (lowerTitle.includes("my hero academia") || lowerTitle.includes("boku no hero")) {
    rootName = "My Hero Academia";
  }

  if (!rootName || rootName.length < 3) return [];

  try {
    const [moviesRes, seriesRes] = await Promise.all([
      searchMovies(rootName, 1, lang),
      searchSeries(rootName, 1, lang),
    ]);

    const combined: FranchiseItem[] = [];

    if (moviesRes?.results) {
      moviesRes.results.forEach((m) => {
        const itemIsAnimation = m.genre_ids?.includes(16);
        combined.push({
          id: m.id,
          title: m.title,
          poster_path: m.poster_path,
          backdrop_path: m.backdrop_path,
          release_date: m.release_date || "",
          vote_average: m.vote_average,
          media_type: "movie",
          original_language: m.original_language,
          is_animation: itemIsAnimation
        });
      });
    }

    if (seriesRes?.results) {
      seriesRes.results.forEach((s) => {
        const itemIsAnimation = s.genre_ids?.includes(16);
        combined.push({
          id: s.id,
          title: s.name,
          poster_path: s.poster_path,
          backdrop_path: s.backdrop_path,
          release_date: s.first_air_date || "",
          vote_average: s.vote_average,
          media_type: "tv",
          original_language: s.original_language,
          is_animation: itemIsAnimation
        });
      });
    }

    const cleanRoot = rootName.toLowerCase();
    
    const filtered = combined.filter((item) => {
      const itemTitle = item.title.toLowerCase();
      
      const hasBoundaryMatch = new RegExp(`\\b${cleanRoot}\\b`).test(itemTitle) || 
                               itemTitle.includes(cleanRoot) ||
                               (cleanRoot === "kimetsu no yaiba" && (itemTitle.includes("demon slayer") || itemTitle.includes("kimetsu no yaiba")));
      if (!hasBoundaryMatch) return false;

      if (originalLanguage && item.original_language !== originalLanguage) {
        return false;
      }

      if (isAnimation && !item.is_animation) {
        return false;
      }

      // Hide placeholder items that lack a poster or a release date
      if (!item.poster_path || !item.release_date) {
        return false;
      }

      return true;
    });

    return filtered.sort((a, b) => {
      if (!a.release_date) return 1;
      if (!b.release_date) return -1;
      return new Date(a.release_date).getTime() - new Date(b.release_date).getTime();
    });
  } catch (err) {
    console.error("Failed to fetch franchise pack:", err);
    return [];
  }
}
