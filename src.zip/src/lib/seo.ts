import { getImageUrl } from "@/lib/tmdb";
import type { TMDBMovieDetails, TMDBSeriesDetails } from "@/types/tmdb";

export const SITE_NAME = "AuraMovie";
export const SITE_URL = process.env.NEXT_PUBLIC_SITE_URL || "https://auramovie.dpdns.org";

/**
 * إنشاء عنوان صفحة احترافي (SEO Optimized) - ar / fr / en
 */
export function buildLocalizedTitle(name: string, year: string, locale: string, type: "movie" | "tv" | "anime") {
  if (locale === 'ar') {
    if (type === 'anime') return `مشاهدة انمي ${name} مترجم كامل بجودة عالية ${year} - AuraMovie`;
    if (type === 'tv') return `مشاهدة مسلسل ${name} مترجم اون لاين - جميع الحلقات ${year} - AuraMovie`;
    return `مشاهدة فيلم ${name} مترجم اون لاين بجودة عالية HD ${year} - AuraMovie`;
  }

  if (locale === 'fr') {
    if (type === 'anime') return `Regarder l'anime ${name} (${year}) en streaming VF/VOSTFR complet | ${SITE_NAME}`;
    if (type === 'tv') return `Regarder la série ${name} (${year}) en streaming VF - Tous les épisodes | ${SITE_NAME}`;
    return `Regarder le film ${name} (${year}) en streaming VF/VOSTFR HD | ${SITE_NAME}`;
  }

  const label = type === 'movie' ? 'Movie' : type === 'tv' ? 'TV Series' : 'Anime';
  return `Watch ${name} (${year}) Online - Full ${label} HD | ${SITE_NAME}`;
}

/**
 * إنشاء وصف SEO - ar / fr / en
 */
export function buildLocalizedDescription(overview: string, name: string, locale: string) {
  const cleanOverview = overview?.slice(0, 150)?.trim() || "";

  if (locale === 'ar') {
    return `مشاهدة وتحميل ${name} مترجم بجودة عالية. ${cleanOverview}... استمتع بمشاهدة أحدث الأفلام والمسلسلات اون لاين حصرياً على AuraMovie.`;
  }

  if (locale === 'fr') {
    return `Regardez ${name} en streaming HD gratuit. ${cleanOverview}... Découvrez les derniers films et séries en streaming exclusivement sur ${SITE_NAME}.`;
  }

  return `Stream ${name} online with full HD quality. ${cleanOverview} Discover cast, ratings, and trailers for ${name} on ${SITE_NAME}.`;
}

/**
 * روابط الصور المطلقة للـ SEO
 */
export function absoluteImage(path: string | null, size: "w500" | "original" = "w500") {
  if (!path) return `${SITE_URL}/images/placeholder.jpg`;
  return getImageUrl(path, size);
}

/**
 * JSON-LD: Breadcrumb Schema
 */
export function buildBreadcrumbJsonLd(path: { name: string, item: string }[]) {
  return {
    "@context": "https://schema.org",
    "@type": "BreadcrumbList",
    "itemListElement": path.map((p, i) => ({
      "@type": "ListItem",
      "position": i + 1,
      "name": p.name,
      "item": `${SITE_URL}${p.item}`
    }))
  };
}

/**
 * JSON-LD: Video Schema - ar / fr / en
 */
export function buildVideoJsonLd(media: any, locale: string) {
  const title = "title" in media ? media.title : media.name;

  const name =
    locale === 'ar' ? `مشاهدة ${title} مترجم` :
    locale === 'fr' ? `Regarder ${title} en streaming` :
    `Watch ${title} Online`;

  return {
    "@context": "https://schema.org",
    "@type": "VideoObject",
    "name": name,
    "description": media.overview,
    "thumbnailUrl": [getImageUrl(media.poster_path, "w500")],
    "uploadDate": (media.release_date || media.first_air_date) ? `${media.release_date || media.first_air_date}T08:00:00+00:00` : new Date().toISOString(),
    "contentUrl": `${SITE_URL}/${locale}/watch/${media.id}`,
    "embedUrl": `${SITE_URL}/${locale}/watch/${media.id}`,
    "interactionStatistic": {
      "@type": "InteractionCounter",
      "interactionType": { "@type": "WatchAction" },
      "userInteractionCount": media.vote_count || 100
    }
  };
}

/**
 * JSON-LD: Movie Schema
 */
export function buildMovieJsonLd(movie: TMDBMovieDetails) {
  return {
    "@context": "https://schema.org",
    "@type": "Movie",
    "name": movie.title,
    "description": movie.overview,
    "image": absoluteImage(movie.poster_path, "w500"),
    "datePublished": movie.release_date,
    "aggregateRating": movie.vote_count > 0 ? {
      "@type": "AggregateRating",
      "ratingValue": movie.vote_average.toFixed(1),
      "reviewCount": movie.vote_count,
      "bestRating": "10",
      "worstRating": "1"
    } : undefined
  };
}

/**
 * JSON-LD: TV Series Schema
 */
export function buildSeriesJsonLd(series: TMDBSeriesDetails) {
    return {
      "@context": "https://schema.org",
      "@type": "TVSeries",
      "name": series.name,
      "description": series.overview,
      "image": absoluteImage(series.poster_path, "w500"),
      "startDate": series.first_air_date,
      "numberOfSeasons": series.number_of_seasons,
      "aggregateRating": series.vote_count > 0 ? {
        "@type": "AggregateRating",
        "ratingValue": series.vote_average.toFixed(1),
        "reviewCount": series.vote_count,
        "bestRating": "10",
        "worstRating": "1"
      } : undefined
    };
}

/**
 * JSON-LD: FAQ Schema for SEO domination - ar / fr / en
 */
export function buildFAQJsonLd(name: string, type: string, locale: string) {
  const label =
    locale === 'ar' ? (type === 'movie' ? 'فيلم' : type === 'anime' ? 'أنمي' : 'مسلسل') :
    locale === 'fr' ? (type === 'movie' ? 'film' : type === 'anime' ? 'anime' : 'série') :
    (type === 'movie' ? 'movie' : type === 'anime' ? 'anime' : 'series');

  if (locale === 'ar') {
    return {
      "@context": "https://schema.org",
      "@type": "FAQPage",
      "mainEntity": [
        {
          "@type": "Question",
          "name": `أين يمكنني مشاهدة ${label} ${name} مترجم كامل؟`,
          "acceptedAnswer": {
            "@type": "Answer",
            "text": `يمكنك مشاهدة وتحميل ${label} ${name} مترجم بجودة عالية حصرياً وبدون إعلانات مزعجة على منصة AuraMovie.`
          }
        },
        {
          "@type": "Question",
          "name": `هل قصة ${label} ${name} تستحق المشاهدة؟`,
          "acceptedAnswer": {
            "@type": "Answer",
            "text": `نعم، يعتبر ${name} من أفضل الأعمال في تصنيفه، وقد حظي بتقييمات عالمية إيجابية جداً من النقاد والمشاهدين.`
          }
        }
      ]
    };
  }

  if (locale === 'fr') {
    return {
      "@context": "https://schema.org",
      "@type": "FAQPage",
      "mainEntity": [
        {
          "@type": "Question",
          "name": `Où puis-je regarder le ${label} ${name} en streaming complet ?`,
          "acceptedAnswer": {
            "@type": "Answer",
            "text": `Vous pouvez regarder et télécharger le ${label} ${name} en HD, en streaming exclusif et sans publicités gênantes sur AuraMovie.`
          }
        },
        {
          "@type": "Question",
          "name": `L'histoire de ${name} vaut-elle le coup d'œil ?`,
          "acceptedAnswer": {
            "@type": "Answer",
            "text": `Oui, ${name} est considéré comme l'une des meilleures œuvres de sa catégorie, avec des évaluations très positives de la part des critiques et des spectateurs du monde entier.`
          }
        }
      ]
    };
  }

  return {
    "@context": "https://schema.org",
    "@type": "FAQPage",
    "mainEntity": [
      {
        "@type": "Question",
        "name": `Where to watch ${name} online full hd?`,
        "acceptedAnswer": {
          "@type": "Answer",
          "text": `You can watch ${name} in HD quality with subtitles on AuraMovie.`
        }
      },
      {
        "@type": "Question",
        "name": `Is the story of ${name} worth watching?`,
        "acceptedAnswer": {
          "@type": "Answer",
          "text": `Yes, ${name} is highly rated by critics and viewers globally in its genre.`
        }
      }
    ]
  };
}

export function cleanJsonLd<T extends object>(obj: T): T {
  return JSON.parse(JSON.stringify(obj));
}