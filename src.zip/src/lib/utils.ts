import { type ClassValue, clsx } from "clsx";
import { twMerge } from "tailwind-merge";

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

export function formatDate(dateStr: string): string {
  if (!dateStr) return "Unknown";
  return new Date(dateStr).toLocaleDateString("en-US", {
    year: "numeric",
    month: "long",
    day: "numeric",
  });
}

export function formatYear(dateStr: string): string {
  if (!dateStr) return "Unknown";
  return new Date(dateStr).getFullYear().toString();
}

export function formatRuntime(minutes: number | null): string {
  if (!minutes) return "Unknown";
  const h = Math.floor(minutes / 60);
  const m = minutes % 60;
  return h > 0 ? `${h}h ${m}m` : `${m}m`;
}

export function formatVoteAverage(vote: number): string {
  return vote.toFixed(1);
}

export function formatNumber(num: number): string {
  if (num >= 1_000_000) return `${(num / 1_000_000).toFixed(1)}M`;
  if (num >= 1_000) return `${(num / 1_000).toFixed(1)}K`;
  return num.toString();
}

export function slugify(str: string): string {
  return str
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/(^-|-$)/g, "");
}

export function getRatingColor(rating: number): string {
  if (rating >= 7.5) return "text-green-400";
  if (rating >= 6) return "text-yellow-400";
  return "text-red-400";
}

export function getRatingBg(rating: number): string {
  if (rating >= 7.5) return "bg-green-500";
  if (rating >= 6) return "bg-yellow-500";
  return "bg-red-500";
}

export function truncate(str: string, maxLength: number): string {
  if (str.length <= maxLength) return str;
  return str.slice(0, maxLength).trimEnd() + "…";
}

/**
 * خوارزمية ترتيب النتائج الذكية (Smart Autocomplete/Search Ranking)
 * ترتب النتائج بناءً على درجة تطابق الحروف الأولى ثم وجود الكلمات المستقلة ثم معدل شعبية العمل على TMDB.
 */
export function sortSmartResults<T extends { title?: string; name?: string; popularity?: number }>(
  results: T[],
  query: string
): T[] {
  const q = query.toLowerCase().trim();
  if (!q) return results;

  return [...results].sort((a, b) => {
    const titleA = (a.title || a.name || "").toLowerCase();
    const titleB = (b.title || b.name || "").toLowerCase();

    const aStartsWith = titleA.startsWith(q);
    const bStartsWith = titleB.startsWith(q);

    // 1. الأولوية للأعمال التي تبدأ بكلمة البحث تماماً (مثل "Breaking Bad" عند البحث بـ "break")
    if (aStartsWith && !bStartsWith) return -1;
    if (!aStartsWith && bStartsWith) return 1;

    // 2. الأولوية التالية للأعمال التي تحتوي على الكلمة كجزء مستقل بحدود واضحة
    const aContainsWord = new RegExp(`\\b${q}\\b`).test(titleA);
    const bContainsWord = new RegExp(`\\b${q}\\b`).test(titleB);
    if (aContainsWord && !bContainsWord) return -1;
    if (!aContainsWord && bContainsWord) return 1;

    // 3. في حال تساوي الشروط السابقة، يتم الترتيب بناءً على شعبية العمل (Popularity Score) تنازلياً
    const popA = a.popularity || 0;
    const popB = b.popularity || 0;
    return popB - popA;
  });
}