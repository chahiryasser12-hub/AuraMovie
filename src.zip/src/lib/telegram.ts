import { getMovieDetails, getSeriesDetails, getImageUrl } from "./tmdb";

/**
 * وظيفة لإرسال بوست احترافي للقناة فـ التيليجرام
 */
export async function postMediaToTelegram(id: number, type: 'movie' | 'tv', locale: string = 'ar') {
  const token = process.env.TELEGRAM_BOT_TOKEN;
  const chatId = process.env.TELEGRAM_CHAT_ID;

  if (!token || !chatId) {
    console.error("❌ Telegram credentials missing in .env");
    return { ok: false, error: "Credentials missing" };
  }

  try {
    // 1. جلب البيانات من TMDB
    const [mediaEn, mediaLocale] = await Promise.all([
      type === 'movie' ? getMovieDetails(id, "en") : getSeriesDetails(id, "en"),
      locale !== 'en' ? (type === 'movie' ? getMovieDetails(id, locale) : getSeriesDetails(id, locale)).catch(() => null) : null
    ]);

    const title = 'title' in mediaEn ? mediaEn.title : mediaEn.name;
    const year = ('release_date' in mediaEn ? mediaEn.release_date : mediaEn.first_air_date)?.slice(0, 4) || "2026";
    const overview = mediaLocale?.overview || mediaEn.overview || "";
    const posterUrl = getImageUrl(mediaEn.poster_path, "w500");
    
    const siteUrl = process.env.NEXT_PUBLIC_SITE_URL || "https://auramovie.dpdns.org";
    const watchLink = `${siteUrl}/${locale}/${type === 'movie' ? 'movies' : 'series'}/${id}`;

    const caption = `
<b>🎬 ${type === 'movie' ? 'فيلم جديد' : 'مسلسل جديد'}: ${title} (${year})</b>

📌 <i>${overview.slice(0, 250)}${overview.length > 250 ? '...' : ''}</i>

✅ <b>شاهده الآن مترجم حصرياً على AuraMovie:</b>
🔗 <a href="${watchLink}">رابط المشاهدة المباشر</a>

🍿 استمتعوا بالفيلم!
#AuraMovie #${type === 'movie' ? 'Movies' : 'Series'} #Anime #${title.replace(/\s+/g, '_')}
    `;

    // 2. الإرسال لـ Telegram API
    const response = await fetch(`https://api.telegram.org/bot${token}/sendPhoto`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        chat_id: String(chatId),
        photo: posterUrl,
        caption: caption,
        parse_mode: 'HTML',
        reply_markup: {
          inline_keyboard: [
            [{ text: "📺 شاهد الآن / Watch Now", url: watchLink }],
            [{ text: "🌐 الموقع الرسمي", url: siteUrl }]
          ]
        }
      })
    });

    // هنا فين كاين الحل: زدنا "as any" باش TypeScript ما يبقاش يصدعنا
    const result = (await response.json()) as any;

    if (!result.ok) {
      console.error("❌ Telegram API Error:", result.description);
    } else {
      console.log("✅ Successfully posted to Telegram");
    }

    return result;

  } catch (error) {
    console.error("❌ postMediaToTelegram Catch Error:", error);
    return { ok: false, error: "Internal Server Error" };
  }
}