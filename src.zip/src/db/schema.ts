import { pgTable, serial, varchar, text, timestamp, integer } from "drizzle-orm/pg-core";

// جدول الطلبات
export const requests = pgTable("requests", {
  id: serial("id").primaryKey(),
  title: varchar("title", { length: 255 }).notNull(),
  mediaType: varchar("media_type", { length: 50 }).notNull(),
  notes: text("notes"),
  status: varchar("status", { length: 50 }).default("pending"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// جدول التعليقات (UGC for SEO)
export const comments = pgTable("comments", {
  id: serial("id").primaryKey(),
  tmdbId: integer("tmdb_id").notNull(),
  mediaType: varchar("media_type", { length: 50 }).notNull(), // movie, tv, anime
  userName: varchar("user_name", { length: 100 }).notNull(),
  content: text("content").notNull(),
  rating: integer("rating"), // تقييم المستخدم من 1 إلى 10
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// جدول المقالات والأخبار (Blog for SEO Traffic)
export const articles = pgTable("articles", {
  id: serial("id").primaryKey(),
  slug: varchar("slug", { length: 255 }).notNull().unique(),
  title: varchar("title", { length: 255 }).notNull(),
  content: text("content").notNull(),
  imageUrl: varchar("image_url", { length: 500 }),
  locale: varchar("locale", { length: 10 }).default("ar").notNull(), // ar, en, fr
  publishedAt: timestamp("published_at").defaultNow().notNull(),
});