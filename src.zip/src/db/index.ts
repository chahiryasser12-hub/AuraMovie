import { neon, type NeonQueryFunction } from "@neondatabase/serverless";
import { drizzle, type NeonHttpDatabase } from "drizzle-orm/neon-http";
import { getCloudflareContext } from "@opennextjs/cloudflare";

const globalForDb = globalThis as typeof globalThis & {
  __arenaNextJsNeonDb?: NeonHttpDatabase;
};

function resolveConnectionString(): string {
  // 1. Local Development
  if (process.env.NODE_ENV === "development") {
    const databaseUrl = process.env.DATABASE_URL;
    if (!databaseUrl) {
      throw new Error("DATABASE_URL is required in development");
    }
    return databaseUrl;
  }

  // 2. Production (Cloudflare Workers) — نقرا DATABASE_URL من الـ env bindings
  try {
    const { env } = getCloudflareContext() as { env: any };
    if (env?.DATABASE_URL) {
      return env.DATABASE_URL;
    }
  } catch {
    // Not in Cloudflare context
  }

  const databaseUrl = process.env.DATABASE_URL;
  if (!databaseUrl) {
    throw new Error("DATABASE_URL is required");
  }
  return databaseUrl;
}

// كنبنيو الاتصال غير عند أول استعمال حقيقي (lazy) — ماشي عند تحميل الموديل
// هادشي ضروري باش getCloudflareContext() تلقى سياق الطلب الحقيقي
function getDbInstance(): NeonHttpDatabase {
  if (!globalForDb.__arenaNextJsNeonDb) {
    const connectionString = resolveConnectionString();
    const sql: NeonQueryFunction<false, false> = neon(connectionString);
    globalForDb.__arenaNextJsNeonDb = drizzle(sql);
  }
  return globalForDb.__arenaNextJsNeonDb;
}

export const db: NeonHttpDatabase = new Proxy({} as NeonHttpDatabase, {
  get(_target, prop, receiver) {
    const instance = getDbInstance();
    const value = Reflect.get(instance as object, prop, receiver);
    return typeof value === "function" ? value.bind(instance) : value;
  },
});